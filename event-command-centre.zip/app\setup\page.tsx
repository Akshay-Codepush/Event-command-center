'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { useEvent } from '@/hooks/use-event';
import { ROLES, type Role } from '@/types/event';
import { enhance } from '@/lib/ai';
import { DEFAULT_FORM, OBJECTIVES, generatePlan, sanitizeAiTasks, type SetupForm } from '@/lib/plan';
import { Badge, Btn, Card } from '@/components/ui';

const STEPS = ['Analyzing event brief…', 'Building milestone structure…', 'Creating role-wise tasks…', 'Calculating registration curve…', 'Initializing risk engine…', 'Command Centre ready.'];
const TITLES = ['Event basics', 'Audience', 'Objectives', 'Operational structure', 'Generate plan'];
const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));
const Field = ({ label, children }: { label: string; children: React.ReactNode }) => <label className="grid gap-1 text-xs text-mu">{label}{children}</label>;

export default function Setup() {
  const { s, applySetup } = useEvent(); const router = useRouter();
  const [f, setF] = useState<SetupForm>({ ...DEFAULT_FORM, name: s.event.name, date: s.event.date, venue: s.event.venue, city: s.event.city, targetRegistrations: s.event.targetRegistrations, expectedAttendance: s.event.expectedAttendance });
  const [step, setStep] = useState(0); const [done, setDone] = useState<string[]>([]); const [busy, setBusy] = useState(false); const [mode, setMode] = useState<'claude' | 'demo' | null>(null);
  const set = <K extends keyof SetupForm>(k: K, v: SetupForm[K]) => setF((p) => ({ ...p, [k]: v }));
  const toggle = <T,>(arr: T[], v: T) => (arr.includes(v) ? arr.filter((x) => x !== v) : [...arr, v]);
  const valid = f.name.trim() && f.date && f.targetRegistrations > 0 && f.roles.length > 0;

  const generate = async () => {
    setBusy(true); setDone([STEPS[0]]);
    const ai = await enhance<{ summary: string; tasks: unknown[] }>('plan', { form: f, baseline: generatePlan(f).map((t) => t.title) }, { summary: '', tasks: [] });
    setMode(ai.mode);
    for (let i = 1; i < STEPS.length; i++) { await sleep(420); setDone((d) => [...d, STEPS[i]]); }
    const n = applySetup(f, [...generatePlan(f), ...sanitizeAiTasks(ai.data.tasks, f.roles)]);
    await sleep(600); setBusy(false); router.push(n ? '/plan' : '/');
  };

  return (
    <Card title={`Guided event setup — step ${step + 1} of 5: ${TITLES[step]}`} className="max-w-3xl">
      <div className="mb-4 flex gap-1">{TITLES.map((_, i) => <div key={i} className={`h-1 flex-1 rounded ${i <= step ? 'bg-info' : 'bg-bd'}`} />)}</div>
      {step === 0 && <div className="grid gap-3 sm:grid-cols-2">
        <Field label="Event name"><input value={f.name} onChange={(e) => set('name', e.target.value)} /></Field>
        <Field label="Event type"><select value={f.type} onChange={(e) => set('type', e.target.value)}>{['Conference', 'Hackathon', 'Expo', 'Workshop'].map((o) => <option key={o}>{o}</option>)}</select></Field>
        <Field label="Event date"><input type="date" value={f.date} onChange={(e) => set('date', e.target.value)} /></Field>
        <Field label="Duration (days)"><input type="number" min={1} value={f.duration} onChange={(e) => set('duration', +e.target.value)} /></Field>
        <Field label="Venue"><input value={f.venue} onChange={(e) => set('venue', e.target.value)} /></Field><Field label="City"><input value={f.city} onChange={(e) => set('city', e.target.value)} /></Field></div>}
      {step === 1 && <div className="grid gap-3 sm:grid-cols-2">
        <Field label="Target audience"><input value={f.audience} onChange={(e) => set('audience', e.target.value)} /></Field>
        <Field label="Audience size"><input type="number" value={f.audienceSize} onChange={(e) => set('audienceSize', +e.target.value)} /></Field>
        <Field label="Expected registrations (target)"><input type="number" min={1} value={f.targetRegistrations} onChange={(e) => set('targetRegistrations', +e.target.value)} /></Field>
        <Field label="Expected attendance"><input type="number" value={f.expectedAttendance} onChange={(e) => set('expectedAttendance', +e.target.value)} /></Field></div>}
      {step === 2 && <div className="grid gap-3"><div className="flex flex-wrap gap-2">{OBJECTIVES.map((o) => <label key={o} className="flex gap-1.5 rounded-full border border-bd bg-p2 px-3 py-1"><input type="checkbox" checked={f.objectives.includes(o)} onChange={() => set('objectives', toggle(f.objectives, o))} />{o}</label>)}</div>
        <Field label="Event brief (optional — Claude uses it to add tasks)"><textarea rows={3} value={f.brief} onChange={(e) => set('brief', e.target.value)} placeholder="e.g. 2-day AI summit for 800 students and founders, sponsor-led, showcase on day 2…" className="rounded-md border border-bd bg-p2 p-2 text-tx" /></Field></div>}
      {step === 3 && <div className="flex flex-wrap gap-2">{ROLES.slice(1).map((o) => <label key={o} className="flex gap-1.5 rounded-full border border-bd bg-p2 px-3 py-1"><input type="checkbox" checked={f.roles.includes(o)} onChange={() => set('roles', toggle<Role>(f.roles, o))} />{o}</label>)}</div>}
      {step === 4 && <div><p className="mb-1 text-mu">{f.name} · {f.type} · {f.city} · {f.date} · target {f.targetRegistrations} · {f.roles.length} roles · {f.objectives.length} objectives.</p>
        <p className="mb-3 text-xs text-mu">Replaces the current plan: tasks for deselected roles are removed, new tasks are generated, and the risk engine re-evaluates against the new target and date.</p>
        <Btn variant="primary" disabled={busy || !valid} onClick={generate}>Generate Intelligent Event Plan</Btn> {mode && <Badge tone={mode === 'claude' ? 'ok' : 'warn'}>{mode === 'claude' ? 'CLAUDE' : 'DEMO INTELLIGENCE'}</Badge>}
        <div className="mt-3 space-y-1 text-xs" aria-live="polite">{done.map((d, i) => <div key={d} className={i === STEPS.length - 1 ? 'text-ok' : 'text-mu'}>✔ {d}</div>)}</div></div>}
      <div className="mt-5 flex gap-2"><Btn disabled={step === 0 || busy} onClick={() => setStep(step - 1)}>Back</Btn>{step < 4 && <Btn variant="primary" onClick={() => setStep(step + 1)}>Next</Btn>}</div>
    </Card>);
}
