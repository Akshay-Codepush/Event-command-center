'use client';
import { useEvent } from '@/hooks/use-event';
import { Card, Empty } from '@/components/ui';
import { RiskCard } from '@/components/risks';

export default function Risks() {
  const { s } = useEvent(); const lead = ['Event Lead', 'Leadership'].includes(s.role);
  const rs = lead ? s.risks : s.risks.filter((r) => r.assignedRole === s.role);
  return (<>
    <Card title="Risk engine" right={<span className="text-mu">8 rules evaluated live</span>}>{rs.length ? rs.map((r) => <RiskCard key={r.id} r={r} />) : <Empty>No active risks ✔</Empty>}</Card>
    <Card title="Rule coverage"><div className="text-xs text-mu">R1 Registration gap · R2 Partner &lt;70% · R3 Pending &gt;30% · R4 Conversion &lt;65% · R5 Overdue logistics · R6 Critical task blocked · R7 Velocity decline ×3 · R8 Department escalation (≥3 risks in one role)</div></Card></>);
}
