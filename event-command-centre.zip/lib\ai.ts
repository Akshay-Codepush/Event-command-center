import type { AppState } from '@/types/event';
import type { Partner } from '@/types/partner';
import type { Risk } from '@/types/risk';
import { actionsFor } from './actions';
import { departmentReadiness } from './metrics';

/** Deterministic "Demo Intelligence" — used when no ANTHROPIC_API_KEY. Same JSON shapes the Claude route returns. */
export function buildInsights(s: AppState) {
  const m = s.metrics, top = s.risks[0], early = s.velocity.slice(0, 3).reduce((a, b) => a + b, 0) / 3;
  const slow = Math.round((1 - m.avgVelocity / early) * 100);
  return {
    lines: [
      s.health.score >= 75 ? `Event is ${s.health.status.toLowerCase()}${s.healthHistory.at(-2)! > s.health.score ? ' but trending downward' : ''}.` : `Event is ${s.health.status.toLowerCase()} — intervention needed.`,
      `Registration velocity is ${Math.abs(slow)}% ${slow > 0 ? 'below its early pace' : 'above its early pace'}; gap to target ${m.gapPct.toFixed(1)}%.`,
      `Partner confirmations at ${s.partnerConfirmed}% (${s.partnerConfirmed < 70 ? 'below' : 'above'} the 70% threshold). Operations at ${m.opsReadiness}%.`,
      `If current velocity continues, registrations reach ~${m.forecast} (target ${s.event.targetRegistrations}).`,
    ],
    priority: top ? `Fix “${top.type}” first. ${actionsFor(top.id)[0]?.title ?? 'Escalate'} is the highest-leverage move. Defer low-impact tasks.`
      : 'No active risks. Maintain cadence and run the T-3 logistics verification.',
  };
}
export function managementSummary(s: AppState) {
  const top = s.risks[0], dr = Object.entries(departmentReadiness(s, s.metrics)).sort((a, b) => a[1] - b[1]);
  return { status: s.health.status, topPriority: top?.type ?? 'Maintain cadence', blocker: s.partnerConfirmed <= s.metrics.opsReadiness ? 'Partner confirmation' : 'Logistics',
    strongest: 'Programme readiness (91%)', weakest: dr[0][0], forecast: s.metrics.forecast, action: top ? actionsFor(top.id)[0]?.title ?? 'Escalate' : 'Run T-3 verification' };
}
export const followUpTemplate = (p: Partner, s: AppState) =>
  `Hi ${p.contact}, quick follow-up on ${p.name}'s participation in ${s.event.name}. We're at ${s.registrations} registrations and finalising the sponsor showcase this week. Could we lock your confirmation by Friday? Happy to share the benefit deck and a 15-min call slot.`;

export type AiTask = 'risk-explanation' | 'follow-up' | 'plan' | 'management-summary' | 'recovery-ranking';
/** Calls /api/ai (Claude). Falls back to the deterministic result — never throws, never blocks the UI. */
export async function enhance<T>(task: AiTask, context: unknown, fallback: T): Promise<{ data: T; mode: 'claude' | 'demo' }> {
  try {
    const res = await fetch('/api/ai', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ task, context }) });
    const j = await res.json();
    if (j.mode === 'claude' && j.data) return { data: j.data as T, mode: 'claude' };
  } catch { /* demo mode */ }
  return { data: fallback, mode: 'demo' };
}
export const riskExplanation = (r: Risk) => ({ what: r.explanation.what, why: r.explanation.why, impact: r.impact });
