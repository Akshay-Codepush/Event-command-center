'use client';
import { useState } from 'react';
import { useEvent } from '@/hooks/use-event';
import { MILESTONES } from '@/data/demo-data';
import { ROLES } from '@/types/event';
import { Btn, Card, due } from '@/components/ui';

export default function Tasks() {
  const { s, openDrawer, completeTask } = useEvent();
  const [f, setF] = useState<Record<string, string>>({});
  const lead = ['Event Lead', 'Leadership'].includes(s.role);
  const rows = s.tasks.filter((t) => (lead || t.role === s.role) && (!f.role || t.role === f.role) && (!f.pri || t.priority === f.pri) && (!f.st || t.status === f.st)
    && (!f.ms || t.milestoneId === f.ms) && (!f.risk || (f.risk === 'y' ? t.riskId : !t.riskId)));
  const Sel = ({ k, label, opts }: { k: string; label: string; opts: string[] }) => <select aria-label={label} value={f[k] ?? ''} onChange={(e) => setF({ ...f, [k]: e.target.value })}><option value="">{label}</option>{opts.map((o) => <option key={o}>{o}</option>)}</select>;
  return (
    <Card title="Task control centre" right={<span>{rows.length} tasks</span>}>
      <div className="mb-3 flex flex-wrap gap-2"><Sel k="role" label="Role" opts={ROLES.slice(1)} /><Sel k="pri" label="Priority" opts={['Critical', 'High', 'Medium', 'Low']} />
        <Sel k="st" label="Status" opts={['Not Started', 'In Progress', 'Blocked', 'Completed']} /><Sel k="ms" label="Milestone" opts={MILESTONES.map((m) => m.id)} />
        <select aria-label="Risk linked" value={f.risk ?? ''} onChange={(e) => setF({ ...f, risk: e.target.value })}><option value="">Risk linked</option><option value="y">Linked</option><option value="n">Not linked</option></select><Btn onClick={() => setF({})}>Clear</Btn></div>
      <div className="overflow-x-auto"><table className="w-full"><thead><tr className="text-left text-[10px] uppercase tracking-wider text-mu">{['Task', 'Role', 'Priority', 'Due', 'Status', 'Risk', 'Owner', ''].map((h) => <th key={h} className="border-b border-bd p-2">{h}</th>)}</tr></thead>
        <tbody>{rows.map((t) => <tr key={t.id} tabIndex={0} onKeyDown={(e) => e.key === 'Enter' && openDrawer({ kind: 'task', id: t.id })} onClick={() => openDrawer({ kind: 'task', id: t.id })} className="cursor-pointer hover:bg-p2">
          <td className="border-b border-bd p-2"><b>{t.title}</b><div className="text-xs text-mu">{t.id} · {t.milestoneId}</div></td><td className="border-b border-bd p-2">{t.role}</td>
          <td className={`border-b border-bd p-2 ${t.priority === 'Critical' ? 'text-crit' : t.priority === 'High' ? 'text-warn' : ''}`}>{t.priority}</td>
          <td className="border-b border-bd p-2">{t.status === 'Completed' ? '—' : due(t.dueInDays)}</td>
          <td className={`border-b border-bd p-2 ${t.status === 'Blocked' ? 'text-crit' : t.status === 'Completed' ? 'text-ok' : ''}`}>{t.status}</td>
          <td className="border-b border-bd p-2 text-info">{t.riskId ? s.riskNames[t.riskId] ?? t.riskId : '—'}</td><td className="border-b border-bd p-2">{t.owner}</td>
          <td className="border-b border-bd p-2">{t.status !== 'Completed' && <Btn variant="success" onClick={(e) => { e.stopPropagation(); completeTask(t.id); }}>Complete</Btn>}</td></tr>)}
          {!rows.length && <tr><td colSpan={8} className="p-6 text-center text-mu">No tasks match these filters.</td></tr>}</tbody></table></div>
    </Card>);
}
