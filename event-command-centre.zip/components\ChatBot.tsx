"use client";
import { useState, useRef, useEffect } from "react";

type Msg = { role: "user" | "assistant"; content: string };

// NEW: reads the text currently shown on the page
function getPageContext() {
const clone = document.body.cloneNode(true) as HTMLElement;
clone.querySelectorAll("script, style, #chatbot-root").forEach((el) => el.remove());
return (clone.textContent || "").replace(/\s+/g, " ").trim().slice(0, 8000);
}

export default function ChatBot() {
const [open, setOpen] = useState(false);
const [messages, setMessages] = useState<Msg[]>([
    { role: "assistant", content: "Hi! Ask me anything about your event." },
]);
const [input, setInput] = useState("");
const [loading, setLoading] = useState(false);
const bottomRef = useRef<HTMLDivElement>(null);

useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
}, [messages, loading, open]);

async function sendMessage() {
    const text = input.trim();
    if (!text || loading) return;

    const newMessages: Msg[] = [...messages, { role: "user", content: text }];
    setMessages(newMessages);
    setInput("");
    setLoading(true);

    try {
    const toSend = newMessages.slice(1);
    const res = await fetch("/api/ai/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        // CHANGED: now also sends the page text as "context"
        body: JSON.stringify({ messages: toSend, context: getPageContext() }),
    });
    if (!res.ok) throw new Error("Server returned " + res.status);
    const data = await res.json();
    setMessages([...newMessages, { role: "assistant", content: data.reply }]);
    } catch (e) {
    setMessages([
        ...newMessages,
        { role: "assistant", content: "Error: " + (e as Error).message },
    ]);
    }
    setLoading(false);
}

return (
    // CHANGED: added id="chatbot-root"
    <div id="chatbot-root" style={{ position: "fixed", bottom: 20, right: 20, zIndex: 50 }}>
    {open && (
        <div
        style={{
            width: 340,
            height: 420,
            marginBottom: 12,
            display: "flex",
            flexDirection: "column",
            background: "var(--pn)",
            color: "var(--tx)",
            border: "1px solid var(--bd)",
            borderRadius: 12,
            overflow: "hidden",
            boxShadow: "0 8px 30px rgba(0,0,0,0.35)",
        }}
        >
        <div style={{ padding: "10px 12px", borderBottom: "1px solid var(--bd)", fontWeight: 700 }}>
            Event Assistant
        </div>

        <div style={{ flex: 1, overflowY: "auto", padding: 10, display: "flex", flexDirection: "column", gap: 8 }}>
            {messages.map((m, i) => (
            <div
                key={i}
                style={{
                alignSelf: m.role === "user" ? "flex-end" : "flex-start",
                maxWidth: "85%",
                padding: "8px 10px",
                borderRadius: 10,
                background: m.role === "user" ? "var(--b)" : "var(--p2)",
                color: m.role === "user" ? "#fff" : "var(--tx)",
                whiteSpace: "pre-wrap",
                fontSize: 14,
                }}
            >
                {m.content}
            </div>
            ))}
            {loading && (
            <div style={{ color: "var(--mu)", fontSize: 13 }}>
                <i>Assistant is typing...</i>
            </div>
            )}
            <div ref={bottomRef} />
        </div>

        <div style={{ display: "flex", gap: 6, padding: 8, borderTop: "1px solid var(--bd)" }}>
            <input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && sendMessage()}
            placeholder="Ask something..."
            style={{ flex: 1 }}
            />
            <button
            onClick={sendMessage}
            disabled={loading}
            style={{
                padding: "0 14px",
                borderRadius: 6,
                border: "none",
                background: "var(--b)",
                color: "#fff",
                cursor: "pointer",
            }}
            >
            Send
            </button>
        </div>
        </div>
    )}

    <button
        onClick={() => setOpen(!open)}
        aria-label="Toggle chat"
        style={{
        float: "right",
        width: 52,
        height: 52,
        borderRadius: "50%",
        border: "none",
        background: "var(--b)",
        color: "#fff",
        fontSize: 22,
        cursor: "pointer",
        boxShadow: "0 4px 14px rgba(0,0,0,0.35)",
        }}
    >
        {open ? "✕" : "💬"}
    </button>
    </div>
);
}