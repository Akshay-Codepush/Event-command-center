'use client';
import { useState } from 'react';
import { useEvent } from '@/hooks/use-event';
import { enhance, managementSummary } from '@/lib/ai';
import { buildBrief } from '@/lib/brief';
import { departmentReadiness } from '@/lib/metrics';
import { Badge, Bar, Btn, Card, toneText } from '@/components/ui';
import { Bars, Trend } from '@/components/charts';

export default function Analytics() {
  const { s } = useEvent(); const [ai, setAi] = useState<{ narrative: string; mode: 'claude' | 'demo' } | null>(null); const ms = managementSummary(s), rd = departmentReadiness(s, s.metrics), delta = s.healthHistory.at(-1)! - s.healthHistory[0];
  const rows: [string, string][] = [['EVENT STATUS', ms.status], ['TOP PRIORITY', ms.topPriority], ['BIGGEST BLOCKER', ms.blocker], ['STRONGEST AREA', ms.strongest], ['FORECAST', `${ms.forecast} registrations`], ['RECOMMENDED MANAGEMENT ACTION', ms.action]];
  return (<>
    <Card title="Management summary" right={<Badge tone={ai?.mode === 'claude' ? 'ok' : 'warn'}>{ai?.mode === 'claude' ? 'CLAUDE' : 'DEMO INTELLIGENCE'}</Badge>}><div className="grid gap-x-6 gap-y-1.5 text-xs md:grid-cols-2">{rows.map(([k, v]) => <div key={k}>{k}: <b className={k === 'EVENT STATUS' ? toneText[s.health.tone] : ''}>{v}</b></div>)}</div>
      <div className="mt-3 flex flex-wrap items-start gap-2"><Btn onClick={() => { const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([buildBrief(s)], { type: 'text/markdown' })); a.download = 'management-brief.md'; a.click(); }}>Download brief (.md)</Btn><Btn onClick={async () => { const r = await enhance<{ narrative: string }>('management-summary', { summary: ms, metrics: s.metrics, health: s.health, risks: s.risks.map((x) => ({ type: x.type, severity: x.severity })) }, { narrative: '' }); setAi({ narrative: r.data.narrative, mode: r.mode }); }}>Refresh summary with AI</Btn>
        {ai && <p className="max-w-2xl text-xs">{ai.narrative || 'Demo Intelligence Mode: add ANTHROPIC_API_KEY for a written narrative. The structured summary above is always live.'}</p>}</div></Card>
    <div className="grid gap-3.5 md:grid-cols-2">
      <Card title="Health score over time"><Trend values={s.healthHistory} /></Card><Card title="Risk count over time"><Trend values={s.riskHistory} color="var(--r)" /></Card>
      <Card title="Registration velocity"><Bars values={s.velocity} /></Card>
      <Card title="Department readiness">{Object.entries(rd).map(([k, v]) => <div key={k} className="mb-2 grid grid-cols-[100px_1fr_40px] items-center gap-2 text-xs"><span>{k}</span><Bar value={v} /><b>{v}%</b></div>)}</Card></div>
    <Card title="Recovery effectiveness"><div className="text-xs">{s.tasks.filter((t) => t.applied && t.milestoneId === 'RECOVERY').length} recovery tasks completed · net health change since start: <b className={delta >= 0 ? 'text-ok' : 'text-crit'}>{delta >= 0 ? '+' : ''}{delta}</b></div></Card></>);
}
