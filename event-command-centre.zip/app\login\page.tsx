"use client";
import { useState, type FormEvent } from "react";
import { useRouter } from "next/navigation";
import { login, signUp, USING_SUPABASE, DEMO_USERS } from "@/lib/session";

export default function LoginPage() {
const router = useRouter();
const [mode, setMode] = useState<"signin" | "signup">("signin");
const [email, setEmail] = useState("");
const [password, setPassword] = useState("");
const [error, setError] = useState("");
const [busy, setBusy] = useState(false);

async function go(e: string, p: string, createFirst = false) {
    setError("");
    setBusy(true);
    if (createFirst) {
    const r = await signUp(e, p);
    if (r.error) {
        setError(r.error);
        setBusy(false);
        return;
    }
    }
    const res = await login(e, p);
    setBusy(false);
    if (!res.user) {
    setError(res.error ?? "Login failed.");
    return;
    }
    router.push(res.user.role === "manager" ? "/" : "/attendee");
}

function submit(ev: FormEvent) {
    ev.preventDefault();
    void go(email, password, mode === "signup");
}

const btn = {
    padding: "10px 14px",
    borderRadius: 8,
    border: "none",
    background: "var(--b)",
    color: "#fff",
    cursor: "pointer",
    fontWeight: 600,
} as const;

const ghost = {
    ...btn,
    background: "var(--p2)",
    color: "var(--tx)",
    border: "1px solid var(--bd)",
} as const;

return (
    <div style={{ minHeight: "100vh", display: "grid", placeItems: "center", padding: 16 }}>
    <form
        onSubmit={submit}
        style={{
        width: "100%",
        maxWidth: 380,
        background: "var(--pn)",
        border: "1px solid var(--bd)",
        borderRadius: 14,
        padding: 24,
        display: "flex",
        flexDirection: "column",
        gap: 12,
        }}
    >
        <h1 style={{ fontSize: 22, fontWeight: 800 }}>Event Command Centre</h1>
        <p style={{ color: "var(--mu)", fontSize: 14 }}>
        {mode === "signin" ? "Sign in to continue" : "Create a viewer account"}
        </p>

        <input
        type="email"
        placeholder="Email"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
        style={{ width: "100%" }}
        />
        <input
        type="password"
        placeholder="Password (min 6 characters)"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
        style={{ width: "100%" }}
        />

        {error && <p style={{ color: "var(--r)", fontSize: 13 }}>{error}</p>}

        <button type="submit" disabled={busy} style={btn}>
        {busy ? "Please wait..." : mode === "signin" ? "Sign in" : "Create account"}
        </button>

        {USING_SUPABASE && (
        <button
            type="button"
            style={ghost}
            onClick={() => {
            setError("");
            setMode(mode === "signin" ? "signup" : "signin");
            }}
        >
            {mode === "signin" ? "New here? Create a viewer account" : "Back to sign in"}
        </button>
        )}

        {!USING_SUPABASE && (
        <div style={{ borderTop: "1px solid var(--bd)", paddingTop: 12, display: "flex", flexDirection: "column", gap: 8 }}>
            <span style={{ color: "var(--mu)", fontSize: 12 }}>Quick demo login</span>
            <button type="button" style={ghost} onClick={() => void go(DEMO_USERS[0].email, DEMO_USERS[0].password)}>
            Login as Manager
            </button>
            <button type="button" style={ghost} onClick={() => void go(DEMO_USERS[1].email, DEMO_USERS[1].password)}>
            Login as Viewer
            </button>
        </div>
        )}

        <span style={{ color: "var(--mu)", fontSize: 11, textAlign: "center" }}>
        {USING_SUPABASE ? "Secured by Supabase authentication" : "Demo mode (no Supabase keys found)"}
        </span>
    </form>
    </div>
);
}