'use client';
import { useEvent } from '@/hooks/use-event';
import { SCENARIOS } from '@/lib/simulation';
import { Btn, Card, SevBadge, toneText } from '@/components/ui';

export default function Simulation() {
  const { s, runScenario, randomScenario, setInput, openDrawer } = useEvent();
  const Slider = ({ label, k, min, max, v }: { label: string; k: Parameters<typeof setInput>[0]; min: number; max: number; v: number }) =>
    <label className="grid gap-1 text-xs"><span className="flex"><span>{label}</span><b className="ml-auto">{v}</b></span><input type="range" min={min} max={max} defaultValue={v} key={v} onMouseUp={(e) => setInput(k, +e.currentTarget.value)} onTouchEnd={(e) => setInput(k, +e.currentTarget.value)} onKeyUp={(e) => setInput(k, +e.currentTarget.value)} aria-label={label} className="w-full p-0" /></label>;
  return (<>
    <Card title="Simulation lab — change conditions, watch the intelligence react"><div className="flex flex-wrap gap-2">{SCENARIOS.map((x) =>
      <Btn key={x.id} variant={x.id === 'recovery' ? 'success' : x.id === 'normal' ? 'default' : 'primary'} onClick={() => runScenario(x.id)}>{x.label}</Btn>)}<Btn onClick={randomScenario}>Generate New Scenario</Btn></div></Card>
    <Card title="Controls"><div className="grid gap-4 md:grid-cols-2">
      <Slider label="Registrations" k="reg" min={300} max={900} v={s.registrations} /><Slider label="Partner confirmations %" k="partners" min={20} max={100} v={s.partnerConfirmed} />
      <Slider label="Attendance conversion %" k="conv" min={40} max={100} v={Math.round(s.conversion)} /><Slider label="Logistics (Transport) readiness %" k="transport" min={10} max={100} v={s.categories.Transport} />
      <Slider label="Tasks completed (baseline)" k="tasks" min={10} max={44} v={s.baseline.done} /><Slider label="Marketing campaign performance (reg/day)" k="velocity" min={2} max={60} v={s.velocity.at(-1)!} /></div></Card>
    <div className="grid gap-3.5 md:grid-cols-2"><Card title="Live health"><b className={`text-4xl ${toneText[s.health.tone]}`}>{s.health.score}</b> <span className="text-mu">{s.health.status}</span></Card>
      <Card title={`Active risks (${s.risks.length})`}>{s.risks.map((r) => <button key={r.id} onClick={() => openDrawer({ kind: 'risk', id: r.id })} className="mb-1 flex w-full items-center gap-2 text-left text-xs"><SevBadge severity={r.severity} />{r.type}</button>)}{!s.risks.length && <span className="text-ok">None</span>}</Card></div></>);
}
