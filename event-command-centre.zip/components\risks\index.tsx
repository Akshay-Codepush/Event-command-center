'use client';
import { useState } from 'react';
import type { Risk, RecoveryAction } from '@/types/risk';
import { ROLES } from '@/types/event';
import { useEvent } from '@/hooks/use-event';
import { actionsFor } from '@/lib/actions';
import { enhance, riskExplanation } from '@/lib/ai';
import { Badge, Btn, SevBadge } from '@/components/ui';
import { SEVERITY_META } from '@/lib/risk-engine';

export function ActionRow({ a }: { a: RecoveryAction }) {
  const { s, acceptAction, rejectAction, editAction, assignAction } = useEvent();
  const st = s.actionState[a.id];
  return (
    <div className="grid gap-1.5 border-t border-bd py-2">
      <div className="flex flex-wrap items-center gap-2"><b>{s.actionTitle[a.id] ?? a.title}</b>
        {st && <Badge tone={st === 'task' ? 'ok' : 'warn'}>{st === 'task' ? 'TASK CREATED' : 'REJECTED'}</Badge>}</div>
      <div className="text-xs text-mu">{a.description}</div>
      <div className="flex flex-wrap items-center gap-2 text-xs">
        <span>Impact <b>{a.impact}</b></span><span>Effort <b>{a.effort}</b></span>
        <select aria-label="Owner role" value={s.actionOwner[a.id] ?? a.ownerRole} onChange={(e) => assignAction(a.id, e.target.value as typeof ROLES[number])}>
          {ROLES.slice(1).map((r) => <option key={r}>{r}</option>)}</select>
        {!st && <>
          <Btn variant="primary" onClick={() => acceptAction(a.id, a.riskId)}>Accept &amp; Assign</Btn>
          <Btn onClick={() => { const t = prompt('Edit action', s.actionTitle[a.id] ?? a.title); if (t) editAction(a.id, t); }}>Edit</Btn>
          <Btn onClick={() => rejectAction(a.id)}>Reject</Btn></>}
      </div>
    </div>
  );
}

export function RiskCard({ r }: { r: Risk }) {
  const { openDrawer, acceptAction, s } = useEvent();
  const tone = SEVERITY_META[r.severity].tone;
  const next = actionsFor(r.id).find((a) => !s.actionState[a.id]);
  return (
    <div className={`mb-2 grid gap-1.5 rounded-md border border-bd border-l-4 bg-p2 p-3 ${tone === 'crit' ? 'border-l-crit' : tone === 'warn' ? 'border-l-warn' : 'border-l-info'}`}>
      <div className="flex flex-wrap items-center gap-2"><SevBadge severity={r.severity} /><b>{r.type}</b><span className="ml-auto text-xs text-mu">{r.status} · {r.detectedAt}</span></div>
      <div className="text-xs text-mu">{r.metric}: <b className="text-tx">{r.currentValue}</b> · threshold {r.threshold} · owner {r.assignedRole}</div>
      <div className="text-xs">{r.impact}</div>
      <div className="flex flex-wrap gap-2">
        <Btn onClick={() => openDrawer({ kind: 'risk', id: r.id })}>View Risk</Btn>
        <Btn variant="primary" disabled={!next} onClick={() => next && acceptAction(next.id, r.id)}>Accept Recovery</Btn>
        <Btn onClick={() => openDrawer({ kind: 'risk', id: r.id })}>Assign Action</Btn>
      </div>
    </div>
  );
}

const H4 = ({ children }: { children: React.ReactNode }) => <h4 className="mb-1 mt-4 text-[11px] uppercase tracking-widest text-mu">{children}</h4>;

export function RiskDrawerBody({ id }: { id: string }) {
  const { s } = useEvent();
  const r = s.risks.find((x) => x.id === id);
  const [ai, setAi] = useState<{ what: string; why: string; impact: string; mode: string } | null>(null);
  if (!r) return <div className="text-ok">This risk is resolved. ✔</div>;
  const base = ai ?? { ...riskExplanation(r), mode: 'demo' };
  return (
    <>
      <div className="flex items-center gap-2"><SevBadge severity={r.severity} /><span className="text-xs text-mu">{r.status} · detected {r.detectedAt}</span></div>
      <h2 className="my-1.5 text-lg font-semibold">{r.type}</h2>
      <div className="text-xs text-mu">{r.metric}: <b className="text-tx">{r.currentValue}</b> · threshold {r.threshold}</div>
      <H4>What happened?</H4><p>{base.what}</p>
      <H4>Why did it happen?</H4><p>{base.why}</p>
      <H4>What happens if nothing is done?</H4><p>{base.impact}</p>
      <Btn className="mt-2 text-xs" onClick={async () => { const x = await enhance('risk-explanation', { risk: r, metrics: s.metrics }, riskExplanation(r)); setAi({ ...x.data, mode: x.mode }); }}>
        Refresh explanation with AI</Btn> <Badge tone={base.mode === 'claude' ? 'ok' : 'warn'}>{base.mode === 'claude' ? 'CLAUDE' : 'DEMO INTELLIGENCE'}</Badge>
      <H4>What should we do now? · owner {r.assignedRole}</H4>
      {actionsFor(r.id).map((a) => <ActionRow key={a.id} a={a} />)}
    </>
  );
}
