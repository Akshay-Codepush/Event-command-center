import { NextResponse } from "next/server";
import { GoogleGenerativeAI } from "@google/generative-ai";

export async function POST(req: Request) {
try {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
    return NextResponse.json(
        { reply: "GEMINI_API_KEY is missing in .env.local" },
        { status: 500 }
    );
    }

    const genAI = new GoogleGenerativeAI(apiKey);
    // CHANGED: also reads "context" sent from the chat widget
    const { messages, context } = await req.json();

    const model = genAI.getGenerativeModel({
    model: "gemini-3.8-flash",
      // CHANGED: the dashboard text is now part of the instructions
    systemInstruction: `You are the AI assistant for the Event Command Centre, a dashboard for managing events.
Keep answers short and practical.
Answer questions about the event using ONLY the dashboard data below. If the data doesn't contain the answer, say you can't see it. Never invent numbers.

CURRENT DASHBOARD DATA:
${context ?? "No data available."}`,
    });

    const contents = messages.map((m: { role: string; content: string }) => ({
    role: m.role === "assistant" ? "model" : "user",
    parts: [{ text: m.content }],
    }));

    const result = await model.generateContent({ contents });
    return NextResponse.json({ reply: result.response.text() });
} catch (err) {
    console.error("CHAT ERROR:", err);
    return NextResponse.json({ reply: "Something went wrong." }, { status: 500 });
}
}