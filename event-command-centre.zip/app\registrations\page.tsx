'use client';
import { useState } from 'react';
import { useEvent } from '@/hooks/use-event';
import { registrationSeries, todayIndex } from '@/lib/metrics';
import { AUDIENCE, SOURCES } from '@/data/demo-data';
import { Bar, Card } from '@/components/ui';
import { Bars, RegChart } from '@/components/charts';

export default function Registrations() {
  const { s } = useEvent(); const m = s.metrics; const [src, setSrc] = useState('All');
  const k = src === 'All' ? 1 : SOURCES.find((x) => x[0] === src)![1] / 100;
  const kp: [string, string | number][] = [['Total', Math.round(s.registrations * k)], ['Daily velocity', Math.round(s.velocity.at(-1)! * k)], ['Target', Math.round(s.event.targetRegistrations * k)],
    ['Gap', Math.round((s.registrations - s.event.targetRegistrations) * k)], ['Conversion', `${s.conversion.toFixed(0)}%`], ['Expected attendance', Math.round(m.attendance * k)]];
  return (<>
    <div className="grid grid-cols-[repeat(auto-fit,minmax(140px,1fr))] gap-2.5">{kp.map(([l, v]) => <div key={l} className="rounded-lg border border-bd bg-pn p-3"><div className="text-xs text-mu">{l}</div><b className="text-2xl">{v}</b></div>)}</div>
    <Card title="Target vs actual" right={<select aria-label="Source" value={src} onChange={(e) => setSrc(e.target.value)}>{['All', ...SOURCES.map((x) => x[0])].map((o) => <option key={o}>{o}</option>)}</select>}><RegChart data={registrationSeries(s, m, k)} today={todayIndex(m)} /></Card>
    <div className="grid gap-3.5 md:grid-cols-2">
      <Card title="Registration source">{SOURCES.map(([n, p]) => <div key={n} className="mb-2 grid grid-cols-[80px_1fr_40px] items-center gap-2 text-xs"><span>{n}</span><Bar value={p * 3} tone="info" /><b>{Math.round((s.registrations * p) / 100)}</b></div>)}</Card>
      <Card title="Audience type">{AUDIENCE.map(([n, p]) => <div key={n} className="mb-2 grid grid-cols-[90px_1fr_40px] items-center gap-2 text-xs"><span>{n}</span><Bar value={p * 2.4} tone="ok" /><b>{p}%</b></div>)}</Card>
      <Card title="Daily velocity (registrations/day)"><Bars values={s.velocity.slice(-10)} /></Card></div></>);
}
