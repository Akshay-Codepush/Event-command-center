'use client';
import { useEffect, useState } from 'react';
import { useEvent } from '@/hooks/use-event';
import { persistenceMode } from '@/lib/persistence';
import { Badge, Btn, Card } from '@/components/ui';
import { toggleTheme } from '@/lib/theme';

export default function SettingsPage() {
  const { reset } = useEvent(); const [ai, setAi] = useState<'claude' | 'demo' | '…'>('…');
  useEffect(() => { fetch('/api/ai').then((r) => r.json()).then((j) => setAi(j.mode)).catch(() => setAi('demo')); }, []);
  return (
    <Card title="Settings & integrations">
      <div className="mb-3 grid gap-1.5">
        <div>Intelligence: {ai === 'claude' ? <Badge tone="ok">CLAUDE ACTIVE</Badge> : <Badge tone="warn">DEMO INTELLIGENCE MODE</Badge>} <span className="text-xs text-mu">— rules, scoring and effects are always deterministic; Claude adds explanations, plan tasks, ranking and summaries.</span></div>
        <div>Persistence: <Badge tone={persistenceMode() === 'supabase' ? 'ok' : 'info'}>{persistenceMode() === 'supabase' ? 'SUPABASE' : 'BROWSER (localStorage)'}</Badge></div></div>
      <pre className="mb-3 overflow-auto rounded-md bg-p2 p-3 text-xs">{`ANTHROPIC_API_KEY=\nANTHROPIC_MODEL=claude-sonnet-5-5\nNEXT_PUBLIC_SUPABASE_URL=\nNEXT_PUBLIC_SUPABASE_ANON_KEY=`}</pre>
      <div className="flex gap-2"><Btn onClick={toggleTheme}>Toggle light/dark</Btn><Btn onClick={reset}>Reset Demo</Btn></div></Card>);
}
