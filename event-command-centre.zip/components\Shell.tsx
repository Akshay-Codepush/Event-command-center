'use client';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useState, type ReactNode } from 'react';
import { Bell, LayoutDashboard, Wand2, GanttChart, ListChecks, Users, Handshake, Settings2, ShieldAlert, RotateCcw, LineChart, FlaskConical, SlidersHorizontal, X } from 'lucide-react';
import { ROLES, type Role } from '@/types/event';
import { EventProvider, useEvent } from '@/hooks/use-event';
import { Badge, Btn, toneText } from '@/components/ui';
import { RiskDrawerBody } from '@/components/risks';
import { TaskDrawerBody } from '@/components/tasks';
import { FollowUpBody } from '@/components/partners';
import { DemoTour } from '@/components/DemoTour';
import { CommandPalette } from '@/components/CommandPalette';
import { Confetti } from '@/components/Confetti';
import { ROUTES } from '@/lib/routes';
import { toggleTheme } from '@/lib/theme';

const ICONS = { '/': LayoutDashboard, '/setup': Wand2, '/plan': GanttChart, '/tasks': ListChecks, '/registrations': Users, '/partners': Handshake, '/operations': Settings2, '/risks': ShieldAlert, '/actions': RotateCcw, '/analytics': LineChart, '/simulation': FlaskConical, '/settings': SlidersHorizontal } as const;
const NAV = ROUTES.map((r) => [r.href, r.label, ICONS[r.href]] as const);

function Frame({ children }: { children: ReactNode }) {
  const path = usePathname(); const { s, setRole, reset, randomScenario, drawer, closeDrawer, toast, markRead, setPalette } = useEvent();
  const [pop, setPop] = useState(false);
  const unread = s.notifications.filter((n) => n.unread).length;
  return (
    <div className="grid min-h-screen md:grid-cols-[208px_minmax(0,1fr)]">
      <nav aria-label="Main" className="flex overflow-x-auto border-b border-bd bg-pn p-2 md:sticky md:top-0 md:h-screen md:flex-col md:overflow-y-auto md:border-b-0 md:border-r">
        <div className="hidden px-2 pb-3 pt-1 md:block"><div className="text-xs font-bold tracking-widest">EVENT COMMAND CENTRE</div><div className="text-[10px] text-mu">AI Event Intelligence &amp; Decision Support</div></div>
        {NAV.map(([href, label, Icon]) => <Link key={href} href={href} aria-current={path === href ? 'page' : undefined}
          className={`flex items-center gap-2 whitespace-nowrap rounded-md px-2.5 py-1.5 ${path === href ? 'bg-p2 text-tx shadow-[inset_2px_0_var(--b)]' : 'text-mu hover:bg-p2 hover:text-tx'}`}>
          <Icon size={15} />{label}{href === '/risks' && s.risks.length > 0 && <span className="ml-auto rounded-full bg-crit px-1.5 text-[10px] text-white">{s.risks.length}</span>}</Link>)}
      </nav>
      <div className="min-w-0">
        <header className="sticky top-0 z-10 flex flex-wrap items-center gap-3 border-b border-bd bg-pn px-4 py-2">
          <b>{s.event.name}</b><span className="text-xs font-bold text-ok">LIVE</span><span className="text-mu">{s.metrics.daysLeft} days</span>
          <span>Health <b className={toneText[s.health.tone]}>{s.health.score}/100</b></span><span className="flex-1" />
          <Badge tone="warn">DEMO MODE</Badge>
          <label className="text-xs text-mu">Role <select aria-label="Role" value={s.role} onChange={(e) => setRole(e.target.value as Role)}>{ROLES.map((r) => <option key={r}>{r}</option>)}</select></label>
          <Btn onClick={() => setPalette(true)} aria-label="Open command palette"><kbd className="text-[10px] text-mu">⌘K</kbd> Commands</Btn><Btn onClick={toggleTheme} aria-label="Toggle light or dark theme">🌗</Btn><Btn onClick={randomScenario}>Generate New Scenario</Btn><Btn onClick={reset}>Reset Demo</Btn>
          <div className="relative"><Btn aria-label="Notifications" onClick={() => { if (pop) markRead(); setPop(!pop); }}><Bell size={14} className="inline" />{unread > 0 && <b className="ml-1 text-crit">{unread}</b>}</Btn>
            {pop && <div className="absolute right-0 top-9 z-20 max-h-96 w-80 overflow-auto rounded-lg border border-bd bg-pn p-1">{s.notifications.slice(0, 10).map((n) =>
              <Link key={n.id} href={n.href} onClick={() => { setPop(false); markRead(); }} className="block border-b border-bd p-2 hover:bg-p2"><span className={n.tone === 'critical' ? 'text-crit' : n.tone === 'ok' ? 'text-ok' : n.tone === 'warning' ? 'text-warn' : 'text-info'}>●</span> {n.text}</Link>)}</div>}</div>
        </header>
        <main className="grid max-w-[1500px] gap-3.5 p-4">{children}</main>
      </div>
      {drawer && <div role="dialog" aria-label="Details" className="slidein fixed inset-y-0 right-0 z-20 w-full overflow-auto border-l border-bd bg-pn p-5 shadow-2xl sm:w-[520px]">
        <Btn className="float-right" onClick={closeDrawer}><X size={14} className="inline" /> Close</Btn>
        {drawer.kind === 'risk' && <RiskDrawerBody id={drawer.id} />}{drawer.kind === 'task' && <TaskDrawerBody id={drawer.id} />}{drawer.kind === 'followup' && <FollowUpBody id={drawer.id} />}</div>}
      <DemoTour /><CommandPalette /><Confetti />
      {toast && <div role="status" className="slidein fixed bottom-5 left-1/2 z-30 max-w-[92vw] -translate-x-1/2 rounded-lg bg-tx px-4 py-2.5 text-bg shadow-2xl">{toast}</div>}
    </div>
  );
}
export const Shell = ({ children }: { children: ReactNode }) => <EventProvider><Frame>{children}</Frame></EventProvider>;
