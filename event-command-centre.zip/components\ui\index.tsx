import type { ReactNode, ButtonHTMLAttributes } from 'react';
import type { Severity } from '@/types/risk';
import { SEVERITY_META } from '@/lib/risk-engine';
import { dueDateLabel } from '@/lib/dates';

export type Tone = 'ok' | 'warn' | 'crit' | 'info' | 'mu';
export const toneText: Record<Tone, string> = { ok: 'text-ok', warn: 'text-warn', crit: 'text-crit', info: 'text-info', mu: 'text-mu' };
export const toneBg: Record<Tone, string> = { ok: 'bg-ok', warn: 'bg-warn', crit: 'bg-crit', info: 'bg-info', mu: 'bg-mu' };
export const pctTone = (v: number): Tone => (v >= 85 ? 'ok' : v >= 70 ? 'warn' : 'crit');

export function Card({ title, right, children, className = '' }: { title?: ReactNode; right?: ReactNode; children: ReactNode; className?: string }) {
  return (
    <section className={`rounded-lg border border-bd bg-pn p-4 ${className}`}>
      {title && <h3 className="mb-3 flex items-center justify-between text-[11px] font-semibold uppercase tracking-widest text-mu"><span>{title}</span>{right}</h3>}
      {children}
    </section>
  );
}
export function Badge({ tone = 'info', children }: { tone?: Tone; children: ReactNode }) {
  return <span className={`whitespace-nowrap rounded border border-current px-1.5 py-0.5 text-[10px] font-bold tracking-wider ${toneText[tone]}`}>{children}</span>;
}
export const SevBadge = ({ severity }: { severity: Severity }) => <Badge tone={SEVERITY_META[severity].tone}>{SEVERITY_META[severity].label}</Badge>;
export function Btn({ variant = 'default', className = '', ...p }: ButtonHTMLAttributes<HTMLButtonElement> & { variant?: 'default' | 'primary' | 'success' }) {
  const v = { default: 'bg-p2 border-bd hover:border-info', primary: 'btn-primary bg-info border-info text-white font-semibold', success: 'bg-ok border-ok text-black' }[variant];
  return <button {...p} className={`rounded-md border px-2.5 py-1.5 transition-colors ${v} ${className}`} />;
}
export function Bar({ value, tone }: { value: number; tone?: Tone }) {
  const t = tone ?? pctTone(value);
  return <div className="h-1.5 overflow-hidden rounded bg-bd" role="progressbar" aria-valuenow={Math.round(value)} aria-valuemin={0} aria-valuemax={100}><div className={`h-full transition-all duration-500 ${toneBg[t]}`} style={{ width: `${Math.max(0, Math.min(100, value))}%` }} /></div>;
}
export const Empty = ({ children }: { children: ReactNode }) => <div className="py-6 text-center text-mu">{children}</div>;
export const due = (d: number) => <>{d < 0 ? <span className="text-crit">{-d}d overdue</span> : d === 0 ? <b className="text-warn">Today</b> : <>in {d}d</>}<span className="block text-[10px] text-mu">{dueDateLabel(d)}</span></>;
