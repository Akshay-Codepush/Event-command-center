export const ROUTES = [
  { href: '/', label: 'Overview' }, { href: '/setup', label: 'Event Setup' }, { href: '/plan', label: 'Plan & Milestones' }, { href: '/tasks', label: 'Tasks' },
  { href: '/registrations', label: 'Registrations' }, { href: '/partners', label: 'Partners' }, { href: '/operations', label: 'Operations' }, { href: '/risks', label: 'Risks' },
  { href: '/actions', label: 'Recovery Actions' }, { href: '/analytics', label: 'Analytics' }, { href: '/simulation', label: 'Simulation' }, { href: '/settings', label: 'Settings' },
] as const;
