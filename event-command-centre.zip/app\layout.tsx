import ChatBot from "@/components/ChatBot";
import AuthGate from "@/components/AuthGate";
import type { Metadata, Viewport } from 'next';
import type { ReactNode } from 'react';
import './globals.css';

export const metadata: Metadata = { title: 'Event Command Centre', description: 'AI-powered Event Intelligence & Decision Support System' };
export const viewport: Viewport = { width: 'device-width', initialScale: 1, viewportFit: 'cover' };
const restoreTheme = `try{var t=localStorage.getItem('ecc-theme');if(t)document.documentElement.dataset.theme=t}catch(e){}`;

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head><script dangerouslySetInnerHTML={{ __html: restoreTheme }} /></head>
      <body>
        <AuthGate>{children}</AuthGate>
        <ChatBot />
      </body>
    </html>
  );
}