'use client';
import { useState } from 'react';
import { useEvent } from '@/hooks/use-event';
import { actionsFor } from '@/lib/actions';
import { enhance } from '@/lib/ai';
import { Badge, Btn, Card, Empty, SevBadge } from '@/components/ui';
import { ActionRow } from '@/components/risks';

interface Rank { order: string[]; rationale: string; mode: 'claude' | 'demo' }

export default function Actions() {
  const { s } = useEvent();
  const [ranks, setRanks] = useState<Record<string, Rank>>({});
  const rank = async (riskId: string) => {
    const acts = actionsFor(riskId);
    const r = await enhance<{ order: string[]; rationale: string }>('recovery-ranking', { risk: s.risks.find((x) => x.id === riskId), actions: acts.map((a) => ({ id: a.id, title: a.title, impact: a.impact, effort: a.effort })) },
      { order: acts.map((a) => a.id), rationale: '' });
    const valid = r.data.order?.length === acts.length && acts.every((a) => r.data.order.includes(a.id));
    setRanks((p) => ({ ...p, [riskId]: { order: valid ? r.data.order : acts.map((a) => a.id), rationale: r.data.rationale ?? '', mode: valid ? r.mode : 'demo' } }));
  };
  return <Card title="Recovery action centre">{s.risks.length ? s.risks.map((r) => {
    const rk = ranks[r.id], acts = actionsFor(r.id).sort((a, b) => (rk ? rk.order.indexOf(a.id) - rk.order.indexOf(b.id) : 0));
    return (
      <div key={r.id} className="mb-3 rounded-md border border-bd bg-p2 p-3"><div className="mb-1 flex flex-wrap items-center gap-2"><SevBadge severity={r.severity} /><b>{r.type}</b>
        <Btn className="ml-auto text-xs" onClick={() => rank(r.id)}>Re-rank with AI</Btn>{rk && <Badge tone={rk.mode === 'claude' ? 'ok' : 'warn'}>{rk.mode === 'claude' ? 'CLAUDE' : 'DEMO INTELLIGENCE'}</Badge>}</div>
        {rk?.rationale && <p className="mb-1 text-xs text-mu">{rk.rationale}</p>}
        {acts.map((a) => <ActionRow key={a.id} a={a} />)}</div>);
  }) : <Empty>No recovery needed ✔</Empty>}</Card>;
}
