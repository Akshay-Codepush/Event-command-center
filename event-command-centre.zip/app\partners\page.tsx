'use client';
import { useEvent } from '@/hooks/use-event';
import { STAGES } from '@/types/partner';
import { Btn, Card } from '@/components/ui';

export default function Partners() {
  const { s, openDrawer } = useEvent();
  return (<>
    <div className="grid grid-cols-[repeat(auto-fit,minmax(120px,1fr))] gap-2.5">{STAGES.map((st) => <div key={st} className="rounded-lg border border-bd bg-pn p-3"><div className="text-xs text-mu">{st}</div><b className="text-2xl">{s.partners.filter((p) => p.status === st).length}</b></div>)}</div>
    <Card title="Partner pipeline" right={<span>{s.partnerConfirmed}% confirmed</span>}><div className="overflow-x-auto"><table className="w-full"><thead><tr className="text-left text-[10px] uppercase tracking-wider text-mu">{['Partner', 'Type', 'Status', 'Last contact', 'Next follow-up', 'Probability', ''].map((h) => <th key={h} className="border-b border-bd p-2">{h}</th>)}</tr></thead>
      <tbody>{s.partners.map((p) => <tr key={p.id}><td className="border-b border-bd p-2"><b>{p.name}</b></td><td className="border-b border-bd p-2">{p.type}</td><td className="border-b border-bd p-2">{p.status}</td><td className="border-b border-bd p-2">{p.lastContact}d ago</td>
        <td className="border-b border-bd p-2">{p.nextFollowUp < 0 ? <span className="text-crit">{-p.nextFollowUp}d overdue</span> : p.nextFollowUp === 0 ? <b className="text-warn">TODAY</b> : `in ${p.nextFollowUp}d`}</td><td className="border-b border-bd p-2">{p.confirmationProbability}%</td>
        <td className="border-b border-bd p-2">{!['Confirmed', 'Dropped'].includes(p.status) && <Btn onClick={() => openDrawer({ kind: 'followup', id: p.id })}>Generate Follow-up</Btn>}</td></tr>)}</tbody></table></div></Card></>);
}
