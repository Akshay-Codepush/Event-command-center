'use client';
import { useEvent } from '@/hooks/use-event';
import { MILESTONES } from '@/data/demo-data';
import { Badge, Card } from '@/components/ui';

export default function Plan() {
  const { s, openDrawer } = useEvent();
  return (
    <Card title="AI-generated operating plan">{MILESTONES.map((m) => {
      const ts = s.tasks.filter((t) => t.milestoneId === m.id), done = ts.filter((t) => t.status === 'Completed').length;
      const flag = m.id === 'T-7' && s.registrations / s.event.targetRegistrations < 0.9 ? <Badge tone="warn">BEHIND TARGET</Badge> : m.id === 'T-14' && s.partnerConfirmed < 80 ? <Badge tone="warn">{s.partnerConfirmed}% / 80%</Badge> : null;
      return <details key={m.id} open={ts.length > 0} className="mb-1.5 rounded-md border border-bd bg-p2 p-2.5"><summary className="cursor-pointer font-semibold">{m.label} — {m.title} {flag} <span className="text-xs font-normal text-mu">{done}/{ts.length} tasks</span></summary>
        {ts.map((t) => <button key={t.id} onClick={() => openDrawer({ kind: 'task', id: t.id })} className="mt-1 block w-full text-left text-xs">{t.status === 'Completed' ? <span className="text-ok">✔</span> : '○'} {t.title} <span className="text-mu">· {t.role}</span></button>)}
        {!ts.length && <div className="mt-1 text-xs text-mu">Baseline tasks complete or scheduled.</div>}</details>;
    })}</Card>);
}
