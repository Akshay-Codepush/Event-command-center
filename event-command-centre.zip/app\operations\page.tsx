'use client';
import { useEvent } from '@/hooks/use-event';
import { Badge, Bar, Card, pctTone, toneText } from '@/components/ui';

export default function Operations() {
  const { s } = useEvent(); const ops = s.metrics.opsReadiness;
  return (<>
    <div className="w-fit rounded-lg border border-bd bg-pn p-3"><div className="text-xs text-mu">Operations readiness</div><b className={`text-3xl ${toneText[pctTone(ops)]}`}>{ops}%</b></div>
    <Card title="Logistics readiness">{Object.entries(s.categories).map(([k, v]) => <div key={k} className="mb-3"><div className="mb-1 flex items-center gap-2 text-xs"><b>{k}</b><span className="text-mu">Owner: Operations</span>{v < 70 && <Badge tone="warn">BLOCKER</Badge>}<b className={`ml-auto ${toneText[pctTone(v)]}`}>{v}%</b></div><Bar value={v} /></div>)}</Card></>);
}
