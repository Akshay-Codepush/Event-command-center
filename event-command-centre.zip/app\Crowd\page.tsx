"use client";
import { useState } from "react";
import { useCrowd, saveZone } from "@/lib/useCrowd";
import { USING_SUPABASE } from "@/lib/session";

const ZONES = [
{ id: "gate", label: "Main Gate" },
{ id: "stage", label: "Open Air Theatre" },
{ id: "stalls", label: "Stall Lawn" },
{ id: "food", label: "Food Court" },
{ id: "canteen", label: "Canteen" },
{ id: "sports", label: "Sports Grounds" },
{ id: "parking", label: "Parking" },
];

const START: Record<string, number> = { gate: 72, stage: 88, stalls: 64, food: 80, canteen: 55, sports: 25, parking: 45 };

const SCENARIOS: { name: string; values: Record<string, number> }[] = [
{ name: "🌅 Quiet morning", values: { gate: 25, stage: 10, stalls: 15, food: 10, canteen: 10, sports: 20, parking: 30 } },
{ name: "🎤 Keynote rush", values: { gate: 40, stage: 95, stalls: 30, food: 25, canteen: 20, sports: 15, parking: 50 } },
{ name: "🍔 Lunch rush", values: { gate: 30, stage: 25, stalls: 45, food: 95, canteen: 90, sports: 20, parking: 40 } },
{ name: "🚪 Closing exit rush", values: { gate: 96, stage: 30, stalls: 35, food: 40, canteen: 30, sports: 15, parking: 92 } },
];

function level(d: number) {
if (d < 40) return { text: "Low", color: "#22c55e" };
if (d < 70) return { text: "Medium", color: "#facc15" };
return { text: "High", color: "#ef4444" };
}

export default function CrowdControlPage() {
const { density, setDensity } = useCrowd(START);
const [msg, setMsg] = useState("");

async function save(id: string, value: number) {
    const r = await saveZone(id, value);
    setMsg(r.error ? "Could not save: " + r.error : "Saved. Viewers see this live.");
}

async function applyScenario(values: Record<string, number>) {
    setDensity((d) => ({ ...d, ...values }));
    const results = await Promise.all(Object.entries(values).map(([id, v]) => saveZone(id, v)));
    const failed = results.find((r) => r.error);
    setMsg(failed ? "Could not save: " + failed.error : "Scenario applied. Viewers see this live.");
}

const pill = {
    padding: "8px 12px",
    borderRadius: 999,
    border: "1px solid var(--bd)",
    background: "var(--p2)",
    color: "var(--tx)",
    cursor: "pointer",
    fontSize: 13,
    fontWeight: 600,
} as const;

return (
    <div style={{ maxWidth: 760, margin: "0 auto", padding: 16 }}>
    <h1 style={{ fontSize: 24, fontWeight: 800 }}>Crowd Control</h1>
    <p style={{ color: "var(--mu)", fontSize: 14, margin: "4px 0 14px" }}>
        Set the crowd level of each zone. Attendees see the change live on their heat map.
        In a real event, entry scanners or sensors would write these numbers.
    </p>

    {!USING_SUPABASE && (
        <p style={{ color: "var(--r)", fontSize: 14 }}>Supabase keys not found, so changes will not be shared.</p>
    )}

    <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginBottom: 14 }}>
        {SCENARIOS.map((s) => (
        <button key={s.name} style={pill} onClick={() => void applyScenario(s.values)}>
            {s.name}
        </button>
        ))}
    </div>

    <div style={{ background: "var(--pn)", border: "1px solid var(--bd)", borderRadius: 12, padding: 14 }}>
        {ZONES.map((z) => {
        const d = density[z.id] ?? 0;
        const lv = level(d);
        return (
            <div key={z.id} style={{ display: "flex", alignItems: "center", gap: 10, margin: "12px 0", fontSize: 14 }}>
            <span style={{ width: 130 }}>{z.label}</span>
            <input
                type="range"
                min={0}
                max={100}
                value={d}
                onChange={(e) => setDensity((prev) => ({ ...prev, [z.id]: Number(e.target.value) }))}
                onPointerUp={() => void save(z.id, d)}
                onKeyUp={() => void save(z.id, d)}
                style={{ flex: 1, padding: 0 }}
            />
            <span style={{ width: 96, textAlign: "right", color: lv.color, fontWeight: 700 }}>
                {lv.text} {d}%
            </span>
            </div>
        );
        })}
    </div>

    {msg && <p style={{ marginTop: 10, fontSize: 13, color: "var(--mu)" }}>{msg}</p>}
    </div>
);
}