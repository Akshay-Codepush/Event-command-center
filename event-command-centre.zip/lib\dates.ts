/** Demo "today". The event is 12 days away from here, matching the product brief. */
export const DEMO_TODAY = '2026-10-09';
const DAY = 864e5;
export const daysUntil = (date: string) => Math.max(0, Math.round((Date.parse(date) - Date.parse(DEMO_TODAY)) / DAY));
export const dueDateLabel = (offset: number) =>
  new Date(Date.parse(DEMO_TODAY) + offset * DAY).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', timeZone: 'UTC' });
