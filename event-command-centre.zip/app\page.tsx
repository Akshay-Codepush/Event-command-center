'use client';
import { useEvent } from '@/hooks/use-event';
import { registrationSeries, todayIndex } from '@/lib/metrics';
import { Card, Empty } from '@/components/ui';
import { RegChart } from '@/components/charts';
import { RiskCard } from '@/components/risks';
import { Funnel, HealthPanel, InsightPanel, KpiGrid, LiveFeed, LoopStrip, RadarCard, RoleFocus, TeamReadiness } from '@/components/dashboard';

export default function Overview() {
  const { s } = useEvent(); const m = s.metrics;
  const lead = ['Event Lead', 'Leadership'].includes(s.role);
  const risks = lead ? s.risks : s.risks.filter((r) => r.assignedRole === s.role);
  return (
    <>
      <HealthPanel /><LoopStrip /><RoleFocus /><KpiGrid />
      <div className="grid gap-3.5 lg:grid-cols-[minmax(0,1fr)_320px]">
        <div className="grid min-w-0 gap-3.5">
          <Card title="Registration performance" right={<span className={m.gapPct <= -8 ? 'text-crit' : 'text-ok'}>{m.gapPct <= -8 ? `Registrations are ${Math.abs(m.gapPct).toFixed(1)}% below target` : 'On track'}</span>}>
            <RegChart data={registrationSeries(s, m)} today={todayIndex(m)} /></Card>
          <Card title={`Active risks (${risks.length})`}>{risks.length ? risks.map((r) => <RiskCard key={r.id} r={r} />) : <Empty>No active risks for this view ✔</Empty>}</Card>
          <div className="grid gap-3.5 md:grid-cols-2"><RadarCard /><LiveFeed /></div>
          <div className="grid gap-3.5 md:grid-cols-2"><Funnel /><TeamReadiness /></div>
        </div>
        <InsightPanel />
      </div>
    </>
  );
}
