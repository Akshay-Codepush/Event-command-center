'use client';
import Link from 'next/link';
import { useState } from 'react';
import { useEvent } from '@/hooks/use-event';
import { answer } from '@/lib/qa';
import { mood } from '@/lib/health-score';
import { Radar } from '@/components/charts';
import { buildInsights } from '@/lib/ai';
import { departmentReadiness, funnel } from '@/lib/metrics';
import { actionsFor } from '@/lib/actions';
import { Bar, Btn, Card, Badge, pctTone, toneText, type Tone } from '@/components/ui';

export function HealthPanel() {
  const { s } = useEvent(); const h = s.health, C = 2 * Math.PI * 54;
  return (
    <Card className="grid items-center gap-6 sm:grid-cols-[auto_1fr]">
      <div className="relative h-32 w-32">
        <svg viewBox="0 0 128 128" className="h-32 w-32 -rotate-90"><circle cx="64" cy="64" r="54" fill="none" stroke="var(--bd)" strokeWidth="10" />
          <circle cx="64" cy="64" r="54" fill="none" strokeLinecap="round" strokeWidth="10" className={toneText[h.tone]} stroke="currentColor" strokeDasharray={`${(h.score / 100) * C} ${C}`} style={{ transition: 'stroke-dasharray .6s' }} /></svg>
        <div className="absolute inset-0 grid place-content-center text-center"><b className="text-4xl leading-none">{h.score}</b><span className="text-xs text-mu">/ 100</span></div>
      </div>
      <div>
        <div className="flex items-center gap-2"><b className="text-xl">{s.event.name}</b><span title="Event mood" className="text-xl">{mood(h.score)}</span><span className="text-xs font-bold text-ok"><span className="livedot mr-1 inline-block h-2 w-2 rounded-full bg-ok" />LIVE</span></div>
        <div className="text-mu">{s.metrics.daysLeft} days to event · Event Health <b className={toneText[h.tone]}>{h.status}</b></div>
        <details className="mt-2 rounded-md border border-bd bg-p2 p-2"><summary className="cursor-pointer font-semibold">Why is the score {h.score}?</summary>
          <table className="mt-2 w-full"><tbody>{h.parts.map((p) => <tr key={p.label}><td>{p.label}</td><td className="text-right text-ok">+{Math.round(p.value)}</td></tr>)}
            <tr><td>Risk penalty ({s.risks.length} active)</td><td className="text-right text-crit">-{h.penalty.toFixed(1)}</td></tr></tbody></table></details>
      </div>
    </Card>
  );
}

export function LoopStrip() {
  const { s } = useEvent();
  const pending = s.risks.reduce((a, r) => a + actionsFor(r.id).filter((x) => !s.actionState[x.id]).length, 0);
  const open = s.tasks.filter((t) => t.riskId && t.status !== 'Completed').length;
  const step = (l: string, on: boolean) => <span key={l} className={`rounded border px-2 py-0.5 text-[11px] ${on ? 'border-info text-info' : 'border-bd bg-p2'}`}>{l}</span>;
  return (
    <Card><div className="flex flex-wrap gap-1">{[step('Data', true), step('Intelligence', true), step(`Risk · ${s.risks.length}`, !!s.risks.length), step('Explanation', !!s.risks.length),
      step(`Action · ${pending} pending`, !!pending), step(`Task · ${open} open`, !!open), step('Outcome', !!s.lastOutcome)]}</div>
      <div className={`mt-1.5 text-xs ${s.lastOutcome ? 'text-ok' : 'text-mu'}`}>{s.lastOutcome ? `Last outcome: ${s.lastOutcome}` : 'Accept a recovery action and complete its task to see the outcome here.'}</div></Card>
  );
}

export function KpiGrid() {
  const { s } = useEvent(); const m = s.metrics, crit = s.risks.filter((r) => r.severity === 'critical').length;
  const items: [string, string | number, string, string, Tone?][] = [
    ['Registrations', s.registrations, 'live', '/registrations'], ['Target', s.event.targetRegistrations, 'registrations', '/registrations'],
    ['Registration gap', s.registrations - s.event.targetRegistrations, `${m.gapPct.toFixed(1)}% vs target`, '/registrations', m.gapPct < -15 ? 'crit' : m.gapPct < -8 ? 'warn' : 'ok'],
    ['Attendance forecast', m.attendance, 'confirmed', '/registrations'], ['Partner confirm.', `${s.partnerConfirmed}%`, 'of sponsors', '/partners', s.partnerConfirmed < 70 ? 'warn' : 'ok'],
    ['Tasks completed', `${m.tasksDone} / ${m.tasksTotal}`, '', '/tasks'], ['Critical risks', crit, `${s.risks.length} active`, '/risks', crit ? 'crit' : 'ok'], ['Days remaining', m.daysLeft, 'to event day', '/plan'],
  ];
  return <div className="grid grid-cols-[repeat(auto-fit,minmax(135px,1fr))] gap-2.5">{items.map(([l, v, sub, href, tone]) =>
    <Link key={l} href={href} className="grid gap-0.5 rounded-lg border border-bd bg-pn p-3 hover:border-info"><span className="text-xs text-mu">{l}</span>
      <b className={`text-2xl tabular-nums ${tone ? toneText[tone] : ''}`}>{v}</b><small className="text-mu">{sub}</small></Link>)}</div>;
}

export function TeamReadiness() {
  const { s, setRole } = useEvent(); const rd = departmentReadiness(s, s.metrics);
  return <Card title="Team readiness">{Object.entries(rd).map(([k, v]) =>
    <button key={k} onClick={() => setRole(k as typeof s.role)} className="mb-2.5 block w-full text-left"><div className="mb-1 flex"><span>{k}</span><b className={`ml-auto ${toneText[pctTone(v)]}`}>{v}%</b></div><Bar value={v} /></button>)}</Card>;
}

export function Funnel() {
  const { s, flash } = useEvent(); const f = funnel(s, s.metrics);
  return <Card title="Event funnel">{f.map((x, i) => <button key={x.label} onClick={() => flash(`${x.label}: ${x.value.toLocaleString()}${i ? ` · ${((x.value / f[i - 1].value) * 100).toFixed(1)}% of previous stage` : ''}`)}
    className="grid w-full grid-cols-[130px_1fr_80px] items-center gap-2 py-1 text-left"><span className="text-xs">{x.label}</span><div className="h-3.5 rounded-sm bg-info/80" style={{ width: `${Math.max(4, (x.value / f[0].value) * 100)}%` }} /><span className="text-xs text-mu">{x.value.toLocaleString()}</span></button>)}</Card>;
}

export function InsightPanel() {
  const { s } = useEvent(); const i = buildInsights(s);
  return (
    <aside className="self-start rounded-lg border border-bd bg-pn p-4 lg:sticky lg:top-16">
      <h3 className="mb-3 flex items-center justify-between text-[11px] font-semibold uppercase tracking-widest text-mu">AI Event Intelligence <Badge tone="warn">DEMO INTELLIGENCE</Badge></h3>
      <ol className="mb-3 list-decimal space-y-1.5 pl-5">{i.lines.map((l) => <li key={l}>{l}</li>)}</ol>
      <div className="mb-3 rounded-md border border-bd border-l-4 border-l-info bg-p2 p-3"><b className="text-xs">RECOMMENDED PRIORITY</b><div>{i.priority}</div></div>
      <AskBox />
      <Link href="/actions"><Btn variant="primary" className="mt-2 w-full">Open recovery actions</Btn></Link>
    </aside>
  );
}

export function RoleFocus() {
  const { s } = useEvent(); const r = s.role; if (r === 'Event Lead') return null; const m = s.metrics;
  const lines: Record<string, string[]> = {
    Marketing: [`Registration: ${s.registrations}/${s.event.targetRegistrations} (${m.gapPct.toFixed(1)}%)`, `Attendance conversion: ${s.conversion.toFixed(0)}%`, `Velocity: ${s.velocity.at(-1)}/day`, `Recommended campaign: ${actionsFor('reg')[1].title}`],
    Partnerships: [`Confirmed: ${s.partnerConfirmed}%`, `Overdue follow-ups: ${s.partners.filter((p) => p.nextFollowUp <= 0 && !['Confirmed', 'Dropped'].includes(p.status)).length}`, `Recommended outreach: ${actionsFor('part')[0].title}`],
    Operations: [`Logistics readiness: ${m.opsReadiness}%`, `Overdue tasks: ${s.tasks.filter((t) => t.role === 'Operations' && t.status !== 'Completed' && t.dueInDays < 0).length}`, `Weakest: ${Object.entries(s.categories).sort((a, b) => a[1] - b[1])[0].join(' ')}%`],
    Programme: ['Agenda readiness: 91%', 'Speaker confirmations: 11 / 12', 'Session timing verification: scheduled T-3'],
    Leadership: [`Overall health: ${s.health.score} (${s.health.status})`, `Forecast: ${m.forecast} registrations`, `Decisions needed: ${s.risks.filter((x) => x.assignedRole === 'Leadership' || x.severity === 'critical').length}`],
  };
  const open = s.tasks.filter((t) => t.role === r && t.status !== 'Completed').slice(0, 4);
  return <Card title={`${r} focus`} right={<span className="text-mu">role view</span>}><div className="grid gap-4 md:grid-cols-2"><ul className="list-disc pl-5">{lines[r].map((l) => <li key={l}>{l}</li>)}</ul>
    <div className="text-xs">{open.map((t) => <div key={t.id}>• {t.title} <span className="text-mu">({t.status})</span></div>)}{!open.length && <span className="text-mu">No open tasks</span>}</div></div></Card>;
}

function AskBox() {
  const { s } = useEvent(); const [q, setQ] = useState(''); const [qa, setQa] = useState<{ q: string; a: string }[]>([]);
  const ask = () => { const t = q.trim(); if (!t) return; setQa([{ q: t, a: answer(s, t) }, ...qa].slice(0, 3)); setQ(''); };
  return (
    <div className="mb-1">
      <div className="mb-1 text-xs text-mu">ASK THE COMMAND CENTRE</div>
      <div className="flex gap-2"><input aria-label="Ask the command centre" placeholder="why is health low?" className="min-w-0 flex-1" value={q} onChange={(e) => setQ(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && ask()} /><Btn onClick={ask}>Ask</Btn></div>
      {qa.map((x, i) => <div key={i} className="my-1.5 rounded-md border border-bd bg-p2 p-2 text-xs"><b>{x.q}</b><div>{x.a}</div></div>)}
    </div>
  );
}

export function RadarCard() {
  const { s } = useEvent(); const m = s.metrics;
  const axes = [{ label: 'Registrations', value: Math.min(1, s.registrations / s.event.targetRegistrations) }, { label: 'Tasks', value: m.tasksDone / m.tasksTotal }, { label: 'Partners', value: s.partnerConfirmed / 100 },
    { label: 'Operations', value: m.opsReadiness / 100 }, { label: 'Conversion', value: Math.min(1, s.conversion / 80) }, { label: 'Risk safety', value: Math.max(0, 1 - s.health.penalty / 10) }];
  return <Card title="Readiness radar" right={<span className="text-mu">6 dimensions</span>}><Radar axes={axes} /></Card>;
}

export function LiveFeed() {
  const { s, toggleLive } = useEvent();
  return (
    <Card title="Live registrations" right={<Btn onClick={toggleLive}>{s.live ? '⏸ Pause' : '▶ Go live'}</Btn>}>
      <div className="text-xs" aria-live="polite">{s.feed.length ? s.feed.map((f) => <div key={f.id} className="border-b border-dashed border-bd py-1">💗 <b>{f.name}</b> · {f.city} <span className="text-mu">via {f.source}</span></div>)
        : <span className="text-mu">Press “Go live” to stream simulated registrations. Metrics, risks and health react in real time.</span>}</div>
    </Card>
  );
}
