'use client';

import { useEffect, useState } from 'react';
import { useEvent } from '@/hooks/use-event';
import { persistenceMode } from '@/lib/persistence';
import { Badge, Btn, Card } from '@/components/ui';
import { toggleTheme } from '@/lib/theme';

export default function SettingsPage() {
  const { reset } = useEvent();
  type AiMode = 'claude' | 'gemini' | 'demo' | '…';

  const [ai, setAi] = useState<AiMode>('…');

  useEffect(() => {
    let cancelled = false;

    async function loadAiStatus() {
      try {
        const response = await fetch('/api/ai');

        if (!response.ok) {
          throw new Error('Failed to fetch AI status');
        }

        const result: unknown = await response.json();

        if (
          typeof result === 'object' &&
          result !== null &&
          'mode' in result
        ) {
          const mode = result.mode;

          if (
            mode === 'claude' ||
            mode === 'gemini' ||
            mode === 'demo'
          ) {
            if (!cancelled) setAi(mode);
            return;
          }
        }

        throw new Error('Invalid AI mode response');
      } catch {
        if (!cancelled) setAi('demo');
      }
    }

    void loadAiStatus();

    return () => {
      cancelled = true;
    };
  }, []);

  return (
    <div className="flex flex-col gap-6">
      {/* Editorial Header */}
      <div className="flex flex-col justify-between gap-4 border-b border-bd pb-6 md:flex-row md:items-end">
        <div>
          <div className="text-[11px] font-bold uppercase tracking-widest text-mu">
            System &amp; Configuration /
          </div>
          <h1 className="mt-1 text-3xl font-extrabold tracking-tight text-tx sm:text-4xl">
            System <span className="font-editorial italic font-normal text-tx">Settings</span> &amp; Telemetry
          </h1>
          <p className="mt-1.5 max-w-2xl text-xs text-mu leading-relaxed">
            Manage external AI connections, database synchronization, theme modes, and demo state persistence.
          </p>
        </div>

        <div className="flex items-center gap-2 self-start md:self-end">
          <Btn
            variant="default"
            onClick={toggleTheme}
            className="rounded-full px-4 py-1.5 text-xs font-semibold"
          >
            Toggle <span className="font-editorial italic font-normal">Theme</span>
          </Btn>
          <Btn
            variant="default"
            onClick={reset}
            className="rounded-full px-4 py-1.5 text-xs font-semibold"
          >
            Reset Demo Data
          </Btn>
        </div>
      </div>

      {/* Integration Status Cards */}
      <div className="grid gap-4 sm:grid-cols-2">
        <div className="rounded-2xl border border-bd bg-pn p-5 shadow-sm">
          <div className="text-[10px] font-bold uppercase tracking-wider text-mu">Intelligence Engine</div>
          <div className="mt-2 flex items-center gap-2">
            {ai === 'claude' ? (
              <Badge tone="ok">CLAUDE SONNET ACTIVE</Badge>
            ) : (
              <Badge tone="warn">DETERMINISTIC FALLBACK ACTIVE</Badge>
            )}
          </div>
          <p className="mt-3 text-xs text-mu leading-relaxed">
            Rule detection, risk scoring, and recovery state machines run natively without requiring external API keys. Claude adds narrative reasoning and automated follow-ups when configured.
          </p>
        </div>

        <div className="rounded-2xl border border-bd bg-pn p-5 shadow-sm">
          <div className="text-[10px] font-bold uppercase tracking-wider text-mu">Storage &amp; Persistence</div>
          <div className="mt-2 flex items-center gap-2">
            <Badge tone={persistenceMode() === 'supabase' ? 'ok' : 'info'}>
              {persistenceMode() === 'supabase' ? 'SUPABASE CLOUD SYNC' : 'BROWSER LOCALSTORAGE'}
            </Badge>
          </div>
          <p className="mt-3 text-xs text-mu leading-relaxed">
            When Supabase credentials are provided, live events, risks, and attendee scans synchronize to Postgres. In demo mode, all changes safely persist in local storage.
          </p>
        </div>
      </div>

      {/* Configuration Reference */}
      <Card
        title="Environment configuration schema"
        right={<span className="text-xs text-mu">.env.local reference</span>}
      >
        <div className="overflow-hidden rounded-xl border border-bd bg-p2">
          <pre className="p-4 font-mono text-xs text-tx leading-relaxed overflow-x-auto">
            {`# AI Intelligence Engine (Claude / Gemini)
ANTHROPIC_API_KEY=your_anthropic_key_here
ANTHROPIC_MODEL=claude-sonnet-5-5
GEMINI_API_KEY=your_gemini_key_here

# Supabase Cloud Database (Optional)
NEXT_PUBLIC_SUPABASE_URL=https://your-project.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=your_anon_public_key`}
          </pre>
        </div>
      </Card>
    </div>
  );
}
