import type { AppState, Metrics, Role } from '@/types/event';
import { daysUntil } from './dates';

export const DAYS = 60; // registration window length (T-60 → event day)
const avg = (a: number[]) => a.reduce((x, y) => x + y, 0) / a.length;

/** Day index of "now" inside the registration window. Driven by the event date. */
export const todayIndex = (m: Metrics) => DAYS - Math.min(DAYS, m.daysLeft);

/** STEP 1 of the loop: raw event data -> calculated metrics. */
export function computeMetrics(s: AppState): Metrics {
  const open = s.tasks.filter((t) => t.status !== 'Completed').length;
  const tasksTotal = s.baseline.total + s.tasks.length;
  const tasksDone = s.baseline.done + s.tasks.length - open;
  const avgVelocity = avg(s.velocity.slice(-3));
  const target = s.event.targetRegistrations;
  const daysLeft = daysUntil(s.event.date);
  return {
    tasksDone, tasksTotal, avgVelocity, daysLeft,
    gapPct: ((s.registrations - target) / target) * 100,
    forecast: Math.round(s.registrations + avgVelocity * daysLeft * 0.3), // decaying-velocity projection
    attendance: Math.round((s.registrations * s.conversion) / 100),
    opsReadiness: Math.round(avg(Object.values(s.categories))),
  };
}

export interface SeriesPoint { day: number; target: number; actual: number | null; forecast: number | null }
export function registrationSeries(s: AppState, m: Metrics, k = 1): SeriesPoint[] {
  const target = s.event.targetRegistrations, today = Math.max(1, todayIndex(m)), left = Math.max(1, DAYS - today);
  return Array.from({ length: DAYS + 1 }, (_, d) => ({
    day: d,
    target: Math.round(target * k * Math.pow(d / DAYS, 0.45)),
    actual: d <= today ? Math.round(s.registrations * k * Math.pow(d / today, 0.62)) : null,
    forecast: d >= today ? Math.round((s.registrations + ((m.forecast - s.registrations) * (d - today)) / left) * k) : null,
  }));
}

export function departmentReadiness(s: AppState, m: Metrics): Record<Exclude<Role, 'Event Lead'>, number> {
  return {
    Marketing: Math.round(Math.min(1, s.registrations / s.event.targetRegistrations) * 86),
    Partnerships: Math.round(s.partnerConfirmed * 0.9),
    Operations: m.opsReadiness, Programme: 91, Leadership: 95,
  };
}

export function funnel(s: AppState, m: Metrics) {
  const r = s.registrations;
  return [
    { label: 'Reach', value: Math.round(r * 26.9) }, { label: 'Landing page visits', value: Math.round(r * 9.14) },
    { label: 'Registrations', value: r }, { label: 'Confirmed attendance', value: m.attendance },
    { label: 'Expected attendance', value: Math.round(m.attendance * 0.87) },
  ];
}
