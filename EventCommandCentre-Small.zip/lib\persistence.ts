import type { AppState } from '@/types/event';

const KEY = 'ecc-state-v1';
const URL = process.env.NEXT_PUBLIC_SUPABASE_URL, ANON = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
const remote = Boolean(URL && ANON);
const headers = (): Record<string, string> => ({ apikey: ANON ?? '', Authorization: `Bearer ${ANON}`, 'Content-Type': 'application/json' });

export const persistenceMode = (): 'supabase' | 'local' => (remote ? 'supabase' : 'local');

/** Supabase (PostgREST) when configured, localStorage otherwise. Never throws. */
export async function loadState(id: string): Promise<AppState | null> {
  try {
    if (remote) {
      const r = await fetch(`${URL}/rest/v1/event_snapshots?id=eq.${encodeURIComponent(id)}&select=state`, { headers: headers() });
      const j: unknown = await r.json();
      if (Array.isArray(j) && j[0]?.state?.metrics) return j[0].state as AppState;
    }
    const raw = localStorage.getItem(KEY);
    const s = raw ? (JSON.parse(raw) as AppState) : null;
    return s?.metrics ? s : null;
  } catch { return null; }
}
export async function saveState(id: string, s: AppState): Promise<void> {
  try {
    localStorage.setItem(KEY, JSON.stringify(s));
    if (remote) await fetch(`${URL}/rest/v1/event_snapshots`, { method: 'POST', headers: { ...headers(), Prefer: 'resolution=merge-duplicates' },
      body: JSON.stringify({ id, state: s, updated_at: new Date().toISOString() }) });
  } catch { /* offline: keep working in memory */ }
}
export async function clearState(id: string): Promise<void> {
  try {
    localStorage.removeItem(KEY);
    if (remote) await fetch(`${URL}/rest/v1/event_snapshots?id=eq.${encodeURIComponent(id)}`, { method: 'DELETE', headers: headers() });
  } catch { /* ignore */ }
}
