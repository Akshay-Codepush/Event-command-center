"use client";
import { useEffect, useState } from "react";
import { supabase } from "@/lib/session";

export type Density = Record<string, number>;

// Manager only: the database rejects this for anyone else
export async function saveZone(zone: string, density: number): Promise<{ error?: string }> {
if (!supabase) return { error: "Supabase is not connected." };
const { error } = await supabase
    .from("crowd_zones")
    .update({ density, updated_at: new Date().toISOString() })
    .eq("id", zone);
return { error: error?.message };
}

// Loads crowd levels and keeps them live
export function useCrowd(fallback: Density) {
const [density, setDensity] = useState<Density>(fallback);

useEffect(() => {
    const client = supabase;
    if (!client) return;
    let active = true;

    client
    .from("crowd_zones")
    .select("id, density")
    .then(({ data }) => {
        if (!active || !data) return;
        setDensity((d) => {
        const n = { ...d };
        for (const r of data) n[r.id] = r.density;
        return n;
        });
    });

    const channel = client
    .channel("crowd-live")
    .on("postgres_changes", { event: "*", schema: "public", table: "crowd_zones" }, (payload) => {
        const row = payload.new as { id?: string; density?: number };
        if (row && row.id && typeof row.density === "number") {
        const id = row.id;
        const value = row.density;
        setDensity((d) => ({ ...d, [id]: value }));
        }
    })
    .subscribe();

    return () => {
    active = false;
    client.removeChannel(channel);
    };
}, []);

return { density, setDensity };
}