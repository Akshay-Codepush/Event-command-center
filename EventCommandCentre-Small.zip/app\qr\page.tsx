"use client";
import { useEffect, useState } from "react";
import { QRCodeSVG } from "qrcode.react";
import { QrCode, Copy, Check, ExternalLink, Smartphone } from "lucide-react";
import { Card } from "@/components/ui";

export default function RegistrationQrPage() {
  const [base, setBase] = useState("");
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    let saved = "";
    try {
      saved = localStorage.getItem("ecc-public-url") ?? "";
    } catch {
      /* ignore */
    }
    setBase(saved || window.location.origin);
  }, []);

  function update(v: string) {
    setBase(v);
    try {
      localStorage.setItem("ecc-public-url", v);
    } catch {
      /* ignore */
    }
  }

  async function copy(text: string) {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      /* fallback */
    }
  }

  const clean = base.trim().replace(/\/+$/, "");
  const hasProtocol = /^https?:\/\//.test(clean);
  const isLocal = /localhost|127\.0\.0\.1/.test(clean);
  const link = clean && hasProtocol ? `${clean}/login?mode=signup` : "";

  return (
    <div className="mx-auto flex max-w-3xl flex-col gap-5">
      <div>
        <h1 className="text-2xl font-black text-tx">Venue Registration QR Code</h1>
        <p className="mt-1 text-xs text-mu">
          Display this dynamic QR on venue entrance screens or projector slides. Attendees scan with their phone camera to create an account and complete on-site registration.
        </p>
      </div>

      {/* Host URL Configuration */}
      <Card title="Public Site Address for Mobile Access">
        <label className="text-xs text-mu">
          Enter the accessible URL of this deployment (Vercel URL or local LAN address):
        </label>
        <input
          value={base}
          onChange={(e) => update(e.target.value)}
          placeholder="https://your-event-command-centre.vercel.app"
          className="mt-2 w-full rounded-xl border border-bd bg-p2 px-3.5 py-2 text-xs text-tx placeholder:text-mu focus:border-info focus:outline-none"
        />
        {isLocal && (
          <p className="mt-2 text-xs text-warn">
            ⚠️ Note: `localhost` only works on this computer. To test from mobile devices on the same Wi-Fi, replace `localhost` with your local IP address (e.g. `http://192.168.1.15:3000`) or deploy to Vercel.
          </p>
        )}
        {!hasProtocol && clean && (
          <p className="mt-2 text-xs text-crit">
            The URL must start with `http://` or `https://`
          </p>
        )}
      </Card>

      {/* QR Code Presentation Box */}
      <Card title="Live QR Code Display" className="text-center">
        {link ? (
          <div className="flex flex-col items-center py-4">
            <div className="relative rounded-2xl bg-white p-6 shadow-xl border-4 border-info/30">
              <QRCodeSVG value={link} size={260} bgColor="#ffffff" fgColor="#170c15" />
            </div>

            <div className="mt-4 flex items-center gap-2 rounded-xl border border-bd bg-p2 px-3 py-1.5 text-xs text-mu max-w-full">
              <span className="truncate font-mono">{link}</span>
              <a href={link} target="_blank" rel="noreferrer" className="text-info hover:text-tx">
                <ExternalLink size={13} />
              </a>
            </div>

            <button
              onClick={() => void copy(link)}
              className="mt-3 flex items-center gap-1.5 rounded-xl border border-bd bg-p2 px-4 py-2 text-xs font-bold text-tx transition hover:border-info hover:bg-pn"
            >
              {copied ? (
                <>
                  <Check size={14} className="text-ok" /> Copied to clipboard!
                </>
              ) : (
                <>
                  <Copy size={14} /> Copy Mobile Link
                </>
              )}
            </button>
          </div>
        ) : (
          <div className="py-12 text-center text-xs text-mu">
            Enter a valid URL above to preview the QR code.
          </div>
        )}
      </Card>

      {/* Onboarding Guide */}
      <Card title="Attendee Scanning Workflow">
        <div className="grid gap-3 text-xs sm:grid-cols-3">
          <div className="rounded-xl border border-bd bg-p2 p-3.5">
            <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-info/15 text-info font-bold mb-2">1</div>
            <div className="font-bold text-tx">Scan with Phone</div>
            <p className="mt-1 text-mu">Attendee points native camera at QR to open the attendee portal.</p>
          </div>
          <div className="rounded-xl border border-bd bg-p2 p-3.5">
            <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-info/15 text-info font-bold mb-2">2</div>
            <div className="font-bold text-tx">Quick Account Creation</div>
            <p className="mt-1 text-mu">Enters email &amp; password (auto-assigned viewer privileges).</p>
          </div>
          <div className="rounded-xl border border-bd bg-p2 p-3.5">
            <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-info/15 text-info font-bold mb-2">3</div>
            <div className="font-bold text-tx">Live Blueprint Access</div>
            <p className="mt-1 text-mu">Instantly navigates the interactive venue blueprint and crowd heat map.</p>
          </div>
        </div>
      </Card>
    </div>
  );
}