"use client";

import { useEffect, useState } from "react";
import { useCrowd } from "@/lib/useCrowd";
import { USING_SUPABASE, getUser, logout } from "@/lib/session";
import type { User } from "@/lib/auth";
import RegisterCard from "@/components/RegisterCard";
import { LogOut, Flame, Map, RefreshCw, Layers } from "lucide-react";

type Kind = "washroom" | "stall" | "food" | "exit" | "stage" | "help" | "parking";
type Poi = { id: string; kind: Kind; label: string; x: number; y: number; note: string };
type Zone = { id: string; label: string; x: number; y: number; r: number; lx: number; ly: number };

const KINDS: Record<Kind, { icon: string; name: string; color: string }> = {
  washroom: { icon: "🚻", name: "Washrooms", color: "#38bdf8" },
  stall: { icon: "🛍️", name: "Stalls", color: "#f472b6" },
  food: { icon: "🍔", name: "Food & Canteen", color: "#fb923c" },
  exit: { icon: "🚪", name: "Gates & Exits", color: "#4ade80" },
  stage: { icon: "🎤", name: "Main Stage", color: "#c084fc" },
  help: { icon: "ℹ️", name: "Help & First Aid", color: "#facc15" },
  parking: { icon: "🅿️", name: "Parking", color: "#94a3b8" },
};

const POIS: Poi[] = [
  { id: "w1", kind: "washroom", label: "Washroom - Block C/E", x: 285, y: 280, note: "Between Block C and Block E" },
  { id: "w2", kind: "washroom", label: "Washroom - Block E/D", x: 285, y: 378, note: "Between Block E and Block D" },
  { id: "w3", kind: "washroom", label: "Washroom - Block A", x: 507, y: 378, note: "South of Block A" },
  { id: "w4", kind: "washroom", label: "Washroom - Parking", x: 620, y: 470, note: "Next to the parking area" },
  { id: "s1", kind: "stall", label: "Tech Stall 1", x: 665, y: 250, note: "Stall lawn, front row" },
  { id: "s2", kind: "stall", label: "Tech Stall 2", x: 715, y: 250, note: "Stall lawn, front row" },
  { id: "s3", kind: "stall", label: "Tech Stall 3", x: 765, y: 250, note: "Stall lawn, front row" },
  { id: "s4", kind: "stall", label: "Tech Stall 4", x: 815, y: 250, note: "Stall lawn, front row" },
  { id: "s5", kind: "stall", label: "Sponsor Stall 5", x: 665, y: 305, note: "Stall lawn, back row" },
  { id: "s6", kind: "stall", label: "Sponsor Stall 6", x: 715, y: 305, note: "Stall lawn, back row" },
  { id: "s7", kind: "stall", label: "Sponsor Stall 7", x: 765, y: 305, note: "Stall lawn, back row" },
  { id: "s8", kind: "stall", label: "Sponsor Stall 8", x: 815, y: 305, note: "Stall lawn, back row" },
  { id: "f1", kind: "food", label: "Mess / Canteen", x: 395, y: 418, note: "Canteen building" },
  { id: "f2", kind: "food", label: "Food Court", x: 710, y: 410, note: "Food stalls on the east lawn" },
  { id: "st", kind: "stage", label: "Main Stage (Open Air Theatre)", x: 400, y: 328, note: "Keynotes and main events" },
  { id: "h1", kind: "help", label: "Registration Desk", x: 561, y: 226, note: "Administration Block entrance" },
  { id: "h2", kind: "help", label: "First Aid (Block A)", x: 507, y: 320, note: "Medical room in Block A" },
  { id: "e1", kind: "exit", label: "Main Gate", x: 868, y: 445, note: "Main entry and exit, next to parking" },
  { id: "e2", kind: "exit", label: "Exit Gate 2", x: 400, y: 608, note: "South exit" },
  { id: "p1", kind: "parking", label: "Parking", x: 750, y: 535, note: "Vehicle parking" },
];

const ZONES: Zone[] = [
  { id: "gate", label: "Main Gate", x: 850, y: 445, r: 50, lx: 815, ly: 420 },
  { id: "stage", label: "Open Air Theatre", x: 400, y: 328, r: 55, lx: 400, ly: 380 },
  { id: "stalls", label: "Stall Lawn", x: 740, y: 278, r: 95, lx: 740, ly: 338 },
  { id: "food", label: "Food Court", x: 710, y: 410, r: 45, lx: 755, ly: 440 },
  { id: "canteen", label: "Canteen", x: 395, y: 428, r: 40, lx: 395, ly: 468 },
  { id: "sports", label: "Sports Grounds", x: 320, y: 95, r: 90, lx: 500, ly: 41 },
  { id: "parking", label: "Parking", x: 750, y: 535, r: 70, lx: 700, ly: 497 },
];

const START: Record<string, number> = {
  gate: 72,
  stage: 88,
  stalls: 64,
  food: 80,
  canteen: 55,
  sports: 25,
  parking: 45,
};

type Building = { n: string; x: number; y: number; w: number; h: number; low?: boolean };
const BUILDINGS: Building[] = [
  { n: "C", x: 235, y: 205, w: 100, h: 56 },
  { n: "G", x: 355, y: 205, w: 64, h: 56 },
  { n: "B", x: 439, y: 205, w: 64, h: 56 },
  { n: "Admin", x: 523, y: 205, w: 77, h: 56, low: true },
  { n: "E", x: 235, y: 300, w: 64, h: 56 },
  { n: "A", x: 475, y: 300, w: 64, h: 56, low: true },
  { n: "D", x: 235, y: 400, w: 100, h: 56 },
  { n: "Canteen", x: 355, y: 400, w: 80, h: 56, low: true },
  { n: "H", x: 455, y: 400, w: 64, h: 56 },
];

const HOSTELS = [
  { x: 30, y: 435, w: 70, h: 56 },
  { x: 110, y: 435, w: 70, h: 56 },
  { x: 30, y: 510, w: 70, h: 56 },
  { x: 110, y: 510, w: 70, h: 56 },
];

function level(d: number) {
  if (d < 40) return { text: "Low", color: "#22c55e", stroke: "#22c55e" };
  if (d < 70) return { text: "Medium", color: "#facc15", stroke: "#facc15" };
  return { text: "High", color: "#ef4444", stroke: "#ef4444" };
}

export default function AttendeePage() {
  const [heat, setHeat] = useState(false);
  const [live, setLive] = useState(true);
  const { density, setDensity } = useCrowd(START);
  const [selected, setSelected] = useState<string | null>(null);
  const [user, setUser] = useState<User | null>(null);
  const [show, setShow] = useState<Record<Kind, boolean>>({
    washroom: true,
    stall: true,
    food: true,
    exit: true,
    stage: true,
    help: true,
    parking: true,
  });

  useEffect(() => {
    void getUser().then(setUser);
  }, []);

  useEffect(() => {
    if (USING_SUPABASE || !live || !heat) return;
    const t = setInterval(() => {
      setDensity((d) => {
        const n = { ...d };
        for (const k in n) n[k] = Math.max(5, Math.min(98, n[k] + Math.round((Math.random() - 0.5) * 14)));
        return n;
      });
    }, 3000);
    return () => clearInterval(t);
  }, [live, heat, setDensity]);

  function randomize() {
    setDensity((d) => {
      const n = { ...d };
      for (const k in n) n[k] = 10 + Math.round(Math.random() * 85);
      return n;
    });
  }

  const sel = POIS.find((p) => p.id === selected) || null;

  function crowdNear(p: Poi) {
    let best: Zone | null = null;
    let bd = Infinity;
    for (const z of ZONES) {
      const dist = Math.hypot(z.x - p.x, z.y - p.y);
      if (dist < bd) {
        bd = dist;
        best = z;
      }
    }
    if (!best || bd > best.r + 30) return null;
    return { zone: best, d: density[best.id] };
  }

  const nearby = sel ? crowdNear(sel) : null;
  const busiest = [...ZONES].sort((a, b) => density[b.id] - density[a.id]);
  const line = "#93c5fd";
  const soft = "#60a5fa";

  return (
    <div className="mx-auto flex max-w-5xl flex-col gap-4 p-4 md:p-6 pb-24 text-tx">
      {/* Top bar with user session */}
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-bd pb-4">
        <div>
          <h1 className="text-2xl font-black text-tx">Venue Campus Blueprint &amp; Heat Map</h1>
          <p className="text-xs text-mu mt-0.5">
            Locate washrooms, stage halls, sponsor booths, exits, and view live crowd density.
          </p>
        </div>

        {user && (
          <div className="flex items-center gap-2">
            <span className="text-xs font-semibold text-mu">Signed in as:</span>
            <span className="rounded-md border border-bd bg-p2 px-2 py-1 text-xs font-bold text-tx">
              {user.name || user.email} ({user.role})
            </span>
            <button
              onClick={async () => {
                await logout();
                window.location.href = "/login";
              }}
              className="flex items-center gap-1 rounded-md border border-bd bg-p2 px-2.5 py-1 text-xs font-semibold text-mu hover:text-crit transition"
            >
              <LogOut size={13} /> Logout
            </button>
          </div>
        )}
      </div>

      <RegisterCard />

      {/* Mode Switches */}
      <div className="flex flex-wrap items-center gap-2">
        <button
          onClick={() => setHeat(false)}
          className={`flex items-center gap-1.5 rounded-full px-4 py-1.5 text-xs font-bold border transition ${
            !heat ? "bg-info text-white border-info shadow-sm" : "bg-p2 text-tx border-bd hover:border-info"
          }`}
        >
          <Map size={14} /> Blueprint Mode
        </button>
        <button
          onClick={() => setHeat(true)}
          className={`flex items-center gap-1.5 rounded-full px-4 py-1.5 text-xs font-bold border transition ${
            heat ? "bg-crit text-white border-crit shadow-sm" : "bg-p2 text-tx border-bd hover:border-crit"
          }`}
        >
          <Flame size={14} /> Live Heat Map
        </button>

        {heat && (
          <div className="flex items-center gap-2 ml-2">
            {USING_SUPABASE ? (
              <span className="flex items-center gap-1 text-xs font-bold text-ok">
                <span className="h-2 w-2 rounded-full bg-ok livedot" /> Synced from Supabase
              </span>
            ) : (
              <>
                <button
                  onClick={() => setLive(!live)}
                  className="rounded-full border border-bd bg-p2 px-3 py-1 text-xs font-semibold text-tx hover:border-info"
                >
                  {live ? "● Live stream on" : "○ Paused"}
                </button>
                <button
                  onClick={randomize}
                  className="rounded-full border border-bd bg-p2 px-3 py-1 text-xs font-semibold text-tx hover:border-info flex items-center gap-1"
                >
                  <RefreshCw size={12} /> Randomize
                </button>
              </>
            )}
          </div>
        )}
      </div>

      {/* Category filters */}
      <div className="flex flex-wrap gap-1.5">
        {(Object.keys(KINDS) as Kind[]).map((k) => (
          <button
            key={k}
            onClick={() => setShow({ ...show, [k]: !show[k] })}
            className={`rounded-full border px-3 py-1 text-xs font-medium transition ${
              show[k] ? "border-info bg-info/10 text-tx font-bold" : "border-bd bg-p2 text-mu opacity-60"
            }`}
          >
            {KINDS[k].icon} {KINDS[k].name}
          </button>
        ))}
      </div>

      {/* Interactive Blueprint SVG */}
      <div className="overflow-hidden rounded-2xl border border-bd bg-[#061938] shadow-2xl">
        <svg
          viewBox="0 0 960 620"
          className="w-full h-auto max-h-[75vh] block select-none"
        >
          <defs>
            <pattern id="grid" width="20" height="20" patternUnits="userSpaceOnUse">
              <path d="M 20 0 L 0 0 0 20" fill="none" stroke="rgba(255,255,255,0.06)" strokeWidth="1" />
            </pattern>
            <radialGradient id="hg"><stop offset="0%" stopColor="#22c55e" stopOpacity="0.8" /><stop offset="100%" stopColor="#22c55e" stopOpacity="0" /></radialGradient>
            <radialGradient id="hy"><stop offset="0%" stopColor="#facc15" stopOpacity="0.85" /><stop offset="100%" stopColor="#facc15" stopOpacity="0" /></radialGradient>
            <radialGradient id="hr"><stop offset="0%" stopColor="#ef4444" stopOpacity="0.9" /><stop offset="100%" stopColor="#ef4444" stopOpacity="0" /></radialGradient>
          </defs>

          <rect width="960" height="620" fill="#061938" onClick={() => setSelected(null)} />
          <rect width="960" height="620" fill="url(#grid)" onClick={() => setSelected(null)} />

          {/* Campus boundary */}
          <rect x="12" y="12" width="856" height="596" fill="none" stroke={line} strokeWidth="2" />

          {/* Highway */}
          <rect x="880" y="12" width="68" height="596" fill="rgba(255,255,255,0.07)" stroke={soft} />
          <text transform="translate(914,310) rotate(90)" textAnchor="middle" fontSize="13" letterSpacing="4" fill={soft} style={{ pointerEvents: "none" }}>HIGHWAY</text>

          {/* Future extension + north arrow */}
          <rect x="30" y="30" width="170" height="330" fill="none" stroke={soft} strokeDasharray="8 6" opacity="0.7" />
          <text x="115" y="200" textAnchor="middle" fontSize="13" fill={soft} style={{ pointerEvents: "none" }}>Future Extension</text>
          <g transform="translate(115,90)" style={{ pointerEvents: "none" }}>
            <circle r="22" fill="none" stroke={line} />
            <path d="M0,-17 L6,7 L0,3 L-6,7 Z" fill="#fff" />
            <text y="-30" textAnchor="middle" fontSize="12" fontWeight="700" fill="#fff">N</text>
          </g>

          {/* Sports zone */}
          <rect x="220" y="30" width="380" height="150" fill="rgba(74,222,128,0.06)" stroke={soft} strokeDasharray="5 4" />
          <rect x="235" y="45" width="170" height="100" fill="none" stroke={line} />
          <line x1="320" y1="45" x2="320" y2="145" stroke={line} />
          <circle cx="320" cy="95" r="14" fill="none" stroke={line} />
          <text x="320" y="164" textAnchor="middle" fontSize="11" fill="#dbeafe" style={{ pointerEvents: "none" }}>Football Ground</text>
          <circle cx="500" cy="105" r="50" fill="none" stroke={line} />
          <rect x="494" y="88" width="12" height="34" fill="none" stroke={line} />
          <text x="500" y="172" textAnchor="middle" fontSize="11" fill="#dbeafe" style={{ pointerEvents: "none" }}>Cricket Ground</text>

          {/* Courts */}
          <rect x="625" y="40" width="120" height="80" fill="none" stroke={line} />
          <line x1="685" y1="40" x2="685" y2="120" stroke={line} />
          <text x="685" y="138" textAnchor="middle" fontSize="11" fill="#dbeafe" style={{ pointerEvents: "none" }}>Courts</text>

          {/* Stall lawn */}
          <rect x="640" y="205" width="200" height="140" fill="rgba(74,222,128,0.07)" stroke={soft} strokeDasharray="5 4" />
          <text x="650" y="221" fontSize="10" fill={soft} style={{ pointerEvents: "none" }}>Stall Lawn</text>

          {/* Food court */}
          <rect x="640" y="380" width="140" height="70" fill="rgba(251,146,60,0.07)" stroke={soft} strokeDasharray="5 4" />
          <text x="648" y="443" fontSize="10" fill={soft} style={{ pointerEvents: "none" }}>Food Court</text>

          {/* Parking */}
          <rect x="640" y="480" width="220" height="110" fill="rgba(148,163,184,0.08)" stroke={soft} strokeDasharray="5 4" />
          <text x="650" y="582" fontSize="10" fill={soft} style={{ pointerEvents: "none" }}>Parking</text>

          {/* Open air theatre */}
          <circle cx="400" cy="328" r="40" fill="rgba(192,132,252,0.12)" stroke={line} />
          <circle cx="400" cy="328" r="27" fill="none" stroke={line} strokeDasharray="3 3" />

          {/* Buildings */}
          {BUILDINGS.map((b) => (
            <g key={b.n} style={{ pointerEvents: "none" }}>
              <rect x={b.x} y={b.y} width={b.w} height={b.h} fill="rgba(120,170,255,0.18)" stroke={line} strokeWidth="1.5" />
              <text
                x={b.x + b.w / 2}
                y={b.low ? b.y + b.h - 8 : b.y + b.h / 2 + 5}
                textAnchor="middle"
                fontSize={b.n.length > 2 ? 11 : 16}
                fontWeight="700"
                fill="#fff"
              >
                {b.n}
              </text>
            </g>
          ))}

          {/* Hostels */}
          {HOSTELS.map((h, i) => (
            <rect key={i} x={h.x} y={h.y} width={h.w} height={h.h} fill="rgba(120,170,255,0.12)" stroke={line} />
          ))}
          <text x="105" y="425" textAnchor="middle" fontSize="11" fill="#dbeafe" style={{ pointerEvents: "none" }}>Hostels</text>

          {/* Heat glows (under icons) */}
          {heat &&
            ZONES.map((z) => {
              const d = density[z.id];
              const g = d < 40 ? "url(#hg)" : d < 70 ? "url(#hy)" : "url(#hr)";
              return <circle key={z.id} cx={z.x} cy={z.y} r={z.r * (0.7 + d / 200)} fill={g} style={{ pointerEvents: "none" }} />;
            })}

          {/* You are here marker */}
          <g transform="translate(600,320)" style={{ pointerEvents: "none" }}>
            <circle r="7" fill="#facc15" />
            <circle r="13" fill="none" stroke="#facc15" opacity="0.6" />
            <text y="-20" textAnchor="middle" fontSize="11" fontWeight="700" fill="#facc15">You are here</text>
          </g>

          {/* Interactive POI Icons */}
          {POIS.filter((p) => show[p.kind]).map((p) => (
            <g
              key={p.id}
              transform={`translate(${p.x},${p.y})`}
              className="cursor-pointer transition-transform hover:scale-125"
              onClick={(e) => { e.stopPropagation(); setSelected(p.id); }}
            >
              {selected === p.id && <circle r="20" fill="none" stroke="#fff" strokeWidth="2" strokeDasharray="3 3" />}
              <circle r="14" fill="#061938" stroke={KINDS[p.kind].color} strokeWidth="2" />
              <text textAnchor="middle" dominantBaseline="central" fontSize="14">{KINDS[p.kind].icon}</text>
            </g>
          ))}

          {/* Zone % chips */}
          {heat &&
            ZONES.map((z) => {
              const d = density[z.id];
              const c = level(d).stroke;
              return (
                <g key={z.id} style={{ pointerEvents: "none" }}>
                  <rect x={z.lx - 24} y={z.ly - 9} width="48" height="18" rx="9" fill="#061938" stroke={c} strokeWidth="1.5" />
                  <text x={z.lx} y={z.ly + 4} textAnchor="middle" fontSize="11" fontWeight="800" fill={c}>{d}%</text>
                </g>
              );
            })}

          {/* Title banner */}
          <g transform="translate(215,515)" style={{ pointerEvents: "none" }}>
            <rect width="330" height="65" fill="#061938" stroke={line} rx="4" />
            <line x1="0" y1="27" x2="330" y2="27" stroke={line} />
            <text x="12" y="19" fontSize="13" fontWeight="800" fill="#fff">CAMPUS EVENT BLUEPRINT</text>
            <text x="12" y="45" fontSize="11" fill="#dbeafe">Tech Innovation Summit 2026</text>
            <text x="12" y="59" fontSize="10" fill={soft}>Live interactive schematic</text>
          </g>
        </svg>
      </div>

      {/* Selected Marker Details Card */}
      <div className="rounded-xl border border-bd bg-pn p-4 shadow-sm">
        {sel ? (
          <div>
            <div className="text-sm font-bold text-tx flex items-center gap-2">
              <span>{KINDS[sel.kind].icon}</span> {sel.label}
            </div>
            <div className="text-xs text-mu mt-1">{sel.note}</div>
            {nearby && (
              <div className="mt-2 text-xs">
                <span>Crowd density nearby ({nearby.zone.label}): </span>
                <span className={`font-bold ${level(nearby.d).color}`}>
                  {level(nearby.d).text} ({nearby.d}%)
                </span>
              </div>
            )}
          </div>
        ) : (
          <div className="text-xs text-mu">
            Tap any facility or landmark on the blueprint above to view directions and nearby crowd conditions.
          </div>
        )}
      </div>

      {/* Crowd Level Ranking Bar Cards */}
      <div className="rounded-xl border border-bd bg-pn p-4 shadow-sm">
        <div className="text-xs font-bold uppercase tracking-wider text-mu mb-3">
          Zone Congestion Ranking (Busiest First)
        </div>
        <div className="space-y-2">
          {busiest.map((z) => {
            const d = density[z.id];
            const lv = level(d);
            return (
              <div key={z.id} className="grid grid-cols-[140px_1fr_90px] items-center gap-3 text-xs">
                <span className="font-semibold text-tx">{z.label}</span>
                <div className="h-2 rounded-full bg-p2 overflow-hidden border border-bd">
                  <div
                    className="h-full rounded-full transition-all duration-500"
                    style={{ width: `${d}%`, backgroundColor: lv.color }}
                  />
                </div>
                <span className={`text-right font-bold ${lv.color}`}>
                  {lv.text} {d}%
                </span>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}