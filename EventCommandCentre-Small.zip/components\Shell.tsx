'use client';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useState, useEffect, type ReactNode } from 'react';
import { 
  Bell, LayoutDashboard, Wand2, GanttChart, ListChecks, Users, 
  Handshake, Settings2, ShieldAlert, RotateCcw, LineChart, 
  FlaskConical, SlidersHorizontal, X, LogOut, Flame, MapPin, QrCode 
} from 'lucide-react';
import { ROLES, type Role } from '@/types/event';
import { EventProvider, useEvent } from '@/hooks/use-event';
import { Badge, Btn, toneText } from '@/components/ui';
import { RiskDrawerBody } from '@/components/risks';
import { TaskDrawerBody } from '@/components/tasks';
import { FollowUpBody } from '@/components/partners';
import { DemoTour } from '@/components/DemoTour';
import { CommandPalette } from '@/components/CommandPalette';
import { Confetti } from '@/components/Confetti';
import { ROUTES } from '@/lib/routes';
import { toggleTheme } from '@/lib/theme';
import { getUser, logout } from '@/lib/session';
import type { User } from '@/lib/auth';

const ICONS = { 
  '/': LayoutDashboard, 
  '/setup': Wand2, 
  '/plan': GanttChart, 
  '/tasks': ListChecks, 
  '/registrations': Users, 
  '/partners': Handshake, 
  '/operations': Settings2, 
  '/crowd': Flame,
  '/attendee': MapPin,
  '/qr': QrCode,
  '/risks': ShieldAlert, 
  '/actions': RotateCcw, 
  '/analytics': LineChart, 
  '/simulation': FlaskConical, 
  '/settings': SlidersHorizontal 
} as const;

const NAV = ROUTES.map((r) => [r.href, r.label, ICONS[r.href as keyof typeof ICONS] || LayoutDashboard] as const);

function Frame({ children }: { children: ReactNode }) {
  const path = usePathname(); 
  const { s, setRole, reset, randomScenario, drawer, closeDrawer, toast, markRead, setPalette, dataMode, setDataMode } = useEvent();
  const [pop, setPop] = useState(false);
  const [user, setUser] = useState<User | null>(null);

  useEffect(() => {
    void getUser().then(setUser);
  }, [path]);

  const unread = s.notifications.filter((n) => n.unread).length;

  return (
    <div className="grid min-h-screen md:grid-cols-[230px_minmax(0,1fr)] bg-bg text-tx">
      {/* Sidebar Navigation */}
      <nav aria-label="Main navigation" className="flex overflow-x-auto border-b border-bd bg-pn p-3 md:sticky md:top-0 md:h-screen md:flex-col md:overflow-y-auto md:border-b-0 md:border-r">
        {/* Brand Header inspired by reference images */}
        <div className="hidden px-2 pb-5 pt-1 md:block border-b border-bd/60 mb-3">
          <Link href="/" className="group block">
            <div className="flex items-baseline gap-1">
              <span className="text-2xl font-black tracking-tighter text-info">ecc</span>
              <span className="h-1.5 w-1.5 rounded-full bg-info" />
            </div>
            <div className="text-[11px] font-bold tracking-wider text-tx uppercase mt-0.5">
              Event Command <span className="font-editorial normal-case text-mu text-xs">system</span>
            </div>
          </Link>
        </div>

        {/* Navigation Links */}
        <div className="flex flex-row md:flex-col gap-0.5 w-full">
          {NAV.map(([href, label, Icon]) => {
            const active = path === href;
            return (
              <Link 
                key={href} 
                href={href} 
                aria-current={active ? 'page' : undefined}
                className={`flex items-center gap-2.5 whitespace-nowrap rounded-lg px-3 py-2 text-xs transition-all ${
                  active 
                    ? 'bg-tx text-bg font-semibold shadow-xs' 
                    : 'text-mu hover:bg-p2 hover:text-tx font-medium'
                }`}
              >
                <Icon size={15} className={active ? 'text-bg' : 'text-mu'} />
                <span>{label}</span>
                {href === '/risks' && s.risks.length > 0 && (
                  <span className={`ml-auto rounded-full px-1.5 py-0.2 text-[10px] font-bold ${
                    active ? 'bg-bg text-tx' : 'bg-crit text-white'
                  }`}>
                    {s.risks.length}
                  </span>
                )}
              </Link>
            );
          })}
        </div>

        {/* Bottom Agency Note */}
        <div className="hidden md:block mt-auto pt-4 border-t border-bd/60 px-2 text-[11px] text-mu">
          <div className="font-editorial text-sm text-tx">Decision support &amp; telemetry</div>
          <div className="text-[10px] text-mu mt-0.5">Deterministic intelligence engine</div>
        </div>
      </nav>

      {/* Main Area */}
      <div className="min-w-0 flex flex-col">
        {/* Editorial Top Bar */}
        <header className="sticky top-0 z-20 flex flex-wrap items-center gap-2.5 border-b border-bd bg-pn/95 px-4 py-3 backdrop-blur-md">
          {/* Event Name & Slash Divider */}
          <div className="flex items-center gap-2 mr-2">
            <span className="text-sm font-bold text-tx tracking-tight">
              {s.event.name}
            </span>
            <span className="text-mu/40 font-light select-none">/</span>
            <span className="inline-flex items-center gap-1 text-[11px] font-bold text-ok">
              <span className="h-1.5 w-1.5 rounded-full bg-ok livedot" />
              Live
            </span>
            <span className="hidden sm:inline text-xs text-mu">
              ({s.metrics.daysLeft}d to event)
            </span>
          </div>

          <span className="text-mu/40 font-light hidden sm:inline select-none">/</span>

          {/* Health Index */}
          <div className="flex items-center gap-1.5 text-xs">
            <span className="text-mu">Health:</span>
            <span className={`font-black ${toneText[s.health.tone]}`}>
              {s.health.score}<span className="text-[10px] font-normal text-mu">/100</span>
            </span>
          </div>

          <span className="flex-1" />

          {/* Controls with Agency Editorial Polish */}
          <Btn 
            onClick={() => setDataMode(dataMode === 'live' ? 'demo' : 'live')} 
            aria-label="Switch data mode"
            className="text-xs"
          >
            <span className={dataMode === 'live' ? 'text-ok font-bold' : 'text-warn font-bold'}>●</span>{' '}
            {dataMode === 'live' ? 'Live DB' : 'Demo data'}
          </Btn>

          <label className="flex items-center gap-1.5 text-xs text-mu">
            <span>Role:</span>
            <select 
              aria-label="Role selector" 
              value={s.role} 
              onChange={(e) => setRole(e.target.value as Role)}
              className="rounded-lg border border-bd bg-pn px-2 py-1 text-xs text-tx font-medium focus:border-tx"
            >
              {ROLES.map((r) => <option key={r}>{r}</option>)}
            </select>
          </label>

          <Btn onClick={() => setPalette(true)} aria-label="Open command palette" className="hidden lg:inline-flex text-xs">
            <kbd className="mr-1 text-[10px] text-mu font-mono">⌘K</kbd> Palette
          </Btn>

          <Btn onClick={toggleTheme} aria-label="Toggle theme" className="text-xs px-2">
            🌗
          </Btn>

          <Btn onClick={randomScenario} className="hidden sm:inline-flex text-xs">
            New Scenario
          </Btn>

          <Btn onClick={reset} className="text-xs text-mu hover:text-tx">
            Reset
          </Btn>

          {/* Notifications Popover */}
          <div className="relative">
            <Btn 
              aria-label="Notifications" 
              onClick={() => { if (pop) markRead(); setPop(!pop); }}
              className="text-xs relative px-2.5"
            >
              <Bell size={13} className="inline" />
              {unread > 0 && (
                <span className="ml-1 rounded-full bg-crit px-1 text-[10px] font-bold text-white">
                  {unread}
                </span>
              )}
            </Btn>
            {pop && (
              <div className="slidein absolute right-0 top-10 z-30 max-h-96 w-80 overflow-auto rounded-xl border border-bd bg-pn p-2.5 shadow-xl">
                <div className="mb-2 flex items-center justify-between border-b border-bd pb-1.5 px-1">
                  <span className="text-xs font-bold text-tx">Notifications</span>
                  {unread > 0 && (
                    <button onClick={markRead} className="text-[10px] text-info hover:underline">
                      Mark all read
                    </button>
                  )}
                </div>
                {s.notifications.length === 0 ? (
                  <div className="p-3 text-center text-xs text-mu">No active notifications.</div>
                ) : (
                  s.notifications.slice(0, 10).map((n) => (
                    <Link 
                      key={n.id} 
                      href={n.href} 
                      onClick={() => { setPop(false); markRead(); }} 
                      className={`block rounded-lg border-b border-bd/40 p-2 text-xs transition hover:bg-p2 ${n.unread ? 'bg-info/5' : ''}`}
                    >
                      <span className={n.tone === 'critical' ? 'text-crit' : n.tone === 'ok' ? 'text-ok' : n.tone === 'warning' ? 'text-warn' : 'text-info'}>
                        ●
                      </span>{' '}
                      <span className="text-tx font-medium">{n.text}</span>
                    </Link>
                  ))
                )}
              </div>
            )}
          </div>

          {/* User Status & Sign Out */}
          {user && (
            <div className="flex items-center gap-1.5 pl-2 border-l border-bd">
              <span className="hidden xl:inline text-xs font-semibold text-tx truncate max-w-[120px]">
                {user.name || user.email}
              </span>
              <span className="rounded bg-tx text-bg px-1.5 py-0.5 text-[9px] font-bold uppercase tracking-wider">
                {user.role}
              </span>
              <Btn
                aria-label="Logout"
                className="text-xs text-mu hover:text-crit py-1 px-2"
                onClick={async () => {
                  await logout();
                  window.location.href = '/login';
                }}
              >
                <LogOut size={12} className="inline mr-1" />
                <span className="hidden sm:inline">Logout</span>
              </Btn>
            </div>
          )}
        </header>

        {/* Content */}
        <main className="grid max-w-[1500px] gap-5 p-4 md:p-6 lg:p-7">{children}</main>
      </div>

      {/* Slide-in Drawer */}
      {drawer && (
        <div role="dialog" aria-label="Details" className="slidein fixed inset-y-0 right-0 z-40 w-full overflow-auto border-l border-bd bg-pn p-6 shadow-2xl sm:w-[540px]">
          <Btn className="float-right text-xs" onClick={closeDrawer}>
            <X size={14} className="inline mr-1" /> Close
          </Btn>
          {drawer.kind === 'risk' && <RiskDrawerBody id={drawer.id} />}
          {drawer.kind === 'task' && <TaskDrawerBody id={drawer.id} />}
          {drawer.kind === 'followup' && <FollowUpBody id={drawer.id} />}
        </div>
      )}

      <DemoTour />
      <CommandPalette />
      <Confetti />
      {toast && (
        <div role="status" className="slidein fixed bottom-5 left-1/2 z-40 max-w-[92vw] -translate-x-1/2 rounded-xl bg-tx px-4 py-2.5 text-xs font-medium text-bg shadow-2xl">
          {toast}
        </div>
      )}
    </div>
  );
}

export const Shell = ({ children }: { children: ReactNode }) => (
  <EventProvider>
    <Frame>{children}</Frame>
  </EventProvider>
);
