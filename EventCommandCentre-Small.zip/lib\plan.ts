import type { Role } from '@/types/event';
import { ROLES } from '@/types/event';
import type { Priority, Task } from '@/types/task';
import { MILESTONES, OWNERS } from '@/data/demo-data';

export interface SetupForm {
  name: string; type: string; date: string; duration: number; venue: string; city: string;
  audience: string; audienceSize: number; targetRegistrations: number; expectedAttendance: number;
  objectives: string[]; roles: Role[]; brief: string;
}
export interface GeneratedTask { title: string; description: string; role: Role; priority: Priority; milestone: string }

export const OBJECTIVES = ['Generate registrations', 'Increase partner participation', 'Improve attendance', 'Launch student innovation showcase'];
export const DEFAULT_FORM: SetupForm = {
  name: 'Tech Innovation Summit 2026', type: 'Conference', date: '2026-10-21', duration: 2, venue: 'Jaipur Exhibition Centre', city: 'Jaipur',
  audience: 'Students, professionals, founders', audienceSize: 5000, targetRegistrations: 820, expectedAttendance: 541,
  objectives: [...OBJECTIVES], roles: ROLES.slice(1), brief: '',
};

const G = (title: string, description: string, role: Role, priority: Priority, milestone: string): GeneratedTask => ({ title, description, role, priority, milestone });

/** Deterministic plan generator (Demo Intelligence). Claude's tasks, when available, are merged on top. */
export function generatePlan(f: SetupForm): GeneratedTask[] {
  const out: GeneratedTask[] = [
    G(`Finalize ${f.type.toLowerCase()} strategy for ${f.city}`, 'Lock goals, audience segments and success metrics.', 'Leadership', 'High', 'T-30'),
    G('Confirm venue contract and capacity', `Confirm ${f.venue} capacity for ${f.targetRegistrations} registrations.`, 'Operations', 'High', 'T-21'),
    G('Finalize agenda and confirm speakers', `Build a ${f.duration}-day programme grid.`, 'Programme', 'High', 'T-21'),
  ];
  if (f.objectives.includes('Generate registrations')) out.push(
    G('Launch registration campaign', `Social + email launch targeting ${f.audience}.`, 'Marketing', 'High', 'T-21'),
    G('Run paid acquisition push', 'Paid LinkedIn/Instagram with weekly budget review.', 'Marketing', 'Medium', 'T-14'));
  if (f.objectives.includes('Increase partner participation')) out.push(
    G('Confirm sponsor shortlist', 'Close the top sponsor and community partners.', 'Partnerships', 'High', 'T-14'),
    G('Partner amplification kit', 'Share assets and referral links with confirmed partners.', 'Partnerships', 'Medium', 'T-14'));
  if (f.objectives.includes('Improve attendance')) out.push(
    G('Attendance confirmation drip', 'Three-step reminder sequence to registrants.', 'Marketing', 'High', 'T-3'),
    G('Final attendee confirmation', 'One-click confirm links and waitlist release.', 'Marketing', 'Medium', 'T-1'));
  if (f.objectives.includes('Launch student innovation showcase')) out.push(
    G('Open student showcase submissions', 'Call for projects with judging criteria.', 'Programme', 'Medium', 'T-21'),
    G('Showcase floor layout', 'Allocate booths and power for student teams.', 'Operations', 'Medium', 'T-7'));
  out.push(G('Review event readiness', 'Go / no-go readiness review.', 'Leadership', 'Medium', 'T-3'));
  return out.filter((t) => f.roles.includes(t.role));
}

const PRIORITIES: Priority[] = ['Critical', 'High', 'Medium', 'Low'];
/** Validates untrusted model output before it can enter app state. */
export function sanitizeAiTasks(raw: unknown, roles: Role[]): GeneratedTask[] {
  if (!Array.isArray(raw)) return [];
  const ms = MILESTONES.map((m) => m.id);
  return raw.flatMap((x): GeneratedTask[] => {
    const o = x as Record<string, unknown>;
    if (typeof o?.title !== 'string' || typeof o.role !== 'string' || !(ROLES as string[]).includes(o.role) || !roles.includes(o.role as Role)) return [];
    return [{ title: o.title.slice(0, 90), description: String(o.description ?? '').slice(0, 240), role: o.role as Role,
      priority: PRIORITIES.includes(o.priority as Priority) ? (o.priority as Priority) : 'Medium', milestone: ms.includes(String(o.milestone)) ? String(o.milestone) : 'T-14' }];
  }).slice(0, 8);
}

export function toTask(existing: Task[], g: GeneratedTask, eventId: string, daysLeft: number): Task {
  const ids = new Set(existing.map((t) => t.id)); let n = 300 + existing.length; while (ids.has(`TSK-${n}`)) n++;
  const lead = Number(g.milestone.replace('T-', '')) || 0;
  return { id: `TSK-${n}`, eventId, title: g.title, description: g.description, why: 'Generated from the event brief to hit milestone targets.', role: g.role, owner: OWNERS[g.role],
    priority: g.priority, status: 'Not Started', dueInDays: Math.max(1, daysLeft - lead), milestoneId: g.milestone, riskId: null, log: ['Created by Plan Generator'] };
}
