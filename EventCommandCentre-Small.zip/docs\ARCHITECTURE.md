# Architecture

The product is one **closed loop**. Every UI action goes through the same pipeline, so nothing on screen is hard-coded.

```
raw event data ──► metrics ──► risk rules ──► health score ──► explanation ──► recovery action ──► task ──► user completes ──► effect ──┐
   data/            lib/        lib/           lib/            lib/ai.ts +      lib/actions.ts     lib/        hooks/             lib/    │
 demo-data.ts    metrics.ts  risk-engine.ts  health-score.ts   api/ai/route.ts                  simulation.ts  use-event.tsx   simulation.ts │
   ▲                                                                                                                                       │
   └───────────────────────────── lib/engine.ts  settle(): re-run metrics → risks → health → notifications ◄───────────────────────────────┘
```

## Layers
| Layer | Folder | Rule |
|---|---|---|
| Types | `types/` | Plain interfaces: `Event`, `Task`, `Risk`, `RecoveryAction`, `Partner`, `Notification`, `AppState`. |
| Demo data | `data/` | One factory, `createInitialState()`. No randomness (SSR-safe). |
| Business logic | `lib/` | **Pure functions, no React.** Fully unit-tested (`tests/`). |
| State | `hooks/use-event.tsx` | Clone → mutate draft → `settle()` → commit. The only place state changes. |
| UI | `components/`, `app/` | Reads `AppState`; never computes risk/health itself. |
| AI | `lib/ai.ts`, `app/api/ai/route.ts` | Deterministic engine first; Claude optionally enriches. Model output is validated before use. |

## Why rules + AI
Rules, scoring and effect sizes are deterministic, so the demo is reproducible and judges can see *why* a number moved. Claude adds language (explanations, plan tasks, ranking, summaries) on top. If the key is missing or the call fails, `enhance()` returns the deterministic fallback — the UI never blocks.

## Risk rules (`lib/risk-engine.ts`)
R1 registration gap · R2 partner confirmation < 70% · R3 pending confirmations > 30% · R4 attendance conversion < 65% · R5 overdue logistics task · R6 critical task blocked · R7 velocity declining 3 periods · R8 department escalation (≥ 3 risks in one role).

## Health score (`lib/health-score.ts`)
Registration 25 + Tasks 20 + Partners 15 + Logistics 20 + Conversion 10, each with a 50% floor, minus a risk penalty capped at 10 (critical 2, high 1, medium/warning 0.5).
EXCELLENT ≥ 90 · HEALTHY ≥ 75 · WATCH ≥ 60 · AT RISK ≥ 40 · CRITICAL < 40.

## Persistence (`lib/persistence.ts`)
localStorage by default. With `NEXT_PUBLIC_SUPABASE_URL` + `NEXT_PUBLIC_SUPABASE_ANON_KEY` it also writes a snapshot row to `event_snapshots` through PostgREST (no SDK). `supabase/schema.sql` includes the normalised production tables.

## Extending
- **New risk rule:** add a block to `evaluateRisks`, an entry in `lib/actions.ts` (key → actions + effects), a test in `tests/loop.test.ts`.
- **New scenario:** add to `SCENARIOS` + `applyScenario` in `lib/simulation.ts`.
- **New page:** add a route in `lib/routes.ts`, an icon in `components/Shell.tsx`, and `app/<route>/page.tsx`.
