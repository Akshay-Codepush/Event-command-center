'use client';
import { ROLES } from '@/types/event';
import type { Priority } from '@/types/task';
import { useEvent } from '@/hooks/use-event';
import { Btn } from '@/components/ui';

export function TaskDrawerBody({ id }: { id: string }) {
  const { s, completeTask, setTaskStatus, reassignTask, setPriority, closeDrawer } = useEvent();
  const t = s.tasks.find((x) => x.id === id);
  if (!t) return null;
  return (
    <>
      <div className="text-xs text-mu">{t.id} · milestone {t.milestoneId}</div>
      <h2 className="my-1 text-lg font-semibold">{t.title}</h2>
      <p>{t.description}</p>
      <p className="mt-2 text-xs text-mu"><b>Why it matters:</b> {t.why}<br /><b>Related risk:</b> {t.riskId ? s.riskNames[t.riskId] ?? t.riskId : 'None'}<br />
        <b>Dependencies:</b> {t.riskId ? 'Linked recovery action' : 'Milestone gate ' + t.milestoneId}<br /><b>Owner:</b> {t.owner}
        {t.effect && <><br /><b>AI suggestion:</b> completing this is projected to improve event metrics.</>}</p>
      <div className="my-3 flex flex-wrap gap-3 text-xs">
        <label>Priority <select value={t.priority} onChange={(e) => setPriority(t.id, e.target.value as Priority)}>{['Critical', 'High', 'Medium', 'Low'].map((p) => <option key={p}>{p}</option>)}</select></label>
        <label>Reassign <select value={t.role} onChange={(e) => reassignTask(t.id, e.target.value as typeof ROLES[number])}>{ROLES.slice(1).map((r) => <option key={r}>{r}</option>)}</select></label>
      </div>
      <div className="flex gap-2">
        {t.status !== 'Completed' && <Btn variant="success" onClick={() => { completeTask(t.id); closeDrawer(); }}>Complete</Btn>}
        <Btn onClick={() => setTaskStatus(t.id, t.status === 'Blocked' ? 'In Progress' : 'Blocked')}>{t.status === 'Blocked' ? 'Unblock' : 'Block'}</Btn>
      </div>
      <h4 className="mb-1 mt-4 text-[11px] uppercase tracking-widest text-mu">Activity</h4>
      {t.log.map((l, i) => <div key={i} className="text-xs">• {l}</div>)}
    </>
  );
}
