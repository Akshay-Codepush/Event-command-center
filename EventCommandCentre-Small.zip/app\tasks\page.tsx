'use client';

import { useState } from 'react';
import { useEvent } from '@/hooks/use-event';
import { MILESTONES } from '@/data/demo-data';
import { ROLES } from '@/types/event';
import { Btn, Card, due } from '@/components/ui';

export default function Tasks() {
  const { s, openDrawer, completeTask } = useEvent();
  const [f, setF] = useState<Record<string, string>>({});
  const lead = ['Event Lead', 'Leadership'].includes(s.role);

  const rows = s.tasks.filter(
    (t) =>
      (lead || t.role === s.role) &&
      (!f.role || t.role === f.role) &&
      (!f.pri || t.priority === f.pri) &&
      (!f.st || t.status === f.st) &&
      (!f.ms || t.milestoneId === f.ms) &&
      (!f.risk || (f.risk === 'y' ? t.riskId : !t.riskId))
  );

  const completedCount = s.tasks.filter((t) => t.status === 'Completed').length;
  const criticalCount = s.tasks.filter((t) => t.priority === 'Critical' && t.status !== 'Completed').length;

  return (
    <div className="flex flex-col gap-6">
      {/* Editorial Header */}
      <div className="flex flex-col justify-between gap-4 border-b border-bd pb-6 md:flex-row md:items-end">
        <div>
          <div className="text-[11px] font-bold uppercase tracking-widest text-mu">
            Delivery &amp; Milestone Operations /
          </div>
          <h1 className="mt-1 text-3xl font-extrabold tracking-tight text-tx sm:text-4xl">
            Task <span className="font-editorial italic font-normal text-tx">Control</span> Centre
          </h1>
          <p className="mt-1.5 max-w-2xl text-xs text-mu leading-relaxed">
            Real-time critical path tracking across all departments. Milestones dynamically shift and evaluate autonomous risk escalations as tasks complete.
          </p>
        </div>

        {/* Quick Agency Metrics Pill */}
        <div className="flex items-center gap-2 self-start md:self-end">
          <div className="rounded-full border border-bd bg-p2 px-3 py-1.5 text-xs text-tx font-medium shadow-2xs">
            <span className="font-bold">{completedCount}</span> / {s.tasks.length} done
          </div>
          {criticalCount > 0 && (
            <div className="rounded-full border border-crit/30 bg-crit/10 px-3 py-1.5 text-xs font-bold text-crit shadow-2xs">
              {criticalCount} critical pending
            </div>
          )}
        </div>
      </div>

      {/* Filter Toolbar */}
      <Card
        title="Filter tasks"
        right={
          <span className="text-xs font-medium text-mu">
            Showing <b className="text-tx">{rows.length}</b> of {s.tasks.length} tasks
          </span>
        }
      >
        <div className="flex flex-wrap items-center gap-2.5">
          <select
            aria-label="Role"
            value={f.role ?? ''}
            onChange={(e) => setF({ ...f, role: e.target.value })}
            className="rounded-full border border-bd bg-pn px-3 py-1.5 text-xs font-medium text-tx shadow-2xs transition hover:border-tx focus:outline-none"
          >
            <option value="">All Roles</option>
            {ROLES.slice(1).map((o) => (
              <option key={o} value={o}>
                {o}
              </option>
            ))}
          </select>

          <select
            aria-label="Priority"
            value={f.pri ?? ''}
            onChange={(e) => setF({ ...f, pri: e.target.value })}
            className="rounded-full border border-bd bg-pn px-3 py-1.5 text-xs font-medium text-tx shadow-2xs transition hover:border-tx focus:outline-none"
          >
            <option value="">All Priorities</option>
            {['Critical', 'High', 'Medium', 'Low'].map((o) => (
              <option key={o} value={o}>
                {o}
              </option>
            ))}
          </select>

          <select
            aria-label="Status"
            value={f.st ?? ''}
            onChange={(e) => setF({ ...f, st: e.target.value })}
            className="rounded-full border border-bd bg-pn px-3 py-1.5 text-xs font-medium text-tx shadow-2xs transition hover:border-tx focus:outline-none"
          >
            <option value="">All Statuses</option>
            {['Not Started', 'In Progress', 'Blocked', 'Completed'].map((o) => (
              <option key={o} value={o}>
                {o}
              </option>
            ))}
          </select>

          <select
            aria-label="Milestone"
            value={f.ms ?? ''}
            onChange={(e) => setF({ ...f, ms: e.target.value })}
            className="rounded-full border border-bd bg-pn px-3 py-1.5 text-xs font-medium text-tx shadow-2xs transition hover:border-tx focus:outline-none"
          >
            <option value="">All Milestones</option>
            {MILESTONES.map((m) => (
              <option key={m.id} value={m.id}>
                {m.id} · {m.label}
              </option>
            ))}
          </select>

          <select
            aria-label="Risk linked"
            value={f.risk ?? ''}
            onChange={(e) => setF({ ...f, risk: e.target.value })}
            className="rounded-full border border-bd bg-pn px-3 py-1.5 text-xs font-medium text-tx shadow-2xs transition hover:border-tx focus:outline-none"
          >
            <option value="">Risk: Any</option>
            <option value="y">Risk Linked Only</option>
            <option value="n">No Risk Linked</option>
          </select>

          {Object.keys(f).some((k) => f[k]) && (
            <Btn
              variant="default"
              onClick={() => setF({})}
              className="rounded-full px-3 py-1.5 text-xs font-medium text-mu hover:text-tx"
            >
              Reset filters
            </Btn>
          )}
        </div>
      </Card>

      {/* Task Table */}
      <div className="overflow-hidden rounded-2xl border border-bd bg-pn shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-bd bg-p2 text-[10px] font-bold uppercase tracking-wider text-mu">
                <th className="p-3.5">Task &amp; Details</th>
                <th className="p-3.5">Role</th>
                <th className="p-3.5">Priority</th>
                <th className="p-3.5">Due</th>
                <th className="p-3.5">Status</th>
                <th className="p-3.5">Risk Link</th>
                <th className="p-3.5">Owner</th>
                <th className="p-3.5 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-bd">
              {rows.map((t) => {
                const isCrit = t.priority === 'Critical';
                const isHigh = t.priority === 'High';
                const isBlocked = t.status === 'Blocked';
                const isCompleted = t.status === 'Completed';

                return (
                  <tr
                    key={t.id}
                    tabIndex={0}
                    onKeyDown={(e) => e.key === 'Enter' && openDrawer({ kind: 'task', id: t.id })}
                    onClick={() => openDrawer({ kind: 'task', id: t.id })}
                    className="group cursor-pointer transition hover:bg-p2"
                  >
                    <td className="p-3.5">
                      <div className="font-bold text-tx group-hover:text-ink">{t.title}</div>
                      <div className="mt-0.5 flex items-center gap-1.5 font-mono text-[11px] text-mu">
                        <span className="font-bold text-tx">{t.id}</span>
                        <span>/</span>
                        <span>{t.milestoneId}</span>
                      </div>
                    </td>
                    <td className="p-3.5 font-medium text-tx">{t.role}</td>
                    <td className="p-3.5">
                      <span
                        className={`inline-block rounded-md border px-2 py-0.5 text-[10px] font-bold uppercase ${
                          isCrit
                            ? 'border-crit/30 bg-crit/10 text-crit'
                            : isHigh
                            ? 'border-warn/30 bg-warn/10 text-warn'
                            : 'border-bd bg-p2 text-mu'
                        }`}
                      >
                        {t.priority}
                      </span>
                    </td>
                    <td className="p-3.5 font-medium">
                      {isCompleted ? (
                        <span className="text-mu">—</span>
                      ) : (
                        <span className={t.dueInDays <= 2 ? 'font-bold text-crit' : 'text-tx'}>
                          {due(t.dueInDays)}
                        </span>
                      )}
                    </td>
                    <td className="p-3.5">
                      <span
                        className={`inline-block rounded-full px-2.5 py-0.5 text-[10px] font-bold ${
                          isCompleted
                            ? 'bg-ok/10 text-ok border border-ok/20'
                            : isBlocked
                            ? 'bg-crit/10 text-crit border border-crit/20'
                            : 'bg-p2 text-tx border border-bd'
                        }`}
                      >
                        {isCompleted ? '✓ Completed' : t.status}
                      </span>
                    </td>
                    <td className="p-3.5">
                      {t.riskId ? (
                        <span className="rounded-md border border-accent/25 bg-accent/10 px-2 py-0.5 text-[11px] font-bold text-accent">
                          {s.riskNames[t.riskId] ?? t.riskId}
                        </span>
                      ) : (
                        <span className="text-mu">—</span>
                      )}
                    </td>
                    <td className="p-3.5 font-medium text-mu">{t.owner}</td>
                    <td className="p-3.5 text-right">
                      {!isCompleted && (
                        <Btn
                          variant="success"
                          onClick={(e) => {
                            e.stopPropagation();
                            completeTask(t.id);
                          }}
                          className="rounded-full px-3 py-1 text-xs"
                        >
                          Mark <span className="font-editorial italic font-normal">done</span>
                        </Btn>
                      )}
                    </td>
                  </tr>
                );
              })}

              {!rows.length && (
                <tr>
                  <td colSpan={8} className="p-10 text-center">
                    <p className="font-editorial italic text-lg text-mu">No tasks match your selected criteria.</p>
                    <Btn
                      variant="default"
                      onClick={() => setF({})}
                      className="mt-3 rounded-full text-xs"
                    >
                      Clear all filters
                    </Btn>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
