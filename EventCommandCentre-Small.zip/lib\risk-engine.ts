import type { AppState, Metrics, Role } from '@/types/event';
import type { Risk, RiskStatus, Severity } from '@/types/risk';
import { actionsFor } from './actions';

export const SEVERITY_META: Record<Severity, { label: string; rank: number; penalty: number; tone: 'crit' | 'warn' | 'info' }> = {
  critical: { label: 'CRITICAL', rank: 0, penalty: 2, tone: 'crit' },
  high: { label: 'HIGH', rank: 1, penalty: 1, tone: 'warn' },
  medium: { label: 'MEDIUM', rank: 2, penalty: 0.5, tone: 'info' },
  warning: { label: 'WARNING', rank: 3, penalty: 0.5, tone: 'warn' },
};

export function riskStatus(s: AppState, key: string): RiskStatus {
  const linked = s.tasks.filter((t) => t.riskId === key);
  if (linked.some((t) => t.status === 'In Progress')) return 'Mitigating';
  if (linked.some((t) => t.status !== 'Completed')) return 'Action Assigned';
  return s.acknowledged[key] ? 'Acknowledged' : 'Detected';
}

/**
 * STEP 2–3 of the loop: rule-based risk detection (pure function of state + metrics).
 *  R1 registration gap  R2 partner <70%  R3 pending >30%  R4 conversion <65%
 *  R5 overdue logistics R6 critical blocked  R7 velocity declining x3  R8 department escalation (>=3 in one role)
 */
export function evaluateRisks(s: AppState, m: Metrics): Risk[] {
  const out: Risk[] = [];
  const v = s.velocity, n = v.length, target = s.event.targetRegistrations;
  const add = (key: string, type: string, severity: Severity, metric: string, currentValue: string, threshold: string,
    role: Role, what: string, why: string, impact: string) =>
    out.push({ id: key, eventId: s.event.id, type, severity, metric, currentValue, threshold, detectedAt: s.detected[key] ?? 'just now',
      impact, explanation: { what, why }, recommendedActionIds: actionsFor(key).map((a) => a.id), assignedRole: role, status: riskStatus(s, key) });

  const gap = m.gapPct.toFixed(1), drop = Math.round((1 - v[n - 1] / v[n - 4]) * 100);
  if (m.gapPct <= -8) add('reg', 'Registration Velocity Drop', m.gapPct <= -15 ? 'critical' : 'warning', 'Registrations vs target',
    `${s.registrations} / ${target} (${gap}%)`, 'gap ≤ 15%', 'Marketing',
    `Registrations are ${Math.abs(+gap)}% below target (${target - s.registrations} short).`,
    drop > 0 ? `Daily velocity fell ${drop}% in 3 days (${v[n - 4]}→${v[n - 1]}/day) and the early-bird window is closing.` : 'Pace has stabilised but the base is still behind the target curve.',
    `At current velocity registrations may reach ~${m.forecast}, missing target by ${Math.max(0, target - m.forecast)}. Venue utilisation falls to ~${Math.round((m.forecast / target) * 100)}%.`);

  if (s.partnerConfirmed < 70) add('part', 'Partner Confirmation Shortfall', 'high', 'Partner confirmation', `${s.partnerConfirmed}%`, '≥ 70%', 'Partnerships',
    'Partner confirmations are below the 70% readiness threshold.', 'Three sponsors are stuck at Interested and follow-ups are overdue.',
    'Unconfirmed sponsors reduce funding certainty, branding visibility and referral reach.');

  const pending = 100 - s.conversion;
  if (pending > 30) add('pend', 'Pending Confirmations High', 'high', 'Pending confirmations', `${pending.toFixed(0)}%`, '≤ 30%', 'Marketing',
    'Too many registrants have not confirmed attendance.', 'Reminder cadence is thin and no calendar anchoring has gone out.', 'Expected attendance will undershoot registrations.');
  if (s.conversion < 65) add('conv', 'Low Attendance Conversion', s.conversion < 55 ? 'high' : 'medium', 'Attendance conversion', `${s.conversion.toFixed(0)}%`, '≥ 65%', 'Marketing',
    'Registration-to-attendance conversion is weak.', 'Late registrants confirm less; reminders underperform.', `Expected attendance only ~${m.attendance}.`);

  const overdue = s.tasks.filter((t) => t.role === 'Operations' && t.status !== 'Completed' && t.dueInDays < 0);
  if (overdue.length) add('ops', 'Overdue Logistics Task', 'high', 'Overdue logistics tasks', `${overdue.length} overdue`, '0', 'Operations',
    `"${overdue[0].title}" is overdue.`, 'Vendor response delayed; no backup arranged.', 'Day-of transport and guest experience at risk.');

  const blocked = s.tasks.filter((t) => t.priority === 'Critical' && t.status === 'Blocked');
  if (blocked.length) add('blk', 'Critical Task Blocked', 'critical', 'Blocked critical tasks', `${blocked.length} blocked`, '0', 'Operations',
    `"${blocked[0].title}" is blocked.`, 'Dependency on an external AV vendor with no fallback.', 'Stage readiness cannot be verified before T-3.');

  if (n >= 4 && v[n - 1] < v[n - 2] && v[n - 2] < v[n - 3] && v[n - 3] < v[n - 4]) add('vel', 'Declining Registration Velocity', 'warning',
    'Daily velocity', '↓ 3 periods', `${v[n - 4]}→${v[n - 1]}/day`, 'Marketing', 'Registration velocity has declined for 3 consecutive periods.',
    'Campaign fatigue with no new announcement in 6 days.', 'Momentum loss compounds the registration gap.');

  const byRole: Record<string, number> = {};
  out.forEach((r) => (byRole[r.assignedRole] = (byRole[r.assignedRole] ?? 0) + 1));
  Object.entries(byRole).forEach(([role, c]) => c >= 3 && add('esc', `Department Escalation: ${role}`, 'high', `Risks in ${role}`, `${c} active`, '< 3', 'Leadership',
    `${role} has multiple active risks.`, 'Risks are clustering in one department.', 'Capacity must be rebalanced.'));

  return out.sort((a, b) => SEVERITY_META[a.severity].rank - SEVERITY_META[b.severity].rank);
}
