'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { useEvent } from '@/hooks/use-event';
import { Btn } from '@/components/ui';

interface Step { title: string; body: string; route: string; act?: { label: string; run: () => void; disabled?: boolean; why?: string } }

/** 8-step guided demo for judges. Every step can be driven by hand or with "Do it for me". */
export function DemoTour() {
  const e = useEvent(); const { s } = e; const router = useRouter();
  const [open, setOpen] = useState(false); const [i, setI] = useState(0);
  const referral = s.tasks.find((t) => t.riskId === 'reg' && t.title.toLowerCase().includes('referral'));
  const steps: Step[] = [
    { title: '1 · What is happening?', route: '/', body: `Health ${s.health.score}, ${s.registrations}/${s.event.targetRegistrations} registrations, ${s.risks.length} active risks. Note the loop strip: Data → Risk → Action → Task → Outcome.` },
    { title: '2 · Why is it happening?', route: '/', body: 'Open the registration risk: what happened, why, and what happens if nothing is done.',
      act: { label: 'Open registration risk', run: () => e.openDrawer({ kind: 'risk', id: 'reg' }), disabled: !s.risks.some((r) => r.id === 'reg'), why: 'Registration risk is not active.' } },
    { title: '3 · What should we do — and who?', route: '/', body: 'Accept the highest-leverage recovery action. It becomes a real task for Partnerships.',
      act: { label: 'Accept & Assign referral campaign', run: () => e.acceptAction('reg0', 'reg'), disabled: !!s.actionState.reg0 || !s.risks.some((r) => r.id === 'reg'), why: 'Already accepted — continue.' } },
    { title: '4 · Did it work?', route: '/tasks', body: 'Complete the task. Watch registrations, gap, forecast, risk severity and health change at once.',
      act: { label: 'Complete the task', run: () => referral && e.completeTask(referral.id), disabled: !referral || referral.status === 'Completed', why: referral ? 'Already completed.' : 'Do step 3 first.' } },
    { title: '5 · Outcome', route: '/', body: 'Back on the command centre: health up, registration risk CRITICAL → WARNING, partner and velocity risks cleared. The outcome strip records it.' },
    { title: '6 · Stress test', route: '/simulation', body: 'Trigger a Logistics Crisis: AV task blocks, transport goes overdue, the risk engine reacts instantly.',
      act: { label: 'Run Logistics Crisis', run: () => e.runScenario('logistics-crisis') } },
    { title: '7 · AI recovery plan', route: '/actions', body: 'Recovery actions were generated for the new risks, each with impact, effort and owner. Re-rank with AI if a key is set.' },
    { title: '8 · Recover', route: '/', body: 'Apply the recovery: tasks are created and completed, metrics improve, risks clear. The loop is closed.',
      act: { label: 'Apply Last-Minute Recovery', run: () => e.runScenario('recovery'), disabled: s.risks.length === 0, why: 'No risks to recover.' } },
  ];
  const st = steps[i];
  const go = (n: number) => { setI(n); router.push(steps[n].route); };
  if (!open) return <button onClick={() => setOpen(true)} className="fixed bottom-5 left-4 z-30 rounded-full border border-info bg-info px-4 py-2 text-white shadow-xl">▶ Guided Demo</button>;
  return (
    <section aria-label="Guided demo" className="slidein fixed bottom-5 left-4 z-30 w-[min(340px,calc(100vw-2rem))] rounded-lg border border-info bg-pn p-4 shadow-2xl">
      <div className="mb-1 flex items-center gap-2"><b className="text-xs uppercase tracking-widest text-info">Guided demo · {i + 1}/{steps.length}</b>
        <button aria-label="Close tour" className="ml-auto text-mu" onClick={() => setOpen(false)}>✕</button></div>
      <div className="mb-2 flex gap-1">{steps.map((_, k) => <div key={k} className={`h-1 flex-1 rounded ${k <= i ? 'bg-info' : 'bg-bd'}`} />)}</div>
      <b>{st.title}</b><p className="my-1.5 text-xs text-mu">{st.body}</p>
      {st.act && <><Btn variant="primary" className="w-full" disabled={st.act.disabled} onClick={st.act.run}>{st.act.label}</Btn>{st.act.disabled && st.act.why && <div className="mt-1 text-[11px] text-mu">{st.act.why}</div>}</>}
      <div className="mt-3 flex gap-2"><Btn disabled={i === 0} onClick={() => go(i - 1)}>Back</Btn>
        {i < steps.length - 1 ? <Btn onClick={() => go(i + 1)}>Next</Btn> : <Btn variant="success" onClick={() => setOpen(false)}>Finish</Btn>}
        <Btn className="ml-auto" onClick={() => { e.reset(); setI(0); router.push('/'); }}>Restart</Btn></div>
    </section>
  );
}
