import type { AppState } from '@/types/event';
import type { Task } from '@/types/task';
import type { Partner } from '@/types/partner';
import type { Role, Effect } from '@/types/event';
import type { Priority, TaskStatus } from '@/types/task';

export const OWNERS: Record<Role, string> = {
  'Event Lead': 'You (Event Lead)', Marketing: 'Aisha Rahman', Partnerships: 'Priya Nair',
  Operations: 'Dev Patel', Programme: 'Sana Khan', Leadership: 'Vikram Rao',
};
export const MILESTONES = [
  { id: 'T-30', label: 'T-30', title: 'Event strategy finalized' },
  { id: 'T-21', label: 'T-21', title: 'Marketing campaign launched' },
  { id: 'T-14', label: 'T-14', title: 'Partner confirmations target: 80%' },
  { id: 'T-7', label: 'T-7', title: 'Registration target: 90%' },
  { id: 'T-3', label: 'T-3', title: 'Logistics verification' },
  { id: 'T-1', label: 'T-1', title: 'Final attendee confirmation' },
  { id: 'EVENT', label: 'Event Day', title: 'Execution' },
  { id: 'RECOVERY', label: 'Recovery', title: 'AI-generated recovery actions' },
];
export const EVENT_ID = 'evt-tis-2026';

function t(id: string, title: string, role: Role, priority: Priority, status: TaskStatus, dueInDays: number,
  milestoneId: string, riskId: string | null, description: string, effect?: Effect, why = 'Keeps the event on its operating plan.'): Task {
  return { id, eventId: EVENT_ID, title, description, why, role, owner: OWNERS[role], priority, status, dueInDays, milestoneId, riskId, effect, log: ['Created by Plan Generator'] };
}

const tasks: Task[] = [
  t('TSK-101', 'Run paid LinkedIn campaign', 'Marketing', 'High', 'In Progress', 2, 'T-7', 'reg', 'Paid acquisition across LinkedIn lookalike audiences.', { reg: 14, v: 24 }, 'Largest controllable registration lever.'),
  t('TSK-102', 'Email reminder campaign', 'Marketing', 'Medium', 'Not Started', 1, 'T-7', 'reg', 'Reminder to registrants with unconfirmed attendance.', { reg: 12, c: 3 }),
  t('TSK-103', 'Publish speaker announcement', 'Marketing', 'Medium', 'Completed', -3, 'T-14', null, 'Keynote lineup reveal.'),
  t('TSK-104', 'Follow up with ABC Technologies', 'Partnerships', 'High', 'Not Started', 0, 'T-14', 'part', 'Lock sponsor confirmation.', { p: 4 }, 'A pending sponsor drags partner readiness below 70%.'),
  t('TSK-105', 'Collect sponsor branding assets', 'Partnerships', 'Medium', 'In Progress', 2, 'T-7', null, 'Logos, banners and booth specs.'),
  t('TSK-106', 'AV equipment check', 'Operations', 'Critical', 'In Progress', 3, 'T-3', null, 'Verify projectors, mics and stage sound.', undefined, 'Stage readiness depends on it.'),
  t('TSK-107', 'Transport coordination: shuttle vendor', 'Operations', 'High', 'In Progress', 2, 'T-3', null, 'Confirm airport and venue shuttles.'),
  t('TSK-108', 'Registration desk setup', 'Operations', 'Medium', 'Not Started', 5, 'T-1', null, 'Counters, badges and scanners.'),
  t('TSK-109', 'Seating plan', 'Operations', 'Medium', 'Completed', -2, 'T-7', null, 'Hall layout and capacity.'),
  t('TSK-110', 'Finalize agenda', 'Programme', 'High', 'Completed', -4, 'T-14', null, 'Session grid locked.'),
  t('TSK-111', 'Speaker briefing', 'Programme', 'Medium', 'In Progress', 3, 'T-3', null, 'Briefing call with all speakers.'),
  t('TSK-112', 'Approve final budget', 'Leadership', 'High', 'Completed', -5, 'T-14', null, 'Budget sign-off.'),
  t('TSK-113', 'Review event readiness', 'Leadership', 'Medium', 'Not Started', 4, 'T-3', null, 'Go / no-go readiness review.'),
];

const p = (id: string, name: string, contact: string, type: string, status: Partner['status'], lastContact: number, nextFollowUp: number, prob: number): Partner =>
  ({ id, eventId: EVENT_ID, name, contact, type, status, lastContact, nextFollowUp, confirmationProbability: prob });

export const SOURCES: [string, number][] = [['LinkedIn', 24], ['Instagram', 21], ['Partner', 18], ['Email', 15], ['Website', 14], ['Referral', 8]];
export const AUDIENCE: [string, number][] = [['Students', 38], ['Professionals', 34], ['Founders', 16], ['Faculty', 12]];

/** Fresh demo state. Derived fields (metrics/risks/health) are filled by settle() in lib/engine.ts. */
export function createInitialState(): AppState {
  return {
    event: { id: EVENT_ID, name: 'Tech Innovation Summit 2026', type: 'Conference', date: '2026-10-21', venue: 'Jaipur Exhibition Centre', city: 'Jaipur',
      targetRegistrations: 820, expectedAttendance: 541, healthScore: 78, status: 'LIVE' },
    role: 'Event Lead', registrations: 684, conversion: 79.1, partnerConfirmed: 68,
    velocity: [34, 31, 28, 25, 23, 21, 19], baseline: { done: 38, total: 44 },
    categories: { Venue: 100, AV: 80, Seating: 95, Transport: 60, Catering: 90, Security: 92, 'Registration Desk': 88, Branding: 85, Certificates: 95, Photography: 95 },
    tasks: structuredClone(tasks),
    partners: [
      p('p1', 'ABC Technologies', 'Rahul', 'Sponsor', 'Interested', 4, 0, 72), p('p2', 'NovaCloud', 'Neha', 'Sponsor', 'Negotiating', 2, 1, 81),
      p('p3', 'Orbit AI', 'Kabir', 'Sponsor', 'Interested', 6, -1, 58), p('p4', 'IIT Jaipur Innovation Cell', 'Dr. Mehra', 'Academic', 'Confirmed', 1, 7, 100),
      p('p5', 'StartupRaj', 'Isha', 'Community', 'Confirmed', 3, 5, 100), p('p6', 'CloudNest', 'Arjun', 'Sponsor', 'Contacted', 8, -2, 35),
      p('p7', 'FinEdge', 'Maya', 'Sponsor', 'Prospect', 12, 2, 20), p('p8', 'DataForge', 'Sam', 'Sponsor', 'Dropped', 15, 0, 0),
    ],
    actionState: {}, actionOwner: {}, actionTitle: {}, acknowledged: {},
    detected: { reg: '3h ago', part: '1d ago', vel: '2d ago' }, riskNames: {},
    notifications: [
      { id: 'n1', text: 'Registration gap crossed 15%.', href: '/risks', tone: 'critical', unread: true },
      { id: 'n2', text: 'Partner confirmation dropped below 70%.', href: '/partners', tone: 'warning', unread: true },
      { id: 'n3', text: 'AI generated recovery actions.', href: '/actions', tone: 'info', unread: true },
    ],
    healthHistory: [71, 73, 77, 81, 83, 82, 80], riskHistory: [1, 1, 2, 2, 3, 3, 3], lastOutcome: '', live: false, feed: [],
    metrics: {} as AppState['metrics'], risks: [], health: {} as AppState['health'],
  };
}
