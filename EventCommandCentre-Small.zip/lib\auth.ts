export type Role = "manager" | "viewer";
export type User = { email: string; name: string; role: Role };

// Demo accounts (fake, for the hackathon demo only)
export const USERS = [
{ email: "manager@demo.com", password: "manager123", name: "Event Supervisor", role: "manager" as Role },
{ email: "viewer@demo.com", password: "viewer123", name: "Event Attendee", role: "viewer" as Role },
];

const KEY = "ecc-user";

export function login(email: string, password: string): User | null {
const found = USERS.find(
    (u) => u.email === email.trim().toLowerCase() && u.password === password
);
if (!found) return null;
const user: User = { email: found.email, name: found.name, role: found.role };
localStorage.setItem(KEY, JSON.stringify(user));
return user;
}

export function getUser(): User | null {
if (typeof window === "undefined") return null;
try {
    const raw = localStorage.getItem(KEY);
    return raw ? (JSON.parse(raw) as User) : null;
} catch {
    return null;
}
}

export function logout() {
localStorage.removeItem(KEY);
}