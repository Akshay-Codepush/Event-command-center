'use client';

import { useState } from 'react';
import Link from 'next/link';
import { useEvent } from '@/hooks/use-event';
import { registrationSeries, todayIndex, funnel, departmentReadiness } from '@/lib/metrics';
import { buildInsights } from '@/lib/ai';
import { answer } from '@/lib/qa';
import { mood } from '@/lib/health-score';
import { Card, Empty, Badge, Btn, toneText, pctTone, Bar } from '@/components/ui';
import { RegChart, Radar } from '@/components/charts';
import { RiskCard } from '@/components/risks';
import { 
  Users, Target, TrendingDown, TrendingUp, CheckSquare, 
  AlertTriangle, Calendar, ArrowRight, Sparkles, Play, Pause, 
  Activity, Zap, Check
} from 'lucide-react';

export default function Overview() {
  const { s, dataMode, openDrawer, toggleLive, runScenario } = useEvent();
  const m = s.metrics;
  const lead = ['Event Lead', 'Leadership'].includes(s.role);
  const risks = lead ? s.risks : s.risks.filter((r) => r.assignedRole === s.role);
  const insights = buildInsights(s);
  const rd = departmentReadiness(s, m);
  const fun = funnel(s, m);
  const maxFunnel = fun[0]?.value || 1;

  // Q&A State
  const [qaInput, setQaInput] = useState('');
  const [qaHistory, setQaHistory] = useState<Array<{ q: string; a: string }>>([
    {
      q: 'Why is health score currently low?',
      a: answer(s, 'why is health score low?'),
    },
  ]);

  const handleAsk = (queryText?: string) => {
    const q = (queryText ?? qaInput).trim();
    if (!q) return;
    const a = answer(s, q);
    setQaHistory((prev) => [{ q, a }, ...prev.slice(0, 3)]);
    setQaInput('');
  };

  // Clickable KPIs
  const kpis = [
    {
      label: 'Registrations',
      val: s.registrations.toLocaleString(),
      sub: dataMode === 'live' ? 'Database live' : 'Simulated pace',
      href: '/registrations',
      icon: Users,
      tone: 'info',
    },
    {
      label: 'Target',
      val: s.event.targetRegistrations.toLocaleString(),
      sub: `${s.event.venue}`,
      href: '/setup',
      icon: Target,
      tone: 'mu',
    },
    {
      label: 'Registration Gap',
      val: `${m.gapPct >= 0 ? '+' : ''}${m.gapPct.toFixed(1)}%`,
      sub: `${Math.abs(s.event.targetRegistrations - s.registrations)} ${m.gapPct < 0 ? 'behind' : 'ahead'}`,
      href: '/registrations',
      icon: m.gapPct < -8 ? TrendingDown : TrendingUp,
      tone: m.gapPct <= -15 ? 'crit' : m.gapPct <= -8 ? 'warn' : 'ok',
    },
    {
      label: 'Attendance Forecast',
      val: m.attendance.toLocaleString(),
      sub: `${s.conversion.toFixed(0)}% conversion`,
      href: '/registrations',
      icon: Activity,
      tone: s.conversion < 65 ? 'warn' : 'ok',
    },
    {
      label: 'Partner Confirmations',
      val: `${s.partnerConfirmed}%`,
      sub: s.partnerConfirmed < 70 ? 'Below 70% target' : 'On target (≥70%)',
      href: '/partners',
      icon: Zap,
      tone: s.partnerConfirmed < 70 ? 'warn' : 'ok',
    },
    {
      label: 'Tasks Completed',
      val: `${m.tasksDone} / ${m.tasksTotal}`,
      sub: `${Math.round((m.tasksDone / m.tasksTotal) * 100)}% progress`,
      href: '/tasks',
      icon: CheckSquare,
      tone: pctTone((m.tasksDone / m.tasksTotal) * 100),
    },
    {
      label: 'Active Risks',
      val: `${s.risks.length}`,
      sub: `${s.risks.filter((r) => r.severity === 'critical').length} critical`,
      href: '/risks',
      icon: AlertTriangle,
      tone: s.risks.some((r) => r.severity === 'critical') ? 'crit' : s.risks.length > 0 ? 'warn' : 'ok',
    },
    {
      label: 'Days Remaining',
      val: `${m.daysLeft}d`,
      sub: `Event: ${s.event.date}`,
      href: '/plan',
      icon: Calendar,
      tone: m.daysLeft <= 7 ? 'warn' : 'mu',
    },
  ];

  return (
    <div className="flex flex-col gap-6">
      {/* Editorial Hero Header */}
      <section className="flex flex-col md:flex-row md:items-end justify-between gap-4 border-b border-bd/80 pb-6 pt-2">
        <div>
          <div className="text-[11px] font-bold uppercase tracking-widest text-mu mb-1.5 flex items-center gap-2">
            <span>Operating Control Layer</span>
            <span className="text-mu/40 font-light select-none">/</span>
            <span className="text-info font-medium">{s.event.venue}</span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-extrabold tracking-tight text-tx">
            Event <span className="font-editorial text-4xl sm:text-5xl font-normal text-tx">Command Centre</span>
          </h1>
          <p className="mt-2 text-xs sm:text-sm text-mu max-w-xl leading-relaxed">
            Real-time readiness telemetry, risk rule evaluation, and closed-loop decision support for event leadership.
          </p>
        </div>

        {/* Agency Action Buttons */}
        <div className="flex flex-wrap items-center gap-2.5">
          <Link
            href="/actions"
            className="btn-primary rounded-xl px-4 py-2 text-xs font-semibold shadow-xs flex items-center gap-1.5"
          >
            Take <span className="font-editorial text-sm font-normal">action!</span> <ArrowRight size={13} />
          </Link>
          <Link
            href="/simulation"
            className="rounded-xl border border-bd bg-pn px-3.5 py-2 text-xs font-semibold text-tx hover:border-tx hover:bg-p2 transition shadow-2xs"
          >
            Run <span className="font-editorial text-sm font-normal">simulation</span> ↗
          </Link>
        </div>
      </section>

      {/* Verified Recovery Outcome Strip */}
      {s.lastOutcome && (
        <aside
          role="status"
          aria-label="Recovery action outcome"
          className="slidein flex flex-wrap items-center justify-between gap-3 rounded-xl border border-ok/40 bg-ok/10 px-4 py-3 text-tx"
        >
          <div className="flex items-center gap-2.5">
            <span className="flex h-6 w-6 items-center justify-center rounded-full bg-ok text-white font-bold text-xs">✓</span>
            <div>
              <div className="text-[10px] font-bold uppercase tracking-wider text-ok">
                Recovery Proved &amp; Verified
              </div>
              <div className="text-xs font-medium text-tx">{s.lastOutcome}</div>
            </div>
          </div>
          <Link
            href="/analytics"
            className="flex items-center gap-1 text-xs font-semibold text-ok hover:underline"
          >
            View analytics proof <ArrowRight size={13} />
          </Link>
        </aside>
      )}

      {/* Closed-Loop Operating Architecture Banner */}
      <section aria-label="Closed loop intelligence" className="rounded-xl border border-bd bg-pn p-4">
        <div className="mb-2.5 flex items-center justify-between text-[10px] font-bold uppercase tracking-widest text-mu">
          <span>Closed-Loop Architecture</span>
          <span className="font-normal text-mu/80">Data → Risk → Action → Proved Recovery</span>
        </div>
        <div className="flex flex-wrap items-center gap-2 text-xs">
          <span className="rounded-md border border-bd bg-p2 px-2.5 py-1 font-medium text-tx">1. Live Data</span>
          <span className="text-mu/40 font-light select-none">/</span>
          <span className="rounded-md border border-bd bg-p2 px-2.5 py-1 font-medium text-tx">2. Metrics</span>
          <span className="text-mu/40 font-light select-none">/</span>
          <span className="rounded-md border border-crit/30 bg-crit/10 px-2.5 py-1 font-semibold text-crit">3. Risk Rules</span>
          <span className="text-mu/40 font-light select-none">/</span>
          <span className="rounded-md border border-bd bg-p2 px-2.5 py-1 font-medium text-tx">4. Explanation</span>
          <span className="text-mu/40 font-light select-none">/</span>
          <span className="rounded-md border border-info/30 bg-info/10 px-2.5 py-1 font-semibold text-info">5. Recovery Action</span>
          <span className="text-mu/40 font-light select-none">/</span>
          <span className="rounded-md border border-bd bg-p2 px-2.5 py-1 font-medium text-tx">6. Task Execution</span>
          <span className="text-mu/40 font-light select-none">/</span>
          <span className="rounded-md border border-ok/30 bg-ok/10 px-2.5 py-1 font-bold text-ok">7. Outcome Verified</span>
        </div>
      </section>

      {/* Health Score Card with Multi-Dimensional Breakdown */}
      <section aria-label="Event health score overview" className="rounded-xl border border-bd bg-pn p-6">
        <div className="flex flex-wrap items-center justify-between gap-5">
          <div className="flex items-center gap-4">
            <div className="text-4xl" role="img" aria-label="Mood emoji">{mood(s.health.score)}</div>
            <div>
              <div className="text-[10px] font-bold uppercase tracking-widest text-mu">
                Event Health <span className="font-editorial normal-case text-sm text-tx">Index</span>
              </div>
              <div className="flex items-baseline gap-2.5 mt-0.5">
                <span className={`text-4xl font-extrabold tracking-tight ${toneText[s.health.tone]}`}>
                  {s.health.score}
                  <span className="text-sm font-normal text-mu">/100</span>
                </span>
                <span className={`rounded-md px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider ${
                  s.health.tone === 'ok' ? 'bg-ok/15 text-ok' : s.health.tone === 'warn' ? 'bg-warn/15 text-warn' : 'bg-crit/15 text-crit'
                }`}>
                  {s.health.status}
                </span>
              </div>
            </div>
          </div>

          {/* Breakdown tags */}
          <div className="flex flex-wrap gap-2 text-xs">
            {s.health.parts.map((p) => (
              <div key={p.label} className="rounded-lg border border-bd bg-p2 px-3 py-1.5">
                <div className="text-[10px] text-mu">{p.label}</div>
                <div className="font-bold text-tx">+{Math.round(p.value)} pts</div>
              </div>
            ))}
            {s.health.penalty > 0 && (
              <div className="rounded-lg border border-crit/30 bg-crit/10 px-3 py-1.5 text-crit">
                <div className="text-[10px] opacity-80">Risk Penalty</div>
                <div className="font-bold">-{s.health.penalty.toFixed(1)} pts</div>
              </div>
            )}
          </div>
        </div>

        <div className="mt-4">
          <Bar value={s.health.score} tone={s.health.tone} />
        </div>
      </section>

      {/* 8 Clickable KPI Cards */}
      <section aria-label="Key performance indicators" className="grid grid-cols-2 gap-3 sm:grid-cols-4 lg:grid-cols-8">
        {kpis.map((kpi) => {
          const Icon = kpi.icon;
          return (
            <Link
              key={kpi.label}
              href={kpi.href}
              className="group flex flex-col justify-between rounded-xl border border-bd bg-pn p-3.5 transition-all duration-150 hover:border-tx hover:shadow-xs"
            >
              <div className="flex items-center justify-between text-mu">
                <span className="text-[10px] font-bold uppercase tracking-wider text-mu group-hover:text-tx">{kpi.label}</span>
                <Icon size={13} className="text-mu group-hover:text-tx" />
              </div>
              <div className="my-2.5">
                <div className={`text-2xl font-bold tracking-tight ${toneText[kpi.tone as keyof typeof toneText] || 'text-tx'}`}>
                  {kpi.val}
                </div>
                <div className="text-[10px] text-mu truncate" title={kpi.sub}>
                  {kpi.sub}
                </div>
              </div>
              <div className="text-[10px] font-semibold text-tx opacity-0 transition group-hover:opacity-100 flex items-center gap-1">
                Details <ArrowRight size={10} />
              </div>
            </Link>
          );
        })}
      </section>

      {/* Role-Specific Perspective Banner */}
      <section aria-label="Role perspective" className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-bd bg-p2 px-4 py-2.5 text-xs">
        <div className="flex items-center gap-2">
          <span className="rounded bg-tx text-bg px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider">
            {s.role} Lens
          </span>
          <span className="text-tx font-medium">
            {s.role === 'Marketing' && `Registration gap is ${m.gapPct.toFixed(1)}%. Velocity is ${s.velocity.at(-1)}/day.`}
            {s.role === 'Partnerships' && `Partner confirmation is ${s.partnerConfirmed}%. ${s.partners.filter(p => p.nextFollowUp <= 0 && p.status !== 'Confirmed').length} follow-ups are overdue.`}
            {s.role === 'Operations' && `Logistics readiness is ${m.opsReadiness}%. Transport and AV are active focus areas.`}
            {s.role === 'Programme' && `Programme grid readiness is 91%. Speaker confirmations are 11/12.`}
            {['Event Lead', 'Leadership'].includes(s.role) && `System health is ${s.health.score}/100. ${s.risks.length} active risks under management.`}
          </span>
        </div>
        <div className="text-[11px] text-mu">
          Priority: <span className="font-editorial text-xs text-tx font-bold">{insights.priority.slice(0, 48)}…</span>
        </div>
      </section>

      {/* Main 2-Column Dashboard Layout */}
      <div className="grid gap-6 lg:grid-cols-[minmax(0,1fr)_340px]">
        {/* LEFT COLUMN: Operations, Charts, Risks, Funnel */}
        <div className="flex flex-col gap-6 min-w-0">
          {/* Registration Performance Chart */}
          <Card
            title="Registration Trajectory & Forecast"
            right={
              <span className={`text-xs font-bold ${m.gapPct <= -8 ? 'text-crit' : 'text-ok'}`}>
                {m.gapPct <= -8 ? `Pace deficit: ${Math.abs(m.gapPct).toFixed(1)}%` : 'On trajectory curve'}
              </span>
            }
          >
            <div className="mb-3 flex flex-wrap items-center justify-between gap-2 text-xs text-mu">
              <div className="flex items-center gap-3">
                <span className="flex items-center gap-1.5"><span className="h-2 w-4 rounded-sm bg-info" /> Actual ({s.registrations})</span>
                <span className="flex items-center gap-1.5"><span className="h-2 w-4 rounded-sm bg-mu" /> Target ({s.event.targetRegistrations})</span>
                <span className="flex items-center gap-1.5"><span className="h-2 w-4 rounded-sm border border-dashed border-warn" /> Forecast (~{m.forecast})</span>
              </div>
              <span className="font-editorial text-sm text-tx">Day {todayIndex(m)} of 60</span>
            </div>
            <RegChart data={registrationSeries(s, m)} today={todayIndex(m)} height={220} />
          </Card>

          {/* Active Risks List */}
          <Card
            title={`Active Risks (${risks.length})`}
            right={
              <Link href="/risks" className="text-xs font-semibold text-tx hover:underline">
                Risk Engine (8 rules) →
              </Link>
            }
          >
            {risks.length ? (
              <div className="space-y-3">
                {risks.map((r) => (
                  <RiskCard key={r.id} r={r} />
                ))}
              </div>
            ) : (
              <Empty>No active risks for current filters. Operations stable. ✓</Empty>
            )}
          </Card>

          {/* Live Registration Stream Ticker */}
          <Card
            title="Live Registrations Stream"
            right={
              <div className="flex items-center gap-2.5">
                <Btn onClick={toggleLive} className="text-xs">
                  {s.live ? (
                    <>
                      <Pause size={12} className="inline mr-1 text-warn" /> Pause stream
                    </>
                  ) : (
                    <>
                      <Play size={12} className="inline mr-1 text-ok" /> Resume live stream
                    </>
                  )}
                </Btn>
                <span className={`inline-flex items-center gap-1 text-xs font-semibold ${s.live ? 'text-ok' : 'text-mu'}`}>
                  <span className={`h-2 w-2 rounded-full ${s.live ? 'bg-ok livedot' : 'bg-mu'}`} />
                  {s.live ? 'Live' : 'Paused'}
                </span>
              </div>
            }
          >
            {s.feed.length > 0 ? (
              <div className="grid gap-2.5 sm:grid-cols-2 md:grid-cols-3">
                {s.feed.slice(0, 6).map((item) => (
                  <div
                    key={item.id}
                    className="slidein flex items-center justify-between rounded-lg border border-bd bg-p2 p-2.5 text-xs"
                  >
                    <div>
                      <div className="font-bold text-tx">{item.name}</div>
                      <div className="text-[10px] text-mu">{item.city} <span className="text-mu/40">/</span> {item.source}</div>
                    </div>
                    <span className="rounded bg-pn px-1.5 py-0.5 text-[9px] font-bold text-ok border border-bd">
                      PASS
                    </span>
                  </div>
                ))}
              </div>
            ) : (
              <div className="py-4 text-center text-xs text-mu">
                Live stream ticker is idle. Toggle stream above to observe simulated registration flow.
              </div>
            )}
          </Card>

          {/* Conversion Funnel & Department Readiness */}
          <div className="grid gap-6 md:grid-cols-2">
            {/* Event Conversion Funnel */}
            <Card title="Acquisition & Conversion Funnel">
              <div className="space-y-3">
                {fun.map((stage, i) => {
                  const pct = Math.max(8, (stage.value / maxFunnel) * 100);
                  const prev = i > 0 ? fun[i - 1].value : stage.value;
                  const conv = i > 0 ? ((stage.value / prev) * 100).toFixed(1) : '100';
                  return (
                    <div key={stage.label} className="text-xs">
                      <div className="mb-1 flex justify-between font-medium">
                        <span className="text-tx">{stage.label}</span>
                        <span className="font-bold text-tx">
                          {stage.value.toLocaleString()}{' '}
                          <span className="font-normal text-mu">({conv}%)</span>
                        </span>
                      </div>
                      <div className="h-2 rounded-full bg-p2 border border-bd/40 overflow-hidden">
                        <div
                          className="h-full rounded-full bg-tx transition-all duration-500"
                          style={{ width: `${pct}%` }}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>
            </Card>

            {/* Department Readiness & Radar */}
            <Card title="Department Readiness">
              <div className="space-y-2.5">
                {Object.entries(rd).map(([dept, val]) => (
                  <div key={dept} className="text-xs">
                    <div className="mb-1 flex justify-between">
                      <span className="font-medium text-tx">{dept}</span>
                      <b className={toneText[pctTone(val)]}>{val}%</b>
                    </div>
                    <Bar value={val} tone={pctTone(val)} />
                  </div>
                ))}
              </div>
              <div className="mt-4 flex justify-center">
                <div className="w-44">
                  <Radar axes={Object.entries(rd).map(([k, v]) => ({ label: k, value: v / 100 }))} />
                </div>
              </div>
            </Card>
          </div>
        </div>

        {/* RIGHT COLUMN: AI Intelligence Layer & Decision Support */}
        <aside aria-label="AI decision intelligence" className="flex flex-col gap-5">
          <Card
            title="Intelligence Layer / Narrative"
            right={
              <span className="rounded bg-tx text-bg px-2 py-0.5 text-[9px] font-bold uppercase tracking-wider">
                ACTIVE
              </span>
            }
            className="sticky top-16"
          >
            {/* Checklist with signature coral ticks (inspired by reference) */}
            <div className="space-y-2.5 text-xs">
              {insights.lines.map((line, idx) => (
                <div key={idx} className="flex gap-2 items-start">
                  <Check size={14} className="text-info shrink-0 mt-0.5 font-bold" />
                  <span className="text-tx leading-relaxed">{line}</span>
                </div>
              ))}
            </div>

            {/* Recommended Priority Box */}
            <div className="mt-5 rounded-xl border border-bd bg-p2 p-3.5 text-xs">
              <div className="flex items-center gap-1.5 font-bold uppercase tracking-wider text-[10px] text-mu">
                <Sparkles size={12} className="text-info" />
                Recommended Next Move
              </div>
              <p className="mt-1 font-editorial text-sm text-tx leading-relaxed">
                {insights.priority}
              </p>
            </div>

            {/* Action CTA with agency button styling */}
            <Link
              href="/actions"
              className="mt-4 flex w-full items-center justify-center gap-1.5 rounded-xl bg-info px-4 py-2.5 text-xs font-semibold text-white shadow-xs transition hover:opacity-90"
            >
              Open Recovery Action Centre <ArrowRight size={13} />
            </Link>

            {/* Embedded "Ask the Command Centre" Q&A */}
            <div className="mt-6 border-t border-bd/80 pt-4">
              <div className="mb-2 text-[10px] font-bold uppercase tracking-widest text-mu">
                Ask the Command Centre
              </div>
              
              <div className="flex gap-1.5">
                <input
                  value={qaInput}
                  onChange={(e) => setQaInput(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleAsk()}
                  placeholder="e.g. why is health low?"
                  aria-label="Ask the command centre"
                  className="flex-1 rounded-lg border border-bd bg-pn px-3 py-1.5 text-xs text-tx placeholder:text-mu focus:outline-none focus:border-tx"
                />
                <Btn variant="black" onClick={() => handleAsk()} className="text-xs">
                  Ask
                </Btn>
              </div>

              {/* Sample Question Chips */}
              <div className="mt-2 flex flex-wrap gap-1">
                {[
                  'forecast',
                  'top risk',
                  'logistics status',
                  'partner followups',
                ].map((chip) => (
                  <button
                    key={chip}
                    onClick={() => handleAsk(chip)}
                    className="rounded-full border border-bd bg-p2 px-2.5 py-0.5 text-[10px] text-mu hover:border-tx hover:text-tx transition cursor-pointer"
                  >
                    {chip}
                  </button>
                ))}
              </div>

              {/* Q&A Responses */}
              <div className="mt-3.5 space-y-2">
                {qaHistory.map((item, idx) => (
                  <div key={idx} className="rounded-lg border border-bd bg-p2 p-3 text-xs">
                    <div className="font-bold text-tx">Q: {item.q}</div>
                    <div className="mt-1 text-mu leading-relaxed">{item.a}</div>
                  </div>
                ))}
              </div>
            </div>

            {/* Demonstration Scenarios */}
            <div className="mt-6 border-t border-bd/80 pt-4">
              <div className="mb-2.5 text-[10px] font-bold uppercase tracking-widest text-mu">
                Test Scenarios (Demonstration)
              </div>
              <div className="grid grid-cols-2 gap-2">
                <Btn onClick={() => runScenario('registration-drop')} className="text-[11px] py-1">
                  Reg Drop
                </Btn>
                <Btn onClick={() => runScenario('logistics-crisis')} className="text-[11px] py-1">
                  Logistics Crisis
                </Btn>
                <Btn onClick={() => runScenario('recovery')} variant="primary" className="col-span-2 text-[11px] py-1.5 font-semibold">
                  Last-Minute Recovery
                </Btn>
              </div>
            </div>
          </Card>
        </aside>
      </div>
    </div>
  );
}