'use client';

import { useEvent } from '@/hooks/use-event';
import { Badge, Bar, Card, pctTone, toneText } from '@/components/ui';

export default function Operations() {
  const { s } = useEvent();
  const ops = s.metrics.opsReadiness;

  return (
    <div className="flex flex-col gap-6">
      {/* Editorial Header */}
      <div className="flex flex-col justify-between gap-4 border-b border-bd pb-6 md:flex-row md:items-end">
        <div>
          <div className="text-[11px] font-bold uppercase tracking-widest text-mu">
            Infrastructure &amp; Venues /
          </div>
          <h1 className="mt-1 text-3xl font-extrabold tracking-tight text-tx sm:text-4xl">
            Logistics &amp; <span className="font-editorial italic font-normal text-tx">Operations</span> Readiness
          </h1>
          <p className="mt-1.5 max-w-2xl text-xs text-mu leading-relaxed">
            Venue infrastructure audits and operational capability scores across physical, transport, security, and AV departments.
          </p>
        </div>

        <div className="flex items-center gap-3 self-start md:self-end">
          <div className="rounded-2xl border border-bd bg-pn px-5 py-3 shadow-sm">
            <div className="text-[10px] font-bold uppercase tracking-wider text-mu">Overall Operations Readiness</div>
            <div className={`mt-0.5 font-mono text-3xl font-black ${toneText[pctTone(ops)]}`}>
              {ops}%
            </div>
          </div>
        </div>
      </div>

      {/* Category Breakdown Cards */}
      <Card
        title="Departmental readiness tracking"
        right={<span className="text-xs text-mu">Target threshold: 70%</span>}
      >
        <div className="flex flex-col gap-5 pt-1">
          {Object.entries(s.categories).map(([k, v]) => {
            const isBlocker = v < 70;
            return (
              <div
                key={k}
                className="rounded-xl border border-bd bg-p2/40 p-4 transition hover:border-tx/30 hover:bg-p2"
              >
                <div className="mb-2 flex flex-wrap items-center justify-between gap-2 text-xs">
                  <div className="flex items-center gap-2">
                    <b className="text-sm font-bold text-tx">{k}</b>
                    <span className="text-[11px] text-mu">· Operations Squad</span>
                    {isBlocker && <Badge tone="crit">CRITICAL BLOCKER</Badge>}
                  </div>
                  <b className={`font-mono text-base ${toneText[pctTone(v)]}`}>{v}%</b>
                </div>
                <Bar value={v} />
              </div>
            );
          })}
        </div>
      </Card>
    </div>
  );
}
