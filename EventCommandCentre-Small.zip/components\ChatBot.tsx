"use client";
import { useState, useRef, useEffect } from "react";
import { MessageSquare, X, Send, Bot, Sparkles } from "lucide-react";

type Msg = { role: "user" | "assistant"; content: string };

function getPageContext() {
  if (typeof document === "undefined") return "";
  const clone = document.body.cloneNode(true) as HTMLElement;
  clone.querySelectorAll("script, style, #chatbot-root").forEach((el) => el.remove());
  return (clone.textContent || "").replace(/\s+/g, " ").trim().slice(0, 8000);
}

const QUICK_PROMPTS = [
  "How is our event health score?",
  "What is the top active risk?",
  "Forecast registrations vs target",
  "Recommended recovery action",
];

export default function ChatBot() {
  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState<Msg[]>([
    {
      role: "assistant",
      content: "👋 Hello! I am your Event Intelligence Assistant. Ask me anything about event health, active risks, velocity forecasts, or operational readiness.",
    },
  ]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (open) {
      bottomRef.current?.scrollIntoView({ behavior: "smooth" });
    }
  }, [messages, loading, open]);

  async function handleSend(textToSend?: string) {
    const text = (textToSend ?? input).trim();
    if (!text || loading) return;

    const newMessages: Msg[] = [...messages, { role: "user", content: text }];
    setMessages(newMessages);
    setInput("");
    setLoading(true);

    try {
      const toSend = newMessages.slice(1);
      const res = await fetch("/api/ai/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ messages: toSend, context: getPageContext() }),
      });
      const data = await res.json();
      setMessages([...newMessages, { role: "assistant", content: data.reply || "I am analyzing telemetry now. Please try again." }]);
    } catch {
      setMessages([
        ...newMessages,
        {
          role: "assistant",
          content: "Event intelligence is operational. Check the Active Risks and Registration chart for live telemetry.",
        },
      ]);
    }
    setLoading(false);
  }

  return (
    <div id="chatbot-root" className="fixed bottom-5 right-5 z-50">
      {open && (
        <aside
          role="complementary"
          aria-label="AI Event Intelligence Assistant"
          className="slidein mb-3 flex h-[480px] w-[350px] sm:w-[380px] max-w-[calc(100vw-2rem)] flex-col overflow-hidden rounded-2xl border border-bd bg-pn shadow-2xl backdrop-blur-md"
        >
          {/* Header */}
          <div className="flex items-center justify-between border-b border-bd bg-p2 px-4 py-3">
            <div className="flex items-center gap-2">
              <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-info/15 text-info">
                <Bot size={18} />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-sm font-bold text-tx">Event Copilot</span>
                  <span className="inline-flex items-center gap-1 rounded-full bg-ok/15 px-2 py-0.5 text-[10px] font-semibold text-ok">
                    <span className="h-1.5 w-1.5 rounded-full bg-ok animate-pulse" />
                    Online
                  </span>
                </div>
                <div className="text-[11px] text-mu">AI Event Intelligence &amp; Decision Support</div>
              </div>
            </div>
            <button
              onClick={() => setOpen(false)}
              className="rounded-lg p-1 text-mu transition hover:bg-pn hover:text-tx"
              aria-label="Close chat"
            >
              <X size={16} />
            </button>
          </div>

          {/* Quick prompt suggestions */}
          <div className="flex gap-1.5 overflow-x-auto border-b border-bd bg-pn/60 px-3 py-2 text-xs no-scrollbar">
            {QUICK_PROMPTS.map((prompt) => (
              <button
                key={prompt}
                onClick={() => handleSend(prompt)}
                disabled={loading}
                className="whitespace-nowrap rounded-full border border-bd bg-p2 px-2.5 py-1 text-[11px] text-mu transition hover:border-info hover:text-tx hover:bg-p2"
              >
                <Sparkles size={10} className="mr-1 inline text-info" />
                {prompt}
              </button>
            ))}
          </div>

          {/* Messages */}
          <div className="flex-1 space-y-3 overflow-y-auto p-3 text-xs">
            {messages.map((m, i) => (
              <div
                key={i}
                className={`flex gap-2 ${m.role === "user" ? "justify-end" : "justify-start"}`}
              >
                {m.role === "assistant" && (
                  <div className="mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-info/10 text-info">
                    <Bot size={13} />
                  </div>
                )}
                <div
                  className={`max-w-[85%] rounded-2xl px-3.5 py-2.5 leading-relaxed ${
                    m.role === "user"
                      ? "rounded-tr-sm bg-info font-medium text-white shadow-sm"
                      : "rounded-tl-sm border border-bd bg-p2 text-tx shadow-sm"
                  }`}
                >
                  <p className="whitespace-pre-wrap">{m.content}</p>
                </div>
              </div>
            ))}
            {loading && (
              <div className="flex items-center gap-2 text-mu">
                <div className="flex h-6 w-6 items-center justify-center rounded-full bg-info/10 text-info">
                  <Bot size={13} />
                </div>
                <div className="flex gap-1 rounded-2xl border border-bd bg-p2 px-3 py-2 text-xs">
                  <span className="h-1.5 w-1.5 rounded-full bg-info animate-bounce" />
                  <span className="h-1.5 w-1.5 rounded-full bg-info animate-bounce [animation-delay:0.2s]" />
                  <span className="h-1.5 w-1.5 rounded-full bg-info animate-bounce [animation-delay:0.4s]" />
                </div>
              </div>
            )}
            <div ref={bottomRef} />
          </div>

          {/* Input Box */}
          <div className="border-t border-bd bg-p2 p-2.5">
            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleSend();
              }}
              className="flex items-center gap-2"
            >
              <input
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Ask about health, risks, forecast…"
                disabled={loading}
                className="flex-1 rounded-xl border border-bd bg-pn px-3 py-2 text-xs text-tx placeholder:text-mu focus:border-info focus:outline-none"
              />
              <button
                type="submit"
                disabled={!input.trim() || loading}
                aria-label="Send message"
                className="flex h-8 w-8 items-center justify-center rounded-xl bg-info text-white shadow-md transition disabled:opacity-40"
              >
                <Send size={13} />
              </button>
            </form>
          </div>
        </aside>
      )}

      {/* Floating trigger button */}
      <button
        onClick={() => setOpen(!open)}
        aria-label="Toggle AI Event Assistant"
        className="group flex h-13 w-13 items-center justify-center rounded-full bg-info text-white shadow-xl transition-all duration-300 hover:scale-105 active:scale-95"
      >
        {open ? <X size={22} /> : <MessageSquare size={22} className="transition-transform group-hover:scale-110" />}
      </button>
    </div>
  );
}