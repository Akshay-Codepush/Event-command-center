import type { AppState } from '@/types/event';
import { actionsFor } from './actions';
import { managementSummary } from './ai';
import { departmentReadiness } from './metrics';

/** Plain-markdown management brief generated from live state (works offline, no AI needed). */
export function buildBrief(s: AppState): string {
  const m = s.metrics, h = s.health, ms = managementSummary(s), rd = departmentReadiness(s, m);
  const L: string[] = [
    `# ${s.event.name} — Management Brief`, `${s.event.venue}, ${s.event.city} · ${s.event.date} · ${m.daysLeft} days to event`, '',
    `## Status: ${h.status} (${h.score}/100)`,
    ...h.parts.map((p) => `- ${p.label}: +${Math.round(p.value)}`), `- Risk penalty: -${h.penalty.toFixed(1)}`, '',
    '## Key numbers',
    `- Registrations: ${s.registrations} / ${s.event.targetRegistrations} (${m.gapPct.toFixed(1)}%), forecast ${m.forecast}`,
    `- Attendance forecast: ${m.attendance} · Partner confirmation: ${s.partnerConfirmed}% · Operations: ${m.opsReadiness}%`,
    `- Tasks: ${m.tasksDone} / ${m.tasksTotal}`, '', '## Department readiness',
    ...Object.entries(rd).map(([k, v]) => `- ${k}: ${v}%`), '', `## Active risks (${s.risks.length})`,
  ];
  if (!s.risks.length) L.push('- None');
  s.risks.forEach((r) => {
    L.push(`### [${r.severity.toUpperCase()}] ${r.type} — ${r.status}`, `- ${r.explanation.what}`, `- Why: ${r.explanation.why}`, `- If nothing is done: ${r.impact}`,
      `- Owner: ${r.assignedRole}`, `- Recommended: ${actionsFor(r.id)[0]?.title ?? 'Escalate to Event Lead'}`, '');
  });
  L.push('## Management decision', `- Top priority: ${ms.topPriority}`, `- Biggest blocker: ${ms.blocker}`, `- Action: ${ms.action}`);
  if (s.lastOutcome) L.push('', `Last outcome: ${s.lastOutcome}`);
  return L.join('\n');
}
