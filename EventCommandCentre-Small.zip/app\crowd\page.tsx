"use client";
import { useState } from "react";
import Link from "next/link";
import { useCrowd, saveZone } from "@/lib/useCrowd";
import { USING_SUPABASE } from "@/lib/session";
import { Card, Btn, Badge } from "@/components/ui";
import { Flame, Sparkles, MapPin, Database, Check } from "lucide-react";

const ZONES = [
  { id: "gate", label: "Main Gate", desc: "Main entrance and ticket turnstiles" },
  { id: "stage", label: "Open Air Theatre", desc: "Keynote sessions and presentations" },
  { id: "stalls", label: "Stall Lawn", desc: "Sponsor exhibits and product showcases" },
  { id: "food", label: "Food Court", desc: "East lawn catering and food vendors" },
  { id: "canteen", label: "Canteen", desc: "Dining hall and refreshment tables" },
  { id: "sports", label: "Sports Grounds", desc: "Cricket & football grounds recreation" },
  { id: "parking", label: "Parking", desc: "Vehicle parking lots and drop-off" },
];

const START: Record<string, number> = {
  gate: 72,
  stage: 88,
  stalls: 64,
  food: 80,
  canteen: 55,
  sports: 25,
  parking: 45,
};

const SCENARIOS = [
  { name: "🌅 Quiet morning", values: { gate: 25, stage: 10, stalls: 15, food: 10, canteen: 10, sports: 20, parking: 30 } },
  { name: "🎤 Keynote rush", values: { gate: 40, stage: 95, stalls: 30, food: 25, canteen: 20, sports: 15, parking: 50 } },
  { name: "🍔 Lunch rush", values: { gate: 30, stage: 25, stalls: 45, food: 95, canteen: 90, sports: 20, parking: 40 } },
  { name: "🚪 Closing exit rush", values: { gate: 96, stage: 30, stalls: 35, food: 40, canteen: 30, sports: 15, parking: 92 } },
];

function level(d: number) {
  if (d < 40) return { text: "Low", color: "text-ok", bg: "bg-ok" };
  if (d < 70) return { text: "Medium", color: "text-warn", bg: "bg-warn" };
  return { text: "High", color: "text-crit", bg: "bg-crit" };
}

export default function CrowdControlPage() {
  const { density, setDensity } = useCrowd(START);
  const [msg, setMsg] = useState("");

  async function save(id: string, value: number) {
    const r = await saveZone(id, value);
    setMsg(r.error ? "Sync alert: " + r.error : "Telemetry synced — live viewers updated.");
    setTimeout(() => setMsg(""), 3500);
  }

  async function applyScenario(values: Record<string, number>) {
    setDensity((d) => ({ ...d, ...values }));
    const results = await Promise.all(Object.entries(values).map(([id, v]) => saveZone(id, v)));
    const failed = results.find((r) => r.error);
    setMsg(failed ? "Sync alert: " + failed.error : "Scenario broadcasted to all attendee maps.");
    setTimeout(() => setMsg(""), 3500);
  }

  return (
    <div className="mx-auto flex max-w-4xl flex-col gap-5">
      {/* Page Header */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-black text-tx">Crowd Operations &amp; Density Control</h1>
          <p className="mt-1 text-xs text-mu">
            Manage real-time zone congestion and heat signatures. Scanners, turnstiles, and venue leads broadcast these metrics live to attendee campus maps.
          </p>
        </div>
        <Link
          href="/attendee"
          className="flex items-center gap-1.5 rounded-xl border border-bd bg-pn px-3.5 py-2 text-xs font-bold text-info hover:border-info transition shadow-sm"
        >
          <MapPin size={14} /> View Live Attendee Map →
        </Link>
      </div>

      {/* Sync Status Banner */}
      <div className="flex items-center justify-between rounded-xl border border-bd bg-p2 px-4 py-2.5 text-xs">
        <div className="flex items-center gap-2">
          <Database size={15} className={USING_SUPABASE ? "text-ok" : "text-warn"} />
          <span className="font-semibold text-tx">
            {USING_SUPABASE ? "Supabase Realtime Sync Active" : "Local Simulation Mode (No external database connected)"}
          </span>
        </div>
        {msg && <span className="text-xs font-bold text-info animate-pulse">{msg}</span>}
      </div>

      {/* Quick Scenarios */}
      <Card title="Simulate Operational Rush Scenarios">
        <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
          {SCENARIOS.map((s) => (
            <button
              key={s.name}
              onClick={() => void applyScenario(s.values)}
              className="flex items-center justify-center rounded-xl border border-bd bg-p2 p-3 text-xs font-semibold text-tx transition hover:border-info hover:bg-pn"
            >
              {s.name}
            </button>
          ))}
        </div>
      </Card>

      {/* Zone Density Sliders */}
      <Card title="Live Zone Congestion Levels">
        <div className="divide-y divide-bd">
          {ZONES.map((z) => {
            const d = density[z.id] ?? 0;
            const lv = level(d);
            return (
              <div key={z.id} className="grid items-center gap-3 py-3.5 sm:grid-cols-[160px_1fr_100px]">
                <div>
                  <div className="font-bold text-xs text-tx">{z.label}</div>
                  <div className="text-[10px] text-mu">{z.desc}</div>
                </div>

                <div className="flex items-center gap-3">
                  <input
                    type="range"
                    min={0}
                    max={100}
                    value={d}
                    onChange={(e) => setDensity((prev) => ({ ...prev, [z.id]: Number(e.target.value) }))}
                    onPointerUp={() => void save(z.id, d)}
                    onKeyUp={() => void save(z.id, d)}
                    aria-label={`Density for ${z.label}`}
                    className="w-full"
                  />
                </div>

                <div className="text-right">
                  <span className={`inline-block rounded-md px-2 py-0.5 text-xs font-bold ${lv.color} bg-p2 border border-bd`}>
                    {lv.text} {d}%
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </Card>
    </div>
  );
}