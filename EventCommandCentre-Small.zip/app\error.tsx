'use client';
export default function Error({ error, reset }: { error: Error; reset: () => void }) {
  return <div role="alert" className="grid gap-2 rounded-lg border border-bd bg-pn p-6"><b className="text-crit">Something went wrong</b><span className="text-mu">{error.message}</span>
    <button className="w-fit rounded-md border border-bd bg-p2 px-3 py-1.5" onClick={reset}>Try again</button></div>;
}
