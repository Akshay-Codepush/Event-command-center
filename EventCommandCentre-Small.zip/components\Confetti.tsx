'use client';
import { useEvent } from '@/hooks/use-event';

const EMOJI = ['💖', '✨', '🌸', '🎉', '💗'];
/** Deterministic (no Math.random) so it never causes hydration mismatches. Hidden for reduced-motion users via CSS. */
export function Confetti() {
  const { party } = useEvent(); if (!party) return null;
  return (
    <div key={party} aria-hidden="true" className="pointer-events-none fixed inset-0 z-50 overflow-hidden">
      {Array.from({ length: 36 }, (_, i) => <span key={i} className="cf" style={{ left: `${(i * 53) % 100}vw`, fontSize: 14 + ((i * 7) % 16), animationDelay: `${(i % 8) * 0.1}s` }}>{EMOJI[i % 5]}</span>)}
    </div>
  );
}
