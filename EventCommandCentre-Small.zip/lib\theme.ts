/** Toggles blush (light) / plum (dark). Persists the choice; default follows the OS setting. */
export function toggleTheme() {
  const root = document.documentElement;
  const dark = root.dataset.theme ? root.dataset.theme === 'dark' : window.matchMedia('(prefers-color-scheme: dark)').matches;
  root.dataset.theme = dark ? 'light' : 'dark';
  try { localStorage.setItem('ecc-theme', root.dataset.theme); } catch { /* private mode */ }
}
