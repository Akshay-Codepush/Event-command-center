"use client";
import { useEffect, useState, type FormEvent } from "react";
import { useRouter } from "next/navigation";
import { login, signUp, USING_SUPABASE, DEMO_USERS } from "@/lib/session";
import { Shield, Sparkles, UserCheck, Lock, Mail, ArrowRight } from "lucide-react";

export default function LoginPage() {
  const router = useRouter();
  const [mode, setMode] = useState<"signin" | "signup">("signin");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (typeof window !== "undefined" && new URLSearchParams(window.location.search).get("mode") === "signup") {
      setMode("signup");
    }
  }, []);

  async function go(e: string, p: string, createFirst = false) {
    setError("");
    setBusy(true);
    if (createFirst) {
      const r = await signUp(e, p);
      if (r.error) {
        setError(r.error);
        setBusy(false);
        return;
      }
    }
    const res = await login(e, p);
    setBusy(false);
    if (!res.user) {
      setError(res.error ?? "Login failed. Please verify credentials.");
      return;
    }
    router.push(res.user.role === "manager" ? "/" : "/attendee");
  }

  function submit(ev: FormEvent) {
    ev.preventDefault();
    void go(email, password, mode === "signup");
  }

  return (
    <div className="flex min-h-screen items-center justify-center p-4 bg-bg text-tx">
      <div className="w-full max-w-md rounded-2xl border border-bd bg-pn p-8 shadow-2xl backdrop-blur-md">
        {/* Brand header */}
        <div className="mb-6 text-center">
          <div className="mx-auto mb-3 flex h-12 w-12 items-center justify-center rounded-2xl bg-info/15 text-info shadow-sm">
            <Shield size={24} />
          </div>
          <h1 className="text-2xl font-black tracking-tight text-tx">Event Command Centre</h1>
          <p className="mt-1 text-xs text-mu">
            {mode === "signin"
              ? "Sign in to access your intelligence control layer"
              : "Create an attendee viewer credential"}
          </p>
        </div>

        {/* Form */}
        <form onSubmit={submit} className="flex flex-col gap-3.5">
          <div>
            <label className="mb-1 block text-xs font-semibold text-mu">Email Address</label>
            <div className="relative">
              <input
                type="email"
                placeholder="name@organization.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                className="w-full rounded-xl border border-bd bg-p2 px-3.5 py-2.5 text-xs text-tx placeholder:text-mu focus:border-info focus:outline-none"
              />
              <Mail size={14} className="absolute right-3.5 top-3 text-mu" />
            </div>
          </div>

          <div>
            <label className="mb-1 block text-xs font-semibold text-mu">Password</label>
            <div className="relative">
              <input
                type="password"
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                minLength={6}
                className="w-full rounded-xl border border-bd bg-p2 px-3.5 py-2.5 text-xs text-tx placeholder:text-mu focus:border-info focus:outline-none"
              />
              <Lock size={14} className="absolute right-3.5 top-3 text-mu" />
            </div>
          </div>

          {error && (
            <div className="rounded-xl border border-crit/30 bg-crit/10 p-2.5 text-xs text-crit font-medium">
              {error}
            </div>
          )}

          <button
            type="submit"
            disabled={busy}
            className="mt-2 flex w-full items-center justify-center gap-2 rounded-xl bg-info py-2.5 text-xs font-bold text-white shadow-md transition hover:opacity-90 disabled:opacity-50"
          >
            {busy ? "Authenticating…" : mode === "signin" ? "Sign In to Control Layer" : "Create Account"}
            <ArrowRight size={14} />
          </button>

          {USING_SUPABASE && (
            <button
              type="button"
              onClick={() => {
                setError("");
                setMode(mode === "signin" ? "signup" : "signin");
              }}
              className="mt-1 text-xs text-mu transition hover:text-info text-center"
            >
              {mode === "signin" ? "Need an attendee account? Create one" : "Already have an account? Sign in"}
            </button>
          )}

          {/* Quick Demo Login (Hackathon Mode) */}
          <div className="mt-5 border-t border-bd pt-4">
            <div className="mb-2.5 flex items-center justify-between text-[11px] font-bold uppercase tracking-wider text-mu">
              <span>Quick Demo Sign-In</span>
              <span className="rounded bg-ok/15 px-1.5 py-0.5 text-[9px] font-bold text-ok">INSTANT</span>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => void go(DEMO_USERS[0].email, DEMO_USERS[0].password)}
                className="flex flex-col items-center justify-center rounded-xl border border-bd bg-p2 p-3 text-center transition hover:border-info hover:bg-pn"
              >
                <Sparkles size={16} className="text-info mb-1" />
                <span className="text-xs font-bold text-tx">Event Manager</span>
                <span className="text-[10px] text-mu">Full Command Centre</span>
              </button>
              <button
                type="button"
                onClick={() => void go(DEMO_USERS[1].email, DEMO_USERS[1].password)}
                className="flex flex-col items-center justify-center rounded-xl border border-bd bg-p2 p-3 text-center transition hover:border-info hover:bg-pn"
              >
                <UserCheck size={16} className="text-ok mb-1" />
                <span className="text-xs font-bold text-tx">Event Attendee</span>
                <span className="text-[10px] text-mu">Campus Blueprint &amp; Map</span>
              </button>
            </div>
          </div>

          <div className="mt-4 text-center text-[10px] text-mu">
            {USING_SUPABASE ? "⚡ Secured with Supabase Auth" : "🛡️ Local Simulation & Demo Mode Active"}
          </div>
        </form>
      </div>
    </div>
  );
}