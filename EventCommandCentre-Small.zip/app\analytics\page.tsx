'use client';

import { useState } from 'react';
import { useEvent } from '@/hooks/use-event';
import { enhance, managementSummary } from '@/lib/ai';
import { buildBrief } from '@/lib/brief';
import { departmentReadiness } from '@/lib/metrics';
import { Badge, Bar, Btn, Card, toneText } from '@/components/ui';
import { Bars, Trend } from '@/components/charts';

export default function Analytics() {
  const { s } = useEvent();
  const [ai, setAi] = useState<{ narrative: string; mode: 'claude' | 'demo' } | null>(null);
  const [isRefreshing, setIsRefreshing] = useState(false);

  const ms = managementSummary(s);
  const rd = departmentReadiness(s, s.metrics);
  const delta = s.healthHistory.at(-1)! - s.healthHistory[0];

  const handleDownload = () => {
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([buildBrief(s)], { type: 'text/markdown' }));
    a.download = `management-brief-${s.event.name.toLowerCase().replace(/\s+/g, '-')}.md`;
    a.click();
  };

  const handleRefresh = async () => {
    setIsRefreshing(true);
    try {
      const r = await enhance<{ narrative: string }>(
        'management-summary',
        {
          summary: ms,
          metrics: s.metrics,
          health: s.health,
          risks: s.risks.map((x) => ({ type: x.type, severity: x.severity })),
        },
        { narrative: '' }
      );
      setAi({ narrative: r.data.narrative, mode: r.mode });
    } finally {
      setIsRefreshing(false);
    }
  };

  const rows: { label: string; value: string; isStatus?: boolean }[] = [
    { label: 'Event Status', value: ms.status, isStatus: true },
    { label: 'Top Priority', value: ms.topPriority },
    { label: 'Biggest Blocker', value: ms.blocker },
    { label: 'Strongest Area', value: ms.strongest },
    { label: 'Forecast Pace', value: `${ms.forecast} registrations` },
    { label: 'Recommended Action', value: ms.action },
  ];

  return (
    <div className="flex flex-col gap-6">
      {/* Editorial Header */}
      <div className="flex flex-col justify-between gap-4 border-b border-bd pb-6 md:flex-row md:items-end">
        <div>
          <div className="text-[11px] font-bold uppercase tracking-widest text-mu">
            Executive Intelligence /
          </div>
          <h1 className="mt-1 text-3xl font-extrabold tracking-tight text-tx sm:text-4xl">
            Management <span className="font-editorial italic font-normal text-tx">Brief</span> &amp; Telemetry
          </h1>
          <p className="mt-1.5 max-w-2xl text-xs text-mu leading-relaxed">
            Continuous synthesis of health indicators, attendance projections, and cross-functional readiness metrics.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2 self-start md:self-end">
          <Btn
            variant="default"
            onClick={handleDownload}
            className="rounded-full px-3.5 py-1.5 text-xs font-semibold"
          >
            Download Brief (.md)
          </Btn>
          <Btn
            variant="primary"
            disabled={isRefreshing}
            onClick={handleRefresh}
            className="rounded-full px-4 py-1.5 text-xs font-semibold"
          >
            {isRefreshing ? 'Synthesizing…' : (
              <>Refresh with <span className="font-editorial italic font-normal">AI</span></>
            )}
          </Btn>
        </div>
      </div>

      {/* Structured Executive Brief Grid */}
      <div className="overflow-hidden rounded-2xl border border-bd bg-pn shadow-sm">
        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-bd bg-p2/50 px-5 py-3">
          <span className="text-xs font-bold uppercase tracking-wider text-tx">
            Executive Status Overview
          </span>
          {ai && (
            <Badge tone={ai.mode === 'claude' ? 'ok' : 'warn'}>
              {ai.mode === 'claude' ? 'CLAUDE INTELLIGENCE' : 'DETERMINISTIC SUMMARY'}
            </Badge>
          )}
        </div>

        <div className="grid divide-y divide-bd sm:grid-cols-2 sm:divide-y-0 sm:divide-x lg:grid-cols-3">
          {rows.map((item, idx) => (
            <div key={item.label} className={`p-4 ${idx >= 3 ? 'sm:border-t sm:border-bd' : ''}`}>
              <div className="text-[10px] font-bold uppercase tracking-wider text-mu">
                {item.label}
              </div>
              <div className={`mt-1 text-sm font-bold ${item.isStatus ? toneText[s.health.tone] : 'text-tx'}`}>
                {item.value}
              </div>
            </div>
          ))}
        </div>

        {ai?.narrative && (
          <div className="border-t border-bd bg-p2 p-4 text-xs">
            <div className="text-[10px] font-bold uppercase tracking-wider text-mu mb-1">
              AI Generated Executive Synthesis
            </div>
            <p className="font-editorial italic text-base leading-relaxed text-tx">
              "{ai.narrative}"
            </p>
          </div>
        )}
      </div>

      {/* Analytical Charts Grid */}
      <div className="grid gap-5 md:grid-cols-2">
        <Card
          title="Health score over time"
          right={<span className="text-xs text-mu">{s.healthHistory.length} checkpoints</span>}
        >
          <div className="pt-2">
            <Trend values={s.healthHistory} />
          </div>
        </Card>

        <Card
          title="Risk count over time"
          right={<span className="text-xs text-mu">Active bottleneck trend</span>}
        >
          <div className="pt-2">
            <Trend values={s.riskHistory} color="var(--r)" />
          </div>
        </Card>

        <Card
          title="Registration velocity"
          right={<span className="text-xs text-mu">Registrations per interval</span>}
        >
          <div className="pt-2">
            <Bars values={s.velocity} />
          </div>
        </Card>

        <Card
          title="Department readiness"
          right={<span className="text-xs text-mu">Across core sectors</span>}
        >
          <div className="flex flex-col gap-3 pt-1">
            {Object.entries(rd).map(([dept, val]) => (
              <div key={dept} className="grid grid-cols-[110px_1fr_45px] items-center gap-3 text-xs">
                <span className="font-semibold text-tx">{dept}</span>
                <Bar value={val} />
                <b className="text-right font-mono text-tx">{val}%</b>
              </div>
            ))}
          </div>
        </Card>
      </div>

      {/* Recovery Effectiveness Strip */}
      <div className="flex flex-wrap items-center justify-between gap-4 rounded-2xl border border-bd bg-pn p-5 shadow-2xs">
        <div>
          <div className="text-xs font-bold uppercase tracking-wider text-mu">Recovery Effectiveness</div>
          <div className="mt-1 text-sm text-tx">
            <b className="font-mono">{s.tasks.filter((t) => t.applied && t.milestoneId === 'RECOVERY').length}</b> recovery interventions applied and resolved.
          </div>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-xs text-mu">Net Health Change:</span>
          <span className={`font-mono text-xl font-black ${delta >= 0 ? 'text-ok' : 'text-crit'}`}>
            {delta >= 0 ? `+${delta}` : delta} pts
          </span>
        </div>
      </div>
    </div>
  );
}
