import type { AppState, HealthResult, Metrics } from '@/types/event';
import type { Risk } from '@/types/risk';
import { SEVERITY_META } from './risk-engine';

// Weights: Registration 25, Tasks 20, Partners 15, Operations 20, Conversion 10, Risk penalty up to -10.
const credit = (x: number) => 0.5 + 0.5 * Math.min(1, x); // every dimension keeps a 50% floor so one weak area never zeroes the score

/** STEP 6 of the loop: transparent, recomputed on every state change. */
export function computeHealth(s: AppState, m: Metrics, risks: Risk[]): HealthResult {
  const parts = [
    { label: 'Registration performance', value: 25 * credit(s.registrations / s.event.targetRegistrations) },
    { label: 'Task completion', value: 20 * credit(m.tasksDone / m.tasksTotal) },
    { label: 'Partner readiness', value: 15 * credit(s.partnerConfirmed / 100) },
    { label: 'Logistics readiness', value: 20 * credit(m.opsReadiness / 100) },
    { label: 'Attendance conversion', value: 10 * credit(s.conversion / 80) },
  ];
  const penalty = Math.min(10, risks.reduce((a, r) => a + SEVERITY_META[r.severity].penalty, 0));
  const score = Math.max(0, Math.round(parts.reduce((a, p) => a + p.value, 0) - penalty));
  const status = score >= 90 ? 'EXCELLENT' : score >= 75 ? 'HEALTHY' : score >= 60 ? 'WATCH' : score >= 40 ? 'AT RISK' : 'CRITICAL';
  return { score, status, tone: score >= 75 ? 'ok' : score >= 60 ? 'warn' : 'crit', parts, penalty };
}

export const mood = (score: number) => (score >= 90 ? '🤩' : score >= 75 ? '😊' : score >= 60 ? '🫠' : score >= 40 ? '😬' : '🚨');
