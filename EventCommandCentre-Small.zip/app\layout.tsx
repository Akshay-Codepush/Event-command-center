import ChatBot from "@/components/ChatBot";
import AuthGate from "@/components/AuthGate";
import type { Metadata, Viewport } from 'next';
import type { ReactNode } from 'react';
import './globals.css';

export const metadata: Metadata = { title: 'Event Command Centre', description: 'AI-powered Event Intelligence & Decision Support System' };
export const viewport: Viewport = { width: 'device-width', initialScale: 1, viewportFit: 'cover' };
const restoreTheme = `try{var t=localStorage.getItem('ecc-theme');if(t)document.documentElement.dataset.theme=t}catch(e){}`;

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link href="https://fonts.googleapis.com/css2?family=Instrument+Serif:ital@0;1&family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet" />
        <script dangerouslySetInnerHTML={{ __html: restoreTheme }} />
      </head>
      <body>
        <AuthGate>{children}</AuthGate>
        <ChatBot />
      </body>
    </html>
  );
}