import type { ReactNode, ButtonHTMLAttributes } from 'react';
import type { Severity } from '@/types/risk';
import { SEVERITY_META } from '@/lib/risk-engine';
import { dueDateLabel } from '@/lib/dates';

export type Tone = 'ok' | 'warn' | 'crit' | 'info' | 'mu';
export const toneText: Record<Tone, string> = {
  ok: 'text-ok',
  warn: 'text-warn',
  crit: 'text-crit',
  info: 'text-info',
  mu: 'text-mu',
};
export const toneBg: Record<Tone, string> = {
  ok: 'bg-ok',
  warn: 'bg-warn',
  crit: 'bg-crit',
  info: 'bg-info',
  mu: 'bg-mu',
};
export const pctTone = (v: number): Tone => (v >= 85 ? 'ok' : v >= 70 ? 'warn' : 'crit');

export function Card({
  title,
  right,
  children,
  className = '',
}: {
  title?: ReactNode;
  right?: ReactNode;
  children: ReactNode;
  className?: string;
}) {
  return (
    <section className={`rounded-xl border border-bd bg-pn p-5 transition-shadow ${className}`}>
      {title && (
        <div className="mb-3.5 flex items-center justify-between border-b border-bd/60 pb-2.5">
          <h3 className="text-[11px] font-bold uppercase tracking-widest text-mu">
            {title}
          </h3>
          {right && <div className="text-xs">{right}</div>}
        </div>
      )}
      {children}
    </section>
  );
}

export function Badge({
  tone = 'info',
  children,
  className = '',
}: {
  tone?: Tone;
  children: ReactNode;
  className?: string;
}) {
  return (
    <span
      className={`inline-flex items-center gap-1 whitespace-nowrap rounded-md border border-current/30 px-2 py-0.5 text-[10px] font-bold tracking-wider uppercase ${toneText[tone]} ${className}`}
    >
      {children}
    </span>
  );
}

export const SevBadge = ({ severity }: { severity: Severity }) => (
  <Badge tone={SEVERITY_META[severity].tone}>{SEVERITY_META[severity].label}</Badge>
);

export function Btn({
  variant = 'default',
  className = '',
  ...p
}: ButtonHTMLAttributes<HTMLButtonElement> & {
  variant?: 'default' | 'primary' | 'success' | 'black';
}) {
  const v = {
    default:
      'bg-pn border-bd text-tx font-medium hover:border-tx hover:bg-p2 shadow-xs',
    primary:
      'btn-primary bg-info border-info text-white font-semibold shadow-sm hover:opacity-95',
    success:
      'bg-ok border-ok text-white font-semibold hover:opacity-95 shadow-sm',
    black:
      'bg-tx border-tx text-bg font-semibold hover:opacity-90 shadow-sm',
  }[variant];

  return (
    <button
      {...p}
      className={`inline-flex items-center justify-center gap-1.5 rounded-lg border px-3 py-1.5 text-xs transition-all duration-150 cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed ${v} ${className}`}
    />
  );
}

export function Bar({ value, tone }: { value: number; tone?: Tone }) {
  const t = tone ?? pctTone(value);
  return (
    <div
      className="h-1.5 overflow-hidden rounded-full bg-p2 border border-bd/50"
      role="progressbar"
      aria-valuenow={Math.round(value)}
      aria-valuemin={0}
      aria-valuemax={100}
    >
      <div
        className={`h-full transition-all duration-500 ${toneBg[t]}`}
        style={{ width: `${Math.max(0, Math.min(100, value))}%` }}
      />
    </div>
  );
}

export const Empty = ({ children }: { children: ReactNode }) => (
  <div className="py-8 text-center text-xs text-mu">{children}</div>
);

export const due = (d: number) => (
  <>
    {d < 0 ? (
      <span className="text-crit font-bold">{-d}d overdue</span>
    ) : d === 0 ? (
      <b className="text-warn">Today</b>
    ) : (
      <span>in {d}d</span>
    )}
    <span className="block text-[10px] text-mu">{dueDateLabel(d)}</span>
  </>
);
