import type { AppState, Effect } from '@/types/event';
import type { RecoveryAction } from '@/types/risk';
import type { Task } from '@/types/task';
import { actionsFor } from './actions';
import { OWNERS } from '@/data/demo-data';

export type ScenarioId = 'normal' | 'registration-drop' | 'partner-dropoff' | 'logistics-crisis' | 'recovery';
export const SCENARIOS: { id: ScenarioId; label: string }[] = [
  { id: 'normal', label: 'NORMAL' }, { id: 'registration-drop', label: 'REGISTRATION DROP' }, { id: 'partner-dropoff', label: 'PARTNER DROP-OFF' },
  { id: 'logistics-crisis', label: 'LOGISTICS CRISIS' }, { id: 'recovery', label: 'LAST-MINUTE RECOVERY' },
];

/** Outcome model: applies the metric changes a completed recovery task is expected to cause. Mutates a draft. */
export function applyEffect(s: AppState, e?: Effect) {
  if (!e) return;
  s.registrations += e.reg ?? 0;
  s.partnerConfirmed = Math.min(100, s.partnerConfirmed + (e.p ?? 0));
  s.conversion = Math.min(99, s.conversion + (e.c ?? 0));
  if (e.v) s.velocity.push(e.v);
  Object.entries(e.cat ?? {}).forEach(([k, d]) => (s.categories[k] = Math.min(100, s.categories[k] + d)));
  (e.fix ?? []).forEach((id) => { const t = s.tasks.find((x) => x.id === id); if (t) t.status = 'Completed'; });
}

export function taskFromAction(s: AppState, a: RecoveryAction): Task {
  const role = s.actionOwner[a.id] ?? a.ownerRole;
  const task: Task = { id: `TSK-${200 + s.tasks.length}`, eventId: s.event.id, title: s.actionTitle[a.id] ?? a.title, description: a.description,
    why: `Recovery action for: ${s.riskNames[a.riskId] ?? a.riskId}`, role, owner: OWNERS[role], priority: a.impact === 'HIGH' ? 'High' : 'Medium',
    status: 'Not Started', dueInDays: 1, milestoneId: 'RECOVERY', riskId: a.riskId, effect: a.effect, log: ['Created from AI recovery recommendation', `Assigned to ${role}`] };
  s.tasks.push(task); s.actionState[a.id] = 'task';
  return task;
}

export function finishTask(t: Task, s: AppState) {
  t.status = 'Completed'; t.log.push('Completed · metrics updated');
  if (!t.applied) { t.applied = true; applyEffect(s, t.effect); }
}

/** Mutates a draft state to the scenario conditions; caller then runs settle(). */
export function applyScenario(s: AppState, id: ScenarioId) {
  const find = (tid: string) => s.tasks.find((t) => t.id === tid)!;
  if (id === 'registration-drop') { s.registrations = Math.min(s.registrations, 588); s.velocity = [34, 29, 23, 18, 13, 9, 6]; }
  if (id === 'partner-dropoff') { s.partnerConfirmed = 52; s.conversion = 66; }
  if (id === 'logistics-crisis') { find('TSK-106').status = 'Blocked'; find('TSK-107').dueInDays = -2; s.categories.Transport = 35; s.categories.AV = 45; }
  if (id === 'recovery') s.risks.forEach((r) => actionsFor(r.id).slice(0, 2).forEach((a) => { if (!s.actionState[a.id]) finishTask(taskFromAction(s, a), s); }));
}
