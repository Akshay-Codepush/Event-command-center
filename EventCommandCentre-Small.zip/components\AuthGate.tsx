"use client";
import { useEffect, useState, type ReactNode } from "react";
import { usePathname, useRouter } from "next/navigation";
import { Shell } from "@/components/Shell";
import { getUser, logout } from "@/lib/session";
import type { User } from "@/lib/auth";

export default function AuthGate({ children }: { children: ReactNode }) {
const pathname = usePathname();
const router = useRouter();
const [okPath, setOkPath] = useState<string | null>(null);
const [user, setUser] = useState<User | null>(null);

useEffect(() => {
    let cancelled = false;

    (async () => {
    const u = await getUser();
    if (cancelled) return;
    setUser(u);

      // Login page: if already logged in, send them to their home
    if (pathname === "/login") {
        if (u) {
        router.replace(u.role === "manager" ? "/" : "/attendee");
        return;
        }
        setOkPath(pathname);
        return;
    }

      // Not logged in -> go to login
    if (!u) {
        router.replace("/login");
        return;
    }

      // Viewers can only see /attendee
    if (u.role === "viewer" && pathname !== "/attendee") {
        router.replace("/attendee");
        return;
    }

    setOkPath(pathname);
    })();

    return () => {
    cancelled = true;
    };
}, [pathname, router]);

async function handleLogout() {
    await logout();
    setUser(null);
    setOkPath(null);
    router.replace("/login");
}

  // Show nothing until the check is done (prevents a flash of the wrong page)
if (okPath !== pathname) return null;

  // Login and attendee pages don't use the manager sidebar
const bare = pathname === "/login" || pathname === "/attendee";

return <>{bare ? children : <Shell>{children}</Shell>}</>;
}