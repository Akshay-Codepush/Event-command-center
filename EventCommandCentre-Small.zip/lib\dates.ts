/** Demo "today" (fixed, so the demo is repeatable). Live mode switches to the real calendar. */
export const DEMO_TODAY = '2026-10-09';
let today = DEMO_TODAY;
export const setToday = (d: string) => { today = d; };
const DAY = 864e5;
export const daysUntil = (date: string) => Math.max(0, Math.round((Date.parse(date) - Date.parse(today)) / DAY));
export const dueDateLabel = (offset: number) =>
  new Date(Date.parse(today) + offset * DAY).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', timeZone: 'UTC' });