'use client';

import { useState } from 'react';
import { useEvent } from '@/hooks/use-event';
import { actionsFor } from '@/lib/actions';
import { enhance } from '@/lib/ai';
import { Badge, Btn, Card, Empty, SevBadge } from '@/components/ui';
import { ActionRow } from '@/components/risks';

interface Rank {
  order: string[];
  rationale: string;
  mode: 'claude' | 'demo';
}

export default function Actions() {
  const { s } = useEvent();
  const [ranks, setRanks] = useState<Record<string, Rank>>({});
  const [loadingRiskId, setLoadingRiskId] = useState<string | null>(null);

  const rank = async (riskId: string) => {
    setLoadingRiskId(riskId);
    try {
      const acts = actionsFor(riskId);
      const r = await enhance<{ order: string[]; rationale: string }>(
        'recovery-ranking',
        {
          risk: s.risks.find((x) => x.id === riskId),
          actions: acts.map((a) => ({ id: a.id, title: a.title, impact: a.impact, effort: a.effort })),
        },
        { order: acts.map((a) => a.id), rationale: '' }
      );
      const valid = r.data.order?.length === acts.length && acts.every((a) => r.data.order.includes(a.id));
      setRanks((p) => ({
        ...p,
        [riskId]: {
          order: valid ? r.data.order : acts.map((a) => a.id),
          rationale: r.data.rationale ?? '',
          mode: valid ? r.mode : 'demo',
        },
      }));
    } finally {
      setLoadingRiskId(null);
    }
  };

  const totalActionsCount = s.risks.reduce((acc, r) => acc + actionsFor(r.id).length, 0);

  return (
    <div className="flex flex-col gap-6">
      {/* Editorial Header */}
      <div className="flex flex-col justify-between gap-4 border-b border-bd pb-6 md:flex-row md:items-end">
        <div>
          <div className="text-[11px] font-bold uppercase tracking-widest text-mu">
            Closed-Loop Mitigation /
          </div>
          <h1 className="mt-1 text-3xl font-extrabold tracking-tight text-tx sm:text-4xl">
            Recovery <span className="font-editorial italic font-normal text-tx">Action</span> Engine
          </h1>
          <p className="mt-1.5 max-w-2xl text-xs text-mu leading-relaxed">
            Prescriptive counter-measures synthesized for active bottlenecks. Apply interventions to simulate immediate impact on attendance and health scores.
          </p>
        </div>

        <div className="flex items-center gap-2 self-start md:self-end">
          <span className="rounded-full border border-bd bg-p2 px-3 py-1.5 text-xs font-bold text-tx shadow-2xs">
            {totalActionsCount} recovery playbooks available
          </span>
        </div>
      </div>

      {/* Action Groups */}
      {s.risks.length ? (
        <div className="flex flex-col gap-5">
          {s.risks.map((r) => {
            const rk = ranks[r.id];
            const acts = actionsFor(r.id).sort((a, b) =>
              rk ? rk.order.indexOf(a.id) - rk.order.indexOf(b.id) : 0
            );

            return (
              <div
                key={r.id}
                className="overflow-hidden rounded-2xl border border-bd bg-pn shadow-sm transition hover:border-tx/30"
              >
                {/* Header of Risk Card */}
                <div className="flex flex-wrap items-center justify-between gap-3 border-b border-bd bg-p2/50 p-4">
                  <div className="flex flex-wrap items-center gap-2.5">
                    <SevBadge severity={r.severity} />
                    <span className="text-sm font-bold text-tx">{r.type}</span>
                    <span className="text-xs text-mu">· Assigned to {r.assignedRole}</span>
                  </div>

                  <div className="flex items-center gap-2">
                    {rk && (
                      <Badge tone={rk.mode === 'claude' ? 'ok' : 'warn'}>
                        {rk.mode === 'claude' ? 'CLAUDE INTELLIGENCE' : 'DETERMINISTIC RANK'}
                      </Badge>
                    )}
                    <Btn
                      variant="primary"
                      disabled={loadingRiskId === r.id}
                      onClick={() => rank(r.id)}
                      className="rounded-full px-3.5 py-1 text-xs"
                    >
                      {loadingRiskId === r.id ? 'Optimizing…' : (
                        <>Re-rank with <span className="font-editorial italic font-normal">AI</span></>
                      )}
                    </Btn>
                  </div>
                </div>

                {/* AI Rationale banner if available */}
                {rk?.rationale && (
                  <div className="border-b border-bd bg-accent/5 p-3.5 text-xs text-tx">
                    <div className="text-[10px] font-bold uppercase tracking-wider text-accent mb-0.5">
                      Strategic Optimization Rationale
                    </div>
                    <p className="italic text-mu">{rk.rationale}</p>
                  </div>
                )}

                {/* Actions rows */}
                <div className="divide-y divide-bd p-2">
                  {acts.map((a) => (
                    <ActionRow key={a.id} a={a} />
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        <Empty>
          <div className="py-8">
            <span className="font-editorial italic text-2xl text-tx">No recovery needed.</span>
            <p className="mt-1 text-xs text-mu">All systems are currently running within safe operational tolerances.</p>
          </div>
        </Empty>
      )}
    </div>
  );
}
