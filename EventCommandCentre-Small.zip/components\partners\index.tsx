'use client';
import { useEffect, useState } from 'react';
import { useEvent } from '@/hooks/use-event';
import { enhance, followUpTemplate } from '@/lib/ai';
import { Badge, Btn } from '@/components/ui';

export function FollowUpBody({ id }: { id: string }) {
  const { s, logFollowUp, closeDrawer } = useEvent();
  const p = s.partners.find((x) => x.id === id);
  const [msg, setMsg] = useState<{ text: string; mode: string }>({ text: p ? followUpTemplate(p, s) : '', mode: 'demo' });
  useEffect(() => { if (!p) return; enhance('follow-up', { partner: p, event: s.event.name }, { message: followUpTemplate(p, s) }).then((r) => setMsg({ text: r.data.message, mode: r.mode })); }, [id]); // eslint-disable-line react-hooks/exhaustive-deps
  if (!p) return null;
  return (
    <>
      <h2 className="text-lg font-semibold">Follow-up: {p.name}</h2>
      <div className="mb-2 text-xs text-mu">{p.status} · {p.confirmationProbability}% probability <Badge tone={msg.mode === 'claude' ? 'ok' : 'warn'}>{msg.mode === 'claude' ? 'CLAUDE' : 'DEMO INTELLIGENCE'}</Badge></div>
      <p className="rounded-md bg-p2 p-3">{msg.text}</p>
      <div className="flex gap-2"><Btn onClick={() => navigator.clipboard?.writeText(msg.text)}>Copy</Btn>
        <Btn variant="primary" onClick={() => { logFollowUp(p.id); closeDrawer(); }}>Mark as sent</Btn></div>
    </>
  );
}
