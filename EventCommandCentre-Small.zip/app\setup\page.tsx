'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { useEvent } from '@/hooks/use-event';
import { ROLES, type Role } from '@/types/event';
import { enhance } from '@/lib/ai';
import { DEFAULT_FORM, OBJECTIVES, generatePlan, sanitizeAiTasks, type SetupForm } from '@/lib/plan';
import { Badge, Btn, Card } from '@/components/ui';

const STEPS = [
  'Analyzing event brief & core parameters…',
  'Structuring phased milestone roadmap…',
  'Generating role-specific accountability tasks…',
  'Projecting non-linear registration curve…',
  'Calibrating autonomous risk surveillance engine…',
  'Event Command Centre ready.',
];

const TITLES = [
  'Event Basics',
  'Target Audience',
  'Strategic Objectives',
  'Departmental Structure',
  'Synthesize Plan',
];

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

const Field = ({ label, children }: { label: string; children: React.ReactNode }) => (
  <label className="flex flex-col gap-1.5 text-xs font-semibold text-tx">
    <span className="text-[11px] font-bold uppercase tracking-wider text-mu">{label}</span>
    {children}
  </label>
);

export default function Setup() {
  const { s, applySetup } = useEvent();
  const router = useRouter();

  const [f, setF] = useState<SetupForm>({
    ...DEFAULT_FORM,
    name: s.event.name,
    date: s.event.date,
    venue: s.event.venue,
    city: s.event.city,
    targetRegistrations: s.event.targetRegistrations,
    expectedAttendance: s.event.expectedAttendance,
  });

  const [step, setStep] = useState(0);
  const [done, setDone] = useState<string[]>([]);
  const [busy, setBusy] = useState(false);
  const [mode, setMode] = useState<'claude' | 'demo' | null>(null);

  const set = <K extends keyof SetupForm>(k: K, v: SetupForm[K]) => setF((p) => ({ ...p, [k]: v }));
  const toggle = <T,>(arr: T[], v: T) => (arr.includes(v) ? arr.filter((x) => x !== v) : [...arr, v]);
  const valid = f.name.trim() && f.date && f.targetRegistrations > 0 && f.roles.length > 0;

  const generate = async () => {
    setBusy(true);
    setDone([STEPS[0]]);
    const ai = await enhance<{ summary: string; tasks: unknown[] }>(
      'plan',
      { form: f, baseline: generatePlan(f).map((t) => t.title) },
      { summary: '', tasks: [] }
    );
    setMode(ai.mode);
    for (let i = 1; i < STEPS.length; i++) {
      await sleep(420);
      setDone((d) => [...d, STEPS[i]]);
    }
    const n = applySetup(f, [...generatePlan(f), ...sanitizeAiTasks(ai.data.tasks, f.roles)]);
    await sleep(600);
    setBusy(false);
    router.push(n ? '/plan' : '/');
  };

  return (
    <div className="flex flex-col gap-6 max-w-4xl mx-auto">
      {/* Editorial Header */}
      <div className="flex flex-col justify-between gap-4 border-b border-bd pb-6 md:flex-row md:items-end">
        <div>
          <div className="text-[11px] font-bold uppercase tracking-widest text-mu">
            Event Setup Studio /
          </div>
          <h1 className="mt-1 text-3xl font-extrabold tracking-tight text-tx sm:text-4xl">
            Event <span className="font-editorial italic font-normal text-tx">Setup</span> Studio
          </h1>
          <p className="mt-1.5 max-w-2xl text-xs text-mu leading-relaxed">
            Initialize an event profile. The system will automatically construct the milestone calendar, assign departmental responsibilities, and arm risk rules.
          </p>
        </div>

        <div className="flex items-center gap-2 self-start md:self-end">
          <span className="rounded-full border border-bd bg-p2 px-3.5 py-1.5 font-mono text-xs font-bold text-tx shadow-2xs">
            Step {step + 1} of 5
          </span>
        </div>
      </div>

      {/* Step Progress Bar */}
      <div className="grid grid-cols-5 gap-2">
        {TITLES.map((t, idx) => (
          <div key={t} className="flex flex-col gap-1.5">
            <div
              className={`h-1.5 rounded-full transition-all duration-300 ${
                idx <= step ? 'bg-accent' : 'bg-bd'
              }`}
            />
            <span className={`hidden sm:inline text-[10px] font-bold uppercase tracking-wider truncate ${
              idx === step ? 'text-accent' : idx < step ? 'text-tx' : 'text-mu'
            }`}>
              {t}
            </span>
          </div>
        ))}
      </div>

      {/* Step Form Container */}
      <Card
        title={`Step ${step + 1} — ${TITLES[step]}`}
        right={<span className="text-xs text-mu">Interactive Planner</span>}
      >
        {/* Step 1: Basics */}
        {step === 0 && (
          <div className="grid gap-4 sm:grid-cols-2 pt-1">
            <Field label="Event Name">
              <input
                value={f.name}
                onChange={(e) => set('name', e.target.value)}
                placeholder="e.g. European Tech Summit 2026"
                className="rounded-xl border border-bd bg-p2 px-3.5 py-2.5 text-xs font-medium text-tx focus:border-tx focus:outline-none"
              />
            </Field>

            <Field label="Event Format / Type">
              <select
                value={f.type}
                onChange={(e) => set('type', e.target.value)}
                className="rounded-xl border border-bd bg-p2 px-3.5 py-2.5 text-xs font-medium text-tx focus:border-tx focus:outline-none"
              >
                {['Conference', 'Hackathon', 'Expo', 'Workshop'].map((o) => (
                  <option key={o} value={o}>
                    {o}
                  </option>
                ))}
              </select>
            </Field>

            <Field label="Event Date">
              <input
                type="date"
                value={f.date}
                onChange={(e) => set('date', e.target.value)}
                className="rounded-xl border border-bd bg-p2 px-3.5 py-2.5 text-xs font-medium text-tx focus:border-tx focus:outline-none"
              />
            </Field>

            <Field label="Duration (Days)">
              <input
                type="number"
                min={1}
                value={f.duration}
                onChange={(e) => set('duration', +e.target.value)}
                className="rounded-xl border border-bd bg-p2 px-3.5 py-2.5 text-xs font-medium text-tx focus:border-tx focus:outline-none"
              />
            </Field>

            <Field label="Venue Location">
              <input
                value={f.venue}
                onChange={(e) => set('venue', e.target.value)}
                placeholder="e.g. Congress Center Hall A"
                className="rounded-xl border border-bd bg-p2 px-3.5 py-2.5 text-xs font-medium text-tx focus:border-tx focus:outline-none"
              />
            </Field>

            <Field label="Host City">
              <input
                value={f.city}
                onChange={(e) => set('city', e.target.value)}
                placeholder="e.g. Zurich, Switzerland"
                className="rounded-xl border border-bd bg-p2 px-3.5 py-2.5 text-xs font-medium text-tx focus:border-tx focus:outline-none"
              />
            </Field>
          </div>
        )}

        {/* Step 2: Audience */}
        {step === 1 && (
          <div className="grid gap-4 sm:grid-cols-2 pt-1">
            <Field label="Target Audience Profile">
              <input
                value={f.audience}
                onChange={(e) => set('audience', e.target.value)}
                placeholder="e.g. Tech Founders &amp; Operators"
                className="rounded-xl border border-bd bg-p2 px-3.5 py-2.5 text-xs font-medium text-tx focus:border-tx focus:outline-none"
              />
            </Field>

            <Field label="Total Audience TAM">
              <input
                type="number"
                value={f.audienceSize}
                onChange={(e) => set('audienceSize', +e.target.value)}
                className="rounded-xl border border-bd bg-p2 px-3.5 py-2.5 text-xs font-medium text-tx focus:border-tx focus:outline-none"
              />
            </Field>

            <Field label="Registration Target">
              <input
                type="number"
                min={1}
                value={f.targetRegistrations}
                onChange={(e) => set('targetRegistrations', +e.target.value)}
                className="rounded-xl border border-bd bg-p2 px-3.5 py-2.5 text-xs font-medium text-tx focus:border-tx focus:outline-none"
              />
            </Field>

            <Field label="Expected Physical Attendance">
              <input
                type="number"
                value={f.expectedAttendance}
                onChange={(e) => set('expectedAttendance', +e.target.value)}
                className="rounded-xl border border-bd bg-p2 px-3.5 py-2.5 text-xs font-medium text-tx focus:border-tx focus:outline-none"
              />
            </Field>
          </div>
        )}

        {/* Step 3: Objectives */}
        {step === 2 && (
          <div className="flex flex-col gap-4 pt-1">
            <div>
              <div className="text-[11px] font-bold uppercase tracking-wider text-mu mb-2">
                Primary Event Objectives
              </div>
              <div className="flex flex-wrap gap-2">
                {OBJECTIVES.map((o) => {
                  const isChecked = f.objectives.includes(o);
                  return (
                    <button
                      type="button"
                      key={o}
                      onClick={() => set('objectives', toggle(f.objectives, o))}
                      className={`rounded-full px-3.5 py-1.5 text-xs font-semibold transition ${
                        isChecked
                          ? 'bg-ink text-white shadow-2xs'
                          : 'border border-bd bg-p2 text-tx hover:border-tx'
                      }`}
                    >
                      {isChecked ? '✓ ' : '+ '}
                      {o}
                    </button>
                  );
                })}
              </div>
            </div>

            <Field label="Strategic Brief &amp; Context (Optional for AI Planning)">
              <textarea
                rows={4}
                value={f.brief}
                onChange={(e) => set('brief', e.target.value)}
                placeholder="Provide special context, sponsor agreements, keynote speakers, or logistical constraints. Claude uses this brief to compose custom tasks and risks."
                className="rounded-xl border border-bd bg-p2 p-3 text-xs font-medium text-tx focus:border-tx focus:outline-none leading-relaxed"
              />
            </Field>
          </div>
        )}

        {/* Step 4: Department Roles */}
        {step === 3 && (
          <div className="flex flex-col gap-3 pt-1">
            <div className="text-[11px] font-bold uppercase tracking-wider text-mu">
              Active Functional Squads &amp; Owners
            </div>
            <p className="text-xs text-mu">
              Selected roles will receive automated milestone tasks and risk surveillance dashboards.
            </p>
            <div className="flex flex-wrap gap-2.5 mt-2">
              {ROLES.slice(1).map((o) => {
                const isChecked = f.roles.includes(o);
                return (
                  <button
                    type="button"
                    key={o}
                    onClick={() => set('roles', toggle<Role>(f.roles, o))}
                    className={`rounded-full px-4 py-2 text-xs font-semibold transition ${
                      isChecked
                        ? 'bg-ink text-white shadow-2xs'
                        : 'border border-bd bg-p2 text-tx hover:border-tx'
                    }`}
                  >
                    {isChecked ? '✓ ' : '+ '}
                    {o}
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* Step 5: Synthesis */}
        {step === 4 && (
          <div className="flex flex-col gap-4 pt-1">
            <div className="rounded-xl border border-bd bg-p2/50 p-4">
              <div className="text-[10px] font-bold uppercase tracking-wider text-mu">
                Specification Review
              </div>
              <div className="mt-2 text-sm font-bold text-tx">
                {f.name} · {f.type} in {f.city}
              </div>
              <div className="mt-1 flex flex-wrap gap-x-4 gap-y-1 text-xs text-mu">
                <span>Date: <b className="text-tx">{f.date}</b></span>
                <span>Target: <b className="text-tx">{f.targetRegistrations}</b> registrations</span>
                <span>Roles: <b className="text-tx">{f.roles.length}</b> assigned</span>
                <span>Objectives: <b className="text-tx">{f.objectives.length}</b> selected</span>
              </div>
            </div>

            <p className="text-xs text-mu leading-relaxed">
              Generating a new plan resets outdated tasks, compiles customized milestone dependencies, and calibrates the real-time risk engine to your target schedule.
            </p>

            <div className="flex flex-wrap items-center gap-3">
              <Btn
                variant="primary"
                disabled={busy || !valid}
                onClick={generate}
                className="rounded-full px-5 py-2 text-xs font-bold"
              >
                {busy ? 'Synthesizing Architecture…' : (
                  <>Generate <span className="font-editorial italic font-normal">Intelligent</span> Event Plan</>
                )}
              </Btn>

              {mode && (
                <Badge tone={mode === 'claude' ? 'ok' : 'warn'}>
                  {mode === 'claude' ? 'CLAUDE INTELLIGENCE' : 'DETERMINISTIC BLUEPRINT'}
                </Badge>
              )}
            </div>

            {done.length > 0 && (
              <div className="mt-3 space-y-1.5 rounded-xl border border-bd bg-p2 p-4 text-xs font-mono" aria-live="polite">
                {done.map((d, i) => (
                  <div
                    key={d}
                    className={`flex items-center gap-2 ${
                      i === STEPS.length - 1 ? 'font-bold text-ok' : 'text-mu'
                    }`}
                  >
                    <span>✓</span>
                    <span>{d}</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Navigation Actions */}
        <div className="mt-6 flex items-center justify-between border-t border-bd pt-4">
          <Btn
            variant="default"
            disabled={step === 0 || busy}
            onClick={() => setStep(step - 1)}
            className="rounded-full px-4 py-1.5 text-xs font-semibold"
          >
            Back
          </Btn>

          {step < 4 && (
            <Btn
              variant="primary"
              onClick={() => setStep(step + 1)}
              className="rounded-full px-5 py-1.5 text-xs font-semibold"
            >
              Continue
            </Btn>
          )}
        </div>
      </Card>
    </div>
  );
}
