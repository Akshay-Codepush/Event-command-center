-- Event Command Centre — Supabase schema
-- 1) Snapshot table: what the prototype's lib/persistence.ts reads/writes today (one jsonb row per event).
create table if not exists event_snapshots (
  id text primary key,
  state jsonb not null,
  updated_at timestamptz not null default now()
);

-- 2) Normalised tables: target schema for production (mirrors /types). Move from snapshots to these table-by-table.
create table if not exists events (id text primary key, name text not null, type text, date date not null, venue text, city text,
  target_registrations int not null, expected_attendance int, health_score int, status text default 'LIVE');
create table if not exists tasks (id text primary key, event_id text references events(id) on delete cascade, title text not null, description text, why text,
  role text not null, owner text, priority text, status text default 'Not Started', due_date date, milestone_id text, risk_id text, effect jsonb, applied boolean default false);
create table if not exists registrations (id uuid primary key default gen_random_uuid(), event_id text references events(id) on delete cascade,
  date date not null, source text, audience_type text, status text default 'registered');
create table if not exists partners (id text primary key, event_id text references events(id) on delete cascade, name text not null, type text,
  status text, last_contact date, next_follow_up date, confirmation_probability int);
create table if not exists risks (id text, event_id text references events(id) on delete cascade, type text, severity text, metric text, current_value text, threshold text,
  detected_at timestamptz default now(), impact text, explanation jsonb, status text, assigned_role text, primary key (event_id, id));
create table if not exists recovery_actions (id text, risk_id text, event_id text references events(id) on delete cascade, title text, description text,
  impact text, effort text, owner_role text, status text default 'Proposed', primary key (event_id, id));
create table if not exists notifications (id uuid primary key default gen_random_uuid(), event_id text references events(id) on delete cascade,
  text text, href text, tone text, unread boolean default true, created_at timestamptz default now());

-- RLS: the demo uses the anon key against event_snapshots only. Lock down before real data.
alter table event_snapshots enable row level security;
create policy "demo read"  on event_snapshots for select using (true);
create policy "demo write" on event_snapshots for insert with check (true);
create policy "demo update" on event_snapshots for update using (true);
create policy "demo delete" on event_snapshots for delete using (true);
-- PRODUCTION: replace the policies above with auth.uid()-scoped ones and add owner_id to every table.