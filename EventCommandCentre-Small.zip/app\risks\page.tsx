'use client';

import { useEvent } from '@/hooks/use-event';
import { Card, Empty } from '@/components/ui';
import { RiskCard } from '@/components/risks';

const RULES = [
  { id: 'R1', title: 'Registration Gap', rule: 'Trajectory falling below projected target pace', tag: 'Growth' },
  { id: 'R2', title: 'Partner Commitment', rule: 'Confirmed sponsor commitments below 70%', tag: 'Sponsorship' },
  { id: 'R3', title: 'Pending Approval Load', rule: 'Unreviewed attendees exceeding 30% capacity', tag: 'Check-in' },
  { id: 'R4', title: 'Conversion Disconnect', rule: 'Show-up rate probability dropped below 65%', tag: 'Experience' },
  { id: 'R5', title: 'Logistics Bottleneck', rule: 'Venue, stage or transport tasks marked overdue', tag: 'Operations' },
  { id: 'R6', title: 'Critical Path Block', rule: 'Any zero-slack milestone task flagged as blocked', tag: 'Delivery' },
  { id: 'R7', title: 'Velocity Deceleration', rule: 'Ticket velocity declined over 3 consecutive intervals', tag: 'Marketing' },
  { id: 'R8', title: 'Department Escalation', rule: 'Three or more unresolved risks clustered in a single role', tag: 'Leadership' },
];

export default function Risks() {
  const { s } = useEvent();
  const lead = ['Event Lead', 'Leadership'].includes(s.role);
  const rs = lead ? s.risks : s.risks.filter((r) => r.assignedRole === s.role);

  return (
    <div className="flex flex-col gap-6">
      {/* Editorial Header */}
      <div className="flex flex-col justify-between gap-4 border-b border-bd pb-6 md:flex-row md:items-end">
        <div>
          <div className="text-[11px] font-bold uppercase tracking-widest text-mu">
            Autonomous Surveillance /
          </div>
          <h1 className="mt-1 text-3xl font-extrabold tracking-tight text-tx sm:text-4xl">
            Active Risk <span className="font-editorial italic font-normal text-tx">Surveillance</span>
          </h1>
          <p className="mt-1.5 max-w-2xl text-xs text-mu leading-relaxed">
            Deterministic risk detection running continuously against real-time signals. Every risk maps directly to corrective actions and owner accountability.
          </p>
        </div>

        <div className="flex items-center gap-2 self-start md:self-end">
          <span className="rounded-full border border-bd bg-p2 px-3 py-1.5 text-xs font-bold text-tx shadow-2xs">
            {rs.length} active {rs.length === 1 ? 'risk' : 'risks'}
          </span>
          <span className="rounded-full border border-ok/30 bg-ok/10 px-3 py-1.5 text-xs font-bold text-ok shadow-2xs">
            ✓ 8 rules active
          </span>
        </div>
      </div>

      {/* Active Risks List */}
      <div className="flex flex-col gap-4">
        {rs.length ? (
          rs.map((r) => <RiskCard key={r.id} r={r} />)
        ) : (
          <Empty>
            <div className="py-6">
              <span className="font-editorial italic text-2xl text-tx">No active risks detected.</span>
              <p className="mt-1 text-xs text-mu">All telemetry indicators are operating within normal parameters.</p>
            </div>
          </Empty>
        )}
      </div>

      {/* Telemetry Rule Coverage Strip */}
      <Card
        title="Rule evaluation coverage"
        right={<span className="text-xs font-medium text-mu">Autonomous logic matrix</span>}
      >
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          {RULES.map((rule) => {
            const isFired = s.risks.some((r) => r.id.toLowerCase().includes(rule.id.toLowerCase()) || r.type.toLowerCase().includes(rule.title.toLowerCase()));
            return (
              <div
                key={rule.id}
                className={`rounded-xl border p-3.5 transition ${
                  isFired
                    ? 'border-crit/40 bg-crit/5'
                    : 'border-bd bg-p2/50 hover:border-tx/20'
                }`}
              >
                <div className="flex items-center justify-between gap-1 text-[11px]">
                  <span className="font-mono font-bold text-tx">{rule.id}</span>
                  <span className={`rounded-full px-2 py-0.5 text-[9px] font-bold uppercase ${
                    isFired ? 'bg-crit text-white' : 'bg-pn border border-bd text-mu'
                  }`}>
                    {isFired ? 'Triggered' : 'Healthy'}
                  </span>
                </div>
                <div className="mt-1.5 text-xs font-bold text-tx">{rule.title}</div>
                <div className="mt-1 text-[11px] text-mu leading-normal">{rule.rule}</div>
              </div>
            );
          })}
        </div>
      </Card>
    </div>
  );
}
