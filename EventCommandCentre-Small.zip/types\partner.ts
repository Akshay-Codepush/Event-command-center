export type PartnerStage = 'Prospect' | 'Contacted' | 'Interested' | 'Negotiating' | 'Confirmed' | 'Dropped';
export const STAGES: PartnerStage[] = ['Prospect', 'Contacted', 'Interested', 'Negotiating', 'Confirmed', 'Dropped'];
export interface Partner {
  id: string; eventId: string; name: string; contact: string; type: string; status: PartnerStage;
  lastContact: number;   // days ago
  nextFollowUp: number;  // days from now (<=0 = due / overdue)
  confirmationProbability: number;
}
