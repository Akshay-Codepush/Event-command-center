import { supabase } from "@/lib/session";

export const SOURCE_OPTIONS = ["Instagram", "LinkedIn", "Partner", "Email", "Website", "Referral"];
export const AUDIENCE_OPTIONS = ["Student", "Professional", "Family", "Faculty"];

export type RegRow = {
id: string;
source: string;
audience_type: string;
status: "registered" | "confirmed" | "attended";
created_at: string;
};

type Split = [string, number][];
export type Summary = { total: number; conversion: number; velocity: number[]; sources: Split; audience: Split };

async function myId(): Promise<string | null> {
if (!supabase) return null;
const { data } = await supabase.auth.getUser();
return data.user?.id ?? null;
}

export async function myRegistration(): Promise<RegRow | null> {
if (!supabase) return null;
const id = await myId();
if (!id) return null;
const { data } = await supabase
    .from("event_registrations")
    .select("id, source, audience_type, status, created_at")
    .eq("user_id", id)
    .maybeSingle();
return (data as RegRow | null) ?? null;
}

export async function registerMe(fullName: string, source: string, audience: string): Promise<{ error?: string }> {
if (!supabase) return { error: "Supabase is not connected." };
const { error } = await supabase
    .from("event_registrations")
    .insert({ full_name: fullName.trim(), source, audience_type: audience });
return { error: error?.message };
}

export async function confirmMe(): Promise<{ error?: string }> {
if (!supabase) return { error: "Supabase is not connected." };
const id = await myId();
if (!id) return { error: "Please sign in again." };
const { error } = await supabase.from("event_registrations").update({ status: "confirmed" }).eq("user_id", id);
return { error: error?.message };
}

// Manager only: the database returns nothing to anyone else
export async function fetchRegistrationRows(): Promise<RegRow[] | null> {
if (!supabase) return null;
const { data, error } = await supabase
    .from("event_registrations")
    .select("id, source, audience_type, status, created_at");
if (error || !data) return null;
return data as RegRow[];
}

export function subscribeRegistrations(cb: () => void): () => void {
const client = supabase;
if (!client) return () => {};
const channel = client
    .channel("registrations-live")
    .on("postgres_changes", { event: "*", schema: "public", table: "event_registrations" }, () => cb())
    .subscribe();
return () => {
    void client.removeChannel(channel);
};
}

// Turns raw rows into the numbers the dashboard engine needs
export function summarize(rows: RegRow[], todayISO: string): Summary {
const total = rows.length;
const confirmed = rows.filter((r) => r.status !== "registered").length;
  const conversion = total ? Math.round((confirmed / total) * 1000) / 10 : 0;

const velocity: number[] = [];
for (let i = 6; i >= 0; i--) {
    const day = new Date(Date.parse(todayISO) - i * 864e5).toISOString().slice(0, 10);
    velocity.push(rows.filter((r) => r.created_at.slice(0, 10) === day).length);
}

const split = (key: "source" | "audience_type"): Split => {
    const counts = new Map<string, number>();
    rows.forEach((r) => counts.set(r[key], (counts.get(r[key]) ?? 0) + 1));
    return Array.from(counts.entries())
    .sort((a, b) => b[1] - a[1])
      .map(([n, c]) => [n, Math.round((c / total) * 1000) / 10] as [string, number]);
};

return { total, conversion, velocity, sources: split("source"), audience: split("audience_type") };
}