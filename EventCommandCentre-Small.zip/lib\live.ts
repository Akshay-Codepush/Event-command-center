import type { AppState } from '@/types/event';

export const NAMES = ['Aarav', 'Diya', 'Kabir', 'Meera', 'Rohan', 'Anaya', 'Vihaan', 'Isha', 'Arjun', 'Saanvi', 'Tara', 'Zoya'];
export const CITIES = ['Jaipur', 'Delhi', 'Mumbai', 'Pune', 'Bengaluru', 'Ahmedabad', 'Udaipur'];
export const SOURCES = ['LinkedIn', 'Instagram', 'Partner', 'Email', 'Website', 'Referral'];

/** One step of the simulated live registration stream. Pure apart from the injected RNG, so it is testable. Mutates a draft. */
export function applyTick(s: AppState, rng: () => number = Math.random): number {
  const pick = <T,>(a: T[]) => a[Math.floor(rng() * a.length)];
  const n = 2 + Math.floor(rng() * 5);
  s.registrations += n;
  for (let i = 0; i < Math.min(n, 2); i++)
    s.feed.unshift({ id: Date.now() + i + Math.floor(rng() * 1e6), name: `${pick(NAMES)} ${pick(['S.', 'K.', 'M.', 'P.'])}`, city: pick(CITIES), source: pick(SOURCES) });
  s.feed = s.feed.slice(0, 7);
  return n;
}
