'use client';

import { useEvent } from '@/hooks/use-event';
import { MILESTONES } from '@/data/demo-data';
import { Badge, Card } from '@/components/ui';

export default function Plan() {
  const { s, openDrawer } = useEvent();

  const totalTasks = s.tasks.length;
  const totalCompleted = s.tasks.filter((t) => t.status === 'Completed').length;
  const overallPct = totalTasks ? Math.round((totalCompleted / totalTasks) * 100) : 0;

  return (
    <div className="flex flex-col gap-6">
      {/* Editorial Header */}
      <div className="flex flex-col justify-between gap-4 border-b border-bd pb-6 md:flex-row md:items-end">
        <div>
          <div className="text-[11px] font-bold uppercase tracking-widest text-mu">
            Master Schedule /
          </div>
          <h1 className="mt-1 text-3xl font-extrabold tracking-tight text-tx sm:text-4xl">
            Operational <span className="font-editorial italic font-normal text-tx">Master</span> Plan
          </h1>
          <p className="mt-1.5 max-w-2xl text-xs text-mu leading-relaxed">
            Phased milestone execution from initial kick-off through T-Day event staging. Dynamic tasks adjust automatically based on scenario signals.
          </p>
        </div>

        <div className="flex items-center gap-3 self-start md:self-end">
          <div className="rounded-full border border-bd bg-p2 px-4 py-1.5 text-xs text-tx font-medium shadow-2xs">
            <span className="font-bold">{totalCompleted}</span> of {totalTasks} tasks complete ({overallPct}%)
          </div>
        </div>
      </div>

      {/* Phased Milestones Accordion / Cards */}
      <div className="flex flex-col gap-4">
        {MILESTONES.map((m) => {
          const ts = s.tasks.filter((t) => t.milestoneId === m.id);
          const done = ts.filter((t) => t.status === 'Completed').length;
          const pct = ts.length ? Math.round((done / ts.length) * 100) : 100;

          const flag =
            m.id === 'T-7' && s.registrations / s.event.targetRegistrations < 0.9 ? (
              <Badge tone="crit">BEHIND TARGET</Badge>
            ) : m.id === 'T-14' && s.partnerConfirmed < 80 ? (
              <Badge tone="warn">{s.partnerConfirmed}% / 80% REQUIRED</Badge>
            ) : null;

          return (
            <details
              key={m.id}
              open={ts.length > 0}
              className="group overflow-hidden rounded-2xl border border-bd bg-pn shadow-sm transition open:border-tx/30"
            >
              <summary className="flex cursor-pointer list-none flex-wrap items-center justify-between gap-3 p-4 bg-p2/40 transition hover:bg-p2 focus:outline-none">
                <div className="flex flex-wrap items-center gap-2.5">
                  <span className="rounded-md border border-bd bg-pn px-2 py-0.5 font-mono text-[11px] font-bold text-tx">
                    {m.id}
                  </span>
                  <span className="font-bold text-tx">{m.label}</span>
                  <span className="text-xs text-mu font-normal">· {m.title}</span>
                  {flag}
                </div>

                <div className="flex items-center gap-3">
                  <span className="text-xs font-mono font-medium text-mu">
                    {done}/{ts.length} completed
                  </span>
                  <div className="h-1.5 w-16 overflow-hidden rounded-full bg-bd">
                    <div
                      className={`h-full transition-all duration-300 ${pct === 100 ? 'bg-ok' : 'bg-accent'}`}
                      style={{ width: `${pct}%` }}
                    />
                  </div>
                  <span className="text-xs text-mu transition group-open:rotate-180">▼</span>
                </div>
              </summary>

              <div className="divide-y divide-bd border-t border-bd p-2">
                {ts.map((t) => {
                  const isDone = t.status === 'Completed';
                  const isBlocked = t.status === 'Blocked';

                  return (
                    <button
                      key={t.id}
                      onClick={() => openDrawer({ kind: 'task', id: t.id })}
                      className="flex w-full items-center justify-between gap-3 p-3 text-left transition hover:bg-p2/60 rounded-xl"
                    >
                      <div className="flex items-center gap-2.5">
                        <span
                          className={`flex h-4 w-4 items-center justify-center rounded-full text-[10px] font-bold ${
                            isDone
                              ? 'bg-ok/15 text-ok border border-ok/30'
                              : isBlocked
                              ? 'bg-crit/15 text-crit border border-crit/30'
                              : 'border border-bd text-mu'
                          }`}
                        >
                          {isDone ? '✓' : isBlocked ? '!' : '○'}
                        </span>
                        <span className={`text-xs font-semibold ${isDone ? 'line-through text-mu' : 'text-tx'}`}>
                          {t.title}
                        </span>
                      </div>

                      <div className="flex items-center gap-2 text-[11px]">
                        <span className="rounded-full border border-bd bg-pn px-2 py-0.5 font-medium text-mu">
                          {t.role}
                        </span>
                        {t.priority === 'Critical' && (
                          <span className="rounded-full border border-crit/30 bg-crit/10 px-2 py-0.5 font-bold text-crit">
                            Critical
                          </span>
                        )}
                      </div>
                    </button>
                  );
                })}

                {!ts.length && (
                  <div className="p-4 text-center text-xs text-mu font-editorial italic">
                    Baseline tasks completed or scheduled for later activation.
                  </div>
                )}
              </div>
            </details>
          );
        })}
      </div>
    </div>
  );
}
