import type { AppState, Notification } from '@/types/event';
import { computeMetrics } from './metrics';
import { evaluateRisks } from './risk-engine';
import { computeHealth } from './health-score';

let nid = 100;
const note = (text: string, href: string, tone: Notification['tone']): Notification => ({ id: `n${nid++}`, text, href, tone, unread: true });

/**
 * THE LOOP, in one function:
 * raw state -> metrics -> risk rules -> health score -> notifications/history.
 * Called after EVERY mutation (task completion, action accepted, simulation, slider).
 */
export function settle(prev: AppState | null, next: AppState, opts: { silent?: boolean } = {}): AppState {
  const metrics = computeMetrics(next);
  const risks = evaluateRisks(next, metrics);
  const health = computeHealth(next, metrics, risks);
  const keys = risks.map((r) => r.id);
  const prevKeys = prev?.risks.map((r) => r.id) ?? [];

  risks.forEach((r) => { next.riskNames[r.id] = r.type; next.detected[r.id] ??= 'just now'; });
  prevKeys.filter((k) => !keys.includes(k)).forEach((k) => delete next.detected[k]);

  if (prev && !opts.silent) {
    const fresh = risks.filter((r) => !prevKeys.includes(r.id));
    fresh.forEach((r) => next.notifications.unshift(note(`New ${r.severity} risk: ${r.type}`, '/risks', r.severity === 'critical' ? 'critical' : 'warning')));
    prevKeys.filter((k) => !keys.includes(k)).forEach((k) => next.notifications.unshift(note(`Risk resolved: ${prev.riskNames[k] ?? k}`, '/risks', 'ok')));
    if (fresh.length) next.notifications.unshift(note('AI generated recovery actions.', '/actions', 'info'));
    const d = health.score - prev.health.score;
    if (Math.abs(d) >= 2) next.notifications.unshift(note(`Health score ${d > 0 ? 'increased' : 'decreased'} by ${Math.abs(d)} points`, '/analytics', d > 0 ? 'ok' : 'warning'));
  }
  const changed = !prev || health.score !== prev.health.score || risks.length !== prev.risks.length;
  if (changed) { next.healthHistory = [...next.healthHistory, health.score].slice(-24); next.riskHistory = [...next.riskHistory, risks.length].slice(-24); }
  next.event.healthScore = health.score;
  return { ...next, metrics, risks, health };
}
