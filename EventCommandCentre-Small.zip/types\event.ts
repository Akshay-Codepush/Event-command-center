import type { Task } from './task';
import type { Risk } from './risk';
import type { Partner } from './partner';

export type Role = 'Event Lead' | 'Marketing' | 'Partnerships' | 'Operations' | 'Programme' | 'Leadership';
export const ROLES: Role[] = ['Event Lead', 'Marketing', 'Partnerships', 'Operations', 'Programme', 'Leadership'];

export interface Event {
  id: string; name: string; type: string; date: string; venue: string; city: string;
  targetRegistrations: number; expectedAttendance: number; healthScore: number; status: 'LIVE' | 'DRAFT';
}
export interface Registration { id: string; eventId: string; date: string; source: string; audienceType: string; status: 'registered' | 'confirmed' | 'attended' }
export interface Milestone { id: string; label: string; title: string }

/** A metric change produced by completing a recovery task (the "outcome" half of the closed loop). */
export interface Effect {
  reg?: number;              // registrations added
  p?: number;                // partner confirmation points
  c?: number;                // attendance conversion points
  v?: number;                // new daily-velocity datapoint
  cat?: Record<string, number>; // operations category readiness deltas
  fix?: string[];            // task ids that get unblocked / completed
}

export interface FeedItem { id: number; name: string; city: string; source: string }
export interface Notification { id: string; text: string; href: string; tone: 'critical' | 'warning' | 'ok' | 'info'; unread: boolean }

export interface Metrics {
  tasksDone: number; tasksTotal: number; gapPct: number; forecast: number; attendance: number;
  opsReadiness: number; avgVelocity: number; daysLeft: number;
}
export type HealthStatus = 'EXCELLENT' | 'HEALTHY' | 'WATCH' | 'AT RISK' | 'CRITICAL';
export interface HealthResult {
  score: number; status: HealthStatus; tone: 'ok' | 'warn' | 'crit';
  parts: { label: string; value: number }[]; penalty: number;
}

export interface AppState {
  event: Event;
  role: Role;
  registrations: number;
  conversion: number;       // % of registrants confirming attendance
  partnerConfirmed: number; // % of partners confirmed
  velocity: number[];       // registrations per day, latest last
  baseline: { done: number; total: number }; // historical tasks aggregated
  categories: Record<string, number>;        // operations readiness by category
  tasks: Task[];
  partners: Partner[];
  actionState: Record<string, 'task' | 'rejected'>;
  actionOwner: Record<string, Role>;
  actionTitle: Record<string, string>;
  acknowledged: Record<string, boolean>;
  detected: Record<string, string>;
  riskNames: Record<string, string>;
  notifications: Notification[];
  healthHistory: number[];
  riskHistory: number[];
  lastOutcome: string;
  live: boolean;        // live registration stream on/off
  feed: FeedItem[];     // most recent simulated registrants
  real?: { sources: [string, number][]; audience: [string, number][] }; // set in Live data mode
  // derived by lib/engine.ts settle()
  metrics: Metrics;
  risks: Risk[];
  health: HealthResult;
}
