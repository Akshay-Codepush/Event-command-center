'use client';

import { useEvent } from '@/hooks/use-event';
import { STAGES } from '@/types/partner';
import { Btn, Card } from '@/components/ui';

export default function Partners() {
  const { s, openDrawer } = useEvent();

  return (
    <div className="flex flex-col gap-6">
      {/* Editorial Header */}
      <div className="flex flex-col justify-between gap-4 border-b border-bd pb-6 md:flex-row md:items-end">
        <div>
          <div className="text-[11px] font-bold uppercase tracking-widest text-mu">
            Sponsorship &amp; Ecosystem /
          </div>
          <h1 className="mt-1 text-3xl font-extrabold tracking-tight text-tx sm:text-4xl">
            Partner <span className="font-editorial italic font-normal text-tx">Pipeline</span> &amp; Outreaches
          </h1>
          <p className="mt-1.5 max-w-2xl text-xs text-mu leading-relaxed">
            Ecosystem and sponsor relationship management. Monitor probability scores, pending conversations, and overdue touches.
          </p>
        </div>

        <div className="flex items-center gap-2 self-start md:self-end">
          <div className="rounded-full border border-bd bg-p2 px-4 py-1.5 text-xs text-tx font-medium shadow-2xs">
            <span className="font-bold text-accent">{s.partnerConfirmed}%</span> confirmed commitment
          </div>
        </div>
      </div>

      {/* Stage Cards Strip */}
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5">
        {STAGES.map((st) => {
          const count = s.partners.filter((p) => p.status === st).length;
          return (
            <div
              key={st}
              className="rounded-2xl border border-bd bg-pn p-4 shadow-sm transition hover:border-tx/30"
            >
              <div className="text-[11px] font-bold uppercase tracking-wider text-mu">
                {st}
              </div>
              <div className="mt-2 font-mono text-3xl font-black text-tx">
                {count}
              </div>
            </div>
          );
        })}
      </div>

      {/* Partner Pipeline Table */}
      <Card
        title="Active partner accounts"
        right={<span className="text-xs text-mu">{s.partners.length} total partners</span>}
      >
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-bd text-[10px] font-bold uppercase tracking-wider text-mu">
                <th className="p-3">Partner Name</th>
                <th className="p-3">Category</th>
                <th className="p-3">Stage</th>
                <th className="p-3">Last Touch</th>
                <th className="p-3">Next Follow-up</th>
                <th className="p-3">Probability</th>
                <th className="p-3 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-bd">
              {s.partners.map((p) => {
                const isOverdue = p.nextFollowUp < 0;
                const isToday = p.nextFollowUp === 0;

                return (
                  <tr key={p.id} className="transition hover:bg-p2/50">
                    <td className="p-3">
                      <b className="font-bold text-tx">{p.name}</b>
                    </td>
                    <td className="p-3 font-medium text-mu">{p.type}</td>
                    <td className="p-3">
                      <span
                        className={`inline-block rounded-full px-2.5 py-0.5 text-[10px] font-bold ${
                          p.status === 'Confirmed'
                            ? 'bg-ok/10 text-ok border border-ok/20'
                            : p.status === 'Dropped'
                            ? 'bg-crit/10 text-crit border border-crit/20'
                            : 'bg-p2 text-tx border border-bd'
                        }`}
                      >
                        {p.status}
                      </span>
                    </td>
                    <td className="p-3 font-mono text-mu">{p.lastContact}d ago</td>
                    <td className="p-3 font-medium">
                      {isOverdue ? (
                        <span className="font-bold text-crit">{-p.nextFollowUp}d overdue</span>
                      ) : isToday ? (
                        <span className="font-bold text-warn">TODAY</span>
                      ) : (
                        <span className="text-tx">in {p.nextFollowUp}d</span>
                      )}
                    </td>
                    <td className="p-3 font-mono font-bold text-tx">
                      {p.confirmationProbability}%
                    </td>
                    <td className="p-3 text-right">
                      {!['Confirmed', 'Dropped'].includes(p.status) && (
                        <Btn
                          variant="primary"
                          onClick={() => openDrawer({ kind: 'followup', id: p.id })}
                          className="rounded-full px-3 py-1 text-xs"
                        >
                          Generate <span className="font-editorial italic font-normal">Follow-up</span>
                        </Btn>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}
