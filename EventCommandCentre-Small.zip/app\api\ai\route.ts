import { NextResponse } from 'next/server';

// Server-side Claude integration. Without ANTHROPIC_API_KEY it reports {mode:'demo'} and the client uses the deterministic engine.
const SCHEMAS: Record<string, string> = {
  'risk-explanation': '{"what": string, "why": string, "impact": string}',
  'follow-up': '{"message": string}',
  plan: '{"summary": string, "tasks": [{"title": string, "description": string, "role": "Marketing|Partnerships|Operations|Programme|Leadership", "priority": "Critical|High|Medium|Low", "milestone": "T-30|T-21|T-14|T-7|T-3|T-1"}]}',
  'management-summary': '{"narrative": string, "topPriority": string, "biggestBlocker": string, "recommendedAction": string}',
  'recovery-ranking': '{"order": [string], "rationale": string}',
};
const INSTR: Record<string, string> = {
  plan: 'Return at most 6 extra tasks that the brief implies and the baseline plan lacks.',
  'recovery-ranking': 'Rank the given action ids by expected impact per effort; return every id exactly once.',
};

export async function GET() { return NextResponse.json({ mode: process.env.ANTHROPIC_API_KEY ? 'claude' : 'demo' }); }

export async function POST(req: Request) {
  const { task, context } = await req.json().catch(() => ({}));
  const key = process.env.ANTHROPIC_API_KEY;
  if (!key || !SCHEMAS[task]) return NextResponse.json({ mode: 'demo' });
  try {
    const r = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: { 'x-api-key': key, 'anthropic-version': '2023-06-01', 'content-type': 'application/json' },
      body: JSON.stringify({
        model: process.env.ANTHROPIC_MODEL ?? 'claude-sonnet-5-5', max_tokens: 1200,
        system: `You are the intelligence layer of an event command centre. Respond with ONLY valid JSON matching: ${SCHEMAS[task]}. No prose, no markdown. Be concise and decision-oriented. Use only numbers present in the context. ${INSTR[task] ?? ''}`,
        messages: [{ role: 'user', content: JSON.stringify({ task, context }) }],
      }),
    });
    if (!r.ok) return NextResponse.json({ mode: 'demo' });
    const j = await r.json();
    const text: string = j.content?.[0]?.text ?? '';
    return NextResponse.json({ mode: 'claude', data: JSON.parse(text.replace(/```json|```/g, '').trim()) });
  } catch {
    return NextResponse.json({ mode: 'demo' });
  }
}
