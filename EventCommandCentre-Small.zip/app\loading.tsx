export default function Loading() { return <div className="p-6 text-mu" aria-busy="true">Loading command centre…</div>; }
