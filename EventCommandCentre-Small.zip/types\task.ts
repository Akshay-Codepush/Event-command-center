import type { Effect, Role } from './event';
export type TaskStatus = 'Not Started' | 'In Progress' | 'Blocked' | 'Completed';
export type Priority = 'Critical' | 'High' | 'Medium' | 'Low';
export interface Task {
  id: string; eventId: string; title: string; description: string; why: string;
  role: Role; owner: string; priority: Priority; status: TaskStatus;
  dueInDays: number; milestoneId: string; riskId: string | null;
  effect?: Effect; applied?: boolean; log: string[];
}
