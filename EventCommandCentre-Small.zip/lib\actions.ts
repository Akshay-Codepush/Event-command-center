import type { RecoveryAction } from '@/types/risk';
import type { Role, Effect } from '@/types/event';

type Row = [string, string, RecoveryAction['impact'], RecoveryAction['effort'], Role, Effect];

/** Recovery library: every risk key maps to ranked, effect-bearing actions (Demo Intelligence Mode).
 *  In production Claude re-ranks/re-writes these; the `effect` model stays deterministic. */
const LIB: Record<string, Row[]> = {
  reg: [
    ['Launch partner referral campaign', 'Activate sponsors & community partners to share a tiered-incentive referral link.', 'HIGH', 'MEDIUM', 'Partnerships', { reg: 57, p: 6, v: 38 }],
    ['Extend early-bird deadline by 5 days', 'Re-open the price window and announce it across all channels.', 'HIGH', 'LOW', 'Marketing', { reg: 38, v: 31 }],
    ['Reminder email to unconfirmed registrants & past attendees', 'Segmented reminder with speaker highlights.', 'MEDIUM', 'LOW', 'Marketing', { reg: 22, c: 2, v: 27 }],
    ['Speaker highlight campaign', 'Short-form video series featuring keynote speakers.', 'MEDIUM', 'LOW', 'Marketing', { reg: 18, v: 26 }],
  ],
  vel: [['Boost paid LinkedIn/Instagram spend 20% for 5 days', 'Shift budget to best-converting audiences.', 'MEDIUM', 'MEDIUM', 'Marketing', { reg: 30, v: 34 }]],
  part: [
    ['Leadership outreach to 3 pending sponsors', 'Executive calls to ABC Technologies, NovaCloud, Orbit AI.', 'HIGH', 'MEDIUM', 'Leadership', { p: 9 }],
    ['Send follow-up pack to Interested partners', 'Benefit deck + confirmation form.', 'MEDIUM', 'LOW', 'Partnerships', { p: 5 }],
  ],
  conv: [
    ['Personalised attendance-confirmation reminders', 'One-click confirm links via email + WhatsApp.', 'HIGH', 'LOW', 'Marketing', { c: 10 }],
    ['Send calendar invite + travel guide', 'Anchors the date and reduces drop-off.', 'MEDIUM', 'LOW', 'Programme', { c: 6 }],
  ],
  ops: [
    ['Book backup shuttle vendor', 'Secure standby capacity for the transport gap.', 'HIGH', 'MEDIUM', 'Operations', { fix: ['TSK-107'], cat: { Transport: 30 } }],
    ['Run daily logistics stand-up', 'Owners report blockers each morning.', 'MEDIUM', 'LOW', 'Operations', { cat: { AV: 8 } }],
  ],
  blk: [
    ['Rent backup AV kit & unblock AV check', 'Removes vendor dependency on the critical AV task.', 'HIGH', 'MEDIUM', 'Operations', { fix: ['TSK-106'], cat: { AV: 35 } }],
    ['Escalate AV vendor to Leadership', 'Executive-level vendor call.', 'MEDIUM', 'LOW', 'Leadership', {}],
  ],
  esc: [['Reallocate capacity to overloaded department', 'Rebalance owners across roles.', 'MEDIUM', 'MEDIUM', 'Leadership', {}]],
};
const ALIAS: Record<string, string> = { pend: 'conv' };

export function actionsFor(riskKey: string): RecoveryAction[] {
  const k = ALIAS[riskKey] ?? riskKey;
  return (LIB[k] ?? []).map((r, i) => ({ id: `${k}${i}`, riskId: riskKey, title: r[0], description: r[1], impact: r[2], effort: r[3], ownerRole: r[4], effect: r[5] }));
}
