import { NextResponse } from "next/server";
import { GoogleGenerativeAI } from "@google/generative-ai";

function getFallbackAnswer(question: string, context?: string): string {
  const q = (question || "").toLowerCase();
  const ctx = (context || "").toLowerCase();

  if (/health|score|how is the event|status/.test(q)) {
    const match = context?.match(/Health\s*(\d+\/\d+|\b\d+\b)/i);
    const score = match ? match[1] : "78/100 (Healthy)";
    return `Current Event Health is ${score}. Metrics, partner readiness, and operations are on track, with active risk mitigations underway.`;
  }

  if (/risk|problem|issue|blocker|wrong|danger/.test(q)) {
    return `Top active risks include: Registration Pace Gap (below early-bird target pace), Partner Confirmation Shortfall (ABC Technologies follow-up pending), and AV Technical Readiness check. Recovery actions have been proposed in the Recovery Actions section.`;
  }

  if (/priority|recommend|what should (we|i) do|next step/.test(q)) {
    return `Recommended Priority: 1. Launch partner referral campaign with Tier-1 sponsors. 2. Finalize AV backup equipment rental. 3. Send automated calendar anchoring and attendance confirmation reminders.`;
  }

  if (/forecast|regist|ticket|attendee|target|how many/.test(q)) {
    return `Registrations are tracking toward the event target (820 capacity). Projected attendance conversion is ~79% with daily velocity around 19–25 registrations/day.`;
  }

  if (/partner|sponsor|abc tech|orbit|novacloud/.test(q)) {
    return `Partner confirmations are at 68% (readiness target is 70%). ABC Technologies is interested with follow-up scheduled today; NovaCloud and Orbit AI are in negotiation.`;
  }

  if (/ops|logistic|av|transport|shuttle|venue|canteen/.test(q)) {
    return `Logistics readiness is currently ~80%. Venue and catering are secured at 90-100%; Transport shuttle vendor confirmation and AV stage equipment check are the active focus areas.`;
  }

  if (/crowd|heat map|density|gate|zone/.test(q)) {
    return `Crowd density is actively monitored across 7 zones: Main Gate, Open Air Theatre, Stall Lawn, Food Court, Canteen, Sports Grounds, and Parking. Live sensors show peak flow near Main Stage and Gate.`;
  }

  if (/date|when|where|location|venue/.test(q)) {
    return `The event is scheduled at Jaipur Exhibition Centre, approximately 12 days away. Campus map and entrance directions are available under the Attendee Map.`;
  }

  if (/who are you|help|what can you do/.test(q)) {
    return `I am your AI Event Operations Assistant. I analyze real-time event intelligence, health scores, partner status, registration velocity, and operational blockers. Ask me anything about current readiness or recommended recovery actions!`;
  }

  // Fallback using context snippet
  if (context && context.length > 50) {
    return `Based on live dashboard telemetry: The event command system is tracking active operations across registrations, risk rules, and department readiness. Let me know if you would like details on health score, active risks, or recovery actions.`;
  }

  return `Event Command Centre is active. Try asking: "Why is health score low?", "What is the top risk?", "What is our registration forecast?", or "Show logistics status".`;
}

export async function POST(req: Request) {
  try {
    const body = await req.json().catch(() => ({}));
    const { messages = [], context = "" } = body;
    const lastUserMessage = [...messages].reverse().find((m: { role: string; content: string }) => m.role === "user")?.content || "";

    const apiKey = process.env.GEMINI_API_KEY;
    if (apiKey && apiKey.startsWith("AIzaSy")) {
      try {
        const genAI = new GoogleGenerativeAI(apiKey);
        const model = genAI.getGenerativeModel({
          model: "gemini-1.5-flash",
          systemInstruction: `You are the AI assistant for Event Command Centre, an intelligent event intelligence and decision support system.
Keep answers concise, direct, helpful, and professional.
Answer questions about the event using the dashboard telemetry provided below. Do not make up fake external facts.

CURRENT DASHBOARD DATA:
${context || "No context provided."}`,
        });

        const contents = messages.map((m: { role: string; content: string }) => ({
          role: m.role === "assistant" ? "model" : "user",
          parts: [{ text: m.content }],
        }));

        const result = await model.generateContent({ contents });
        const reply = result.response.text();
        if (reply) {
          return NextResponse.json({ reply, mode: "gemini" });
        }
      } catch (geminiError) {
        console.warn("Gemini API call failed, falling back to deterministic engine:", (geminiError as Error).message);
      }
    }

    // Graceful fallback to deterministic intelligence engine
    const reply = getFallbackAnswer(lastUserMessage, context);
    return NextResponse.json({ reply, mode: "deterministic" });
  } catch (err) {
    console.error("Chat route error:", err);
    return NextResponse.json({
      reply: "The Event Command Centre assistant is online. You can ask about health score, risks, forecast, tasks, or logistics readiness.",
      mode: "fallback",
    });
  }
}