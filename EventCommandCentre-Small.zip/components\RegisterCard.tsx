"use client";
import { useEffect, useState } from "react";
import { USING_SUPABASE } from "@/lib/session";
import { AUDIENCE_OPTIONS, SOURCE_OPTIONS, confirmMe, myRegistration, registerMe, type RegRow } from "@/lib/registrations";
import { UserCheck, CheckCircle2 } from "lucide-react";

export default function RegisterCard() {
  const [reg, setReg] = useState<RegRow | null>(null);
  const [loaded, setLoaded] = useState(false);
  const [name, setName] = useState("");
  const [source, setSource] = useState(SOURCE_OPTIONS[0]);
  const [audience, setAudience] = useState(AUDIENCE_OPTIONS[0]);
  const [msg, setMsg] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    void myRegistration().then((r) => {
      setReg(r);
      setLoaded(true);
    });
  }, []);

  if (!USING_SUPABASE || !loaded) return null;

  async function submit() {
    if (!name.trim()) {
      setMsg("Please enter your name.");
      return;
    }
    setBusy(true);
    setMsg("");
    const r = await registerMe(name, source, audience);
    if (r.error) setMsg(r.error);
    else setReg(await myRegistration());
    setBusy(false);
  }

  async function confirm() {
    setBusy(true);
    setMsg("");
    const r = await confirmMe();
    if (r.error) setMsg(r.error);
    else setReg(await myRegistration());
    setBusy(false);
  }

  return (
    <div className="rounded-xl border border-bd bg-pn p-4 shadow-sm">
      <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-tx mb-3">
        <UserCheck size={16} className="text-info" />
        <span>Attendee Registration Badge</span>
      </div>

      {reg ? (
        <div className="flex flex-wrap items-center justify-between gap-3 rounded-lg border border-bd bg-p2 p-3 text-xs">
          <div className="flex items-center gap-2.5">
            <CheckCircle2 size={18} className={reg.status === "registered" ? "text-warn" : "text-ok"} />
            <div>
              <div className="font-semibold text-tx">
                Registration Status:{" "}
                <span className={reg.status === "registered" ? "text-warn font-bold" : "text-ok font-bold"}>
                  {reg.status === "registered" ? "Registered (Unconfirmed)" : "Attendance Confirmed"}
                </span>
              </div>
              <div className="text-[11px] text-mu">Credential active in live database.</div>
            </div>
          </div>
          {reg.status === "registered" && (
            <button
              disabled={busy}
              onClick={() => void confirm()}
              className="rounded-lg bg-info px-4 py-2 text-xs font-bold text-white shadow-sm transition hover:opacity-90 disabled:opacity-50"
            >
              {busy ? "Confirming…" : "Confirm I'm Attending"}
            </button>
          )}
        </div>
      ) : (
        <div className="flex flex-wrap gap-2.5 items-center">
          <input
            placeholder="Your full name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="flex-1 min-w-[160px] rounded-lg border border-bd bg-p2 px-3 py-1.5 text-xs text-tx placeholder:text-mu focus:border-info focus:outline-none"
          />
          <select
            value={source}
            onChange={(e) => setSource(e.target.value)}
            aria-label="How did you hear about us"
            className="rounded-lg border border-bd bg-p2 px-3 py-1.5 text-xs text-tx font-medium focus:border-info focus:outline-none"
          >
            {SOURCE_OPTIONS.map((o) => (
              <option key={o}>{o}</option>
            ))}
          </select>
          <select
            value={audience}
            onChange={(e) => setAudience(e.target.value)}
            aria-label="Who are you"
            className="rounded-lg border border-bd bg-p2 px-3 py-1.5 text-xs text-tx font-medium focus:border-info focus:outline-none"
          >
            {AUDIENCE_OPTIONS.map((o) => (
              <option key={o}>{o}</option>
            ))}
          </select>
          <button
            disabled={busy}
            onClick={() => void submit()}
            className="rounded-lg bg-info px-4 py-1.5 text-xs font-bold text-white shadow-sm transition hover:opacity-90 disabled:opacity-50"
          >
            {busy ? "Registering…" : "Register Me"}
          </button>
        </div>
      )}

      {msg && <p className="mt-2 text-xs font-medium text-crit">{msg}</p>}
    </div>
  );
}