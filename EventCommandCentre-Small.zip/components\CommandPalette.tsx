'use client';
import { useMemo, useState } from 'react';
import { useRouter } from 'next/navigation';
import { useEvent } from '@/hooks/use-event';
import { ROUTES } from '@/lib/routes';
import { toggleTheme } from '@/lib/theme';

interface Cmd { label: string; run: () => void }

/** ⌘K / Ctrl+K — jump anywhere, run scenarios, open risks. */
export function CommandPalette() {
  const e = useEvent(); const router = useRouter();
  const [q, setQ] = useState(''); const [idx, setIdx] = useState(0);
  const cmds = useMemo<Cmd[]>(() => [
    ...ROUTES.map((r) => ({ label: `Go to ${r.label}`, run: () => router.push(r.href) })),
    { label: 'Run: Registration drop', run: () => e.runScenario('registration-drop') }, { label: 'Run: Partner drop-off', run: () => e.runScenario('partner-dropoff') },
    { label: 'Run: Logistics crisis', run: () => e.runScenario('logistics-crisis') }, { label: 'Run: Last-minute recovery', run: () => e.runScenario('recovery') },
    { label: 'Toggle live registrations', run: e.toggleLive }, { label: 'Toggle theme', run: toggleTheme }, { label: 'Reset demo', run: e.reset },
    ...e.s.risks.map((r) => ({ label: `Open risk: ${r.type}`, run: () => e.openDrawer({ kind: 'risk', id: r.id }) })),
  ], [e, router]); // eslint-disable-line react-hooks/exhaustive-deps
  const list = cmds.filter((c) => c.label.toLowerCase().includes(q.toLowerCase())).slice(0, 9);
  if (!e.palette) return null;
  const run = (c?: Cmd) => { e.setPalette(false); setQ(''); setIdx(0); c?.run(); };
  return (
    <div className="fixed inset-0 z-40 grid place-items-start justify-center bg-black/60 pt-[12vh]" onClick={(ev) => { if (ev.target === ev.currentTarget) run(); }}>
      <div role="dialog" aria-label="Command palette" className="w-[min(560px,92vw)] rounded-xl border border-info bg-pn p-2.5 shadow-2xl">
        <input autoFocus aria-label="Type a command" placeholder="Type a command… (Enter runs the highlighted one)" className="w-full p-2.5 text-[15px]" value={q}
          onChange={(ev) => { setQ(ev.target.value); setIdx(0); }}
          onKeyDown={(ev) => { if (ev.key === 'Enter') run(list[idx]); if (ev.key === 'ArrowDown') setIdx(Math.min(list.length - 1, idx + 1)); if (ev.key === 'ArrowUp') setIdx(Math.max(0, idx - 1)); }} />
        <div className="mt-1.5">{list.map((c, i) => <button key={c.label} onClick={() => run(c)} className={`block w-full rounded-md px-2.5 py-2 text-left ${i === idx ? 'bg-p2 text-info' : ''}`}>{c.label}</button>)}
          {!list.length && <div className="p-2 text-mu">No matching command</div>}</div>
      </div>
    </div>
  );
}
