'use client';
import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import { usePathname } from 'next/navigation';
import type { AppState, Role } from '@/types/event';
import type { TaskStatus, Priority } from '@/types/task';
import { createInitialState, OWNERS } from '@/data/demo-data';
import { settle } from '@/lib/engine';
import { actionsFor } from '@/lib/actions';
import { daysUntil, setToday, DEMO_TODAY } from '@/lib/dates';
import { applyTick } from '@/lib/live';
import { toTask, type GeneratedTask, type SetupForm } from '@/lib/plan';
import { clearState, loadState, saveState } from '@/lib/persistence';
import { applyScenario, finishTask, taskFromAction, type ScenarioId } from '@/lib/simulation';
import { USING_SUPABASE } from '@/lib/session';
import { fetchRegistrationRows, subscribeRegistrations, summarize } from '@/lib/registrations';

export type DataMode = 'demo' | 'live';
export interface Drawer { kind: 'risk' | 'task' | 'followup'; id: string }
interface Ctx {
  s: AppState; drawer: Drawer | null; toast: string | null; palette: boolean; party: number;
  dataMode: DataMode; setDataMode: (m: DataMode) => void;
  openDrawer: (d: Drawer) => void; closeDrawer: () => void; flash: (m: string) => void; setPalette: (o: boolean) => void;
  setRole: (r: Role) => void; markRead: () => void; toggleLive: () => void;
  acceptAction: (actionId: string, riskKey: string) => void; rejectAction: (id: string) => void;
  editAction: (id: string, title: string) => void; assignAction: (id: string, role: Role) => void;
  completeTask: (id: string) => void; setTaskStatus: (id: string, st: TaskStatus) => void;
  reassignTask: (id: string, role: Role) => void; setPriority: (id: string, p: Priority) => void;
  runScenario: (id: ScenarioId) => void; randomScenario: () => void;
  setInput: (k: 'reg' | 'partners' | 'conv' | 'transport' | 'tasks' | 'velocity', v: number) => void;
  logFollowUp: (partnerId: string) => void; applySetup: (form: SetupForm, extra: GeneratedTask[]) => number; reset: () => void;
}
const C = createContext<Ctx | null>(null);
export const useEvent = () => { const c = useContext(C); if (!c) throw new Error('EventProvider missing'); return c; };
const fresh = () => settle(null, createInitialState(), { silent: true });
const LIVE_PAGES = ['/', '/registrations'];
const realToday = () => new Date().toISOString().slice(0, 10);

export function EventProvider({ children }: { children: ReactNode }) {
  const [s, setS] = useState<AppState>(fresh);
  const [drawer, setDrawer] = useState<Drawer | null>(null);
  const [toast, setToast] = useState<string | null>(null);
  const [palette, setPalette] = useState(false);
  const [party, setParty] = useState(0);
  const [dataMode, setDataModeState] = useState<DataMode>('demo');
  const [ready, setReady] = useState(false);
  const [liveTick, setLiveTick] = useState(0);
  const path = usePathname();
  const hydrated = useRef(false);
  const guard = useRef({ drawer: null as Drawer | null, palette: false, path: '/' });
  guard.current = { drawer, palette, path };
  const flash = useCallback((m: string) => { setToast(m); setTimeout(() => setToast(null), 4200); }, []);

  /** Celebrate big wins: every risk cleared, or health crossing 90. */
  const celebrate = useCallback((prev: AppState, next: AppState) => {
    if ((prev.risks.length > 0 && next.risks.length === 0) || (prev.health.score < 90 && next.health.score >= 90)) setParty((p) => p + 1);
  }, []);

  // Persistence: Supabase if configured, else localStorage. Loaded after mount to avoid hydration mismatch.
  useEffect(() => {
    loadState(createInitialState().event.id).then((x) => {
      if (x) setS({ ...x, live: false, feed: x.feed ?? [] });
      hydrated.current = true; setReady(true);
    });
    try { if (localStorage.getItem('ecc-data-mode') === 'live' && USING_SUPABASE) setDataModeState('live'); } catch { /* ignore */ }
    const onKey = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') { e.preventDefault(); setPalette((o) => !o); }
      else if (e.key === 'Escape') setPalette(false);
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);
  useEffect(() => {
    if (!hydrated.current) return;
    const t = setTimeout(() => void saveState(s.event.id, s), 400);
    return () => clearTimeout(t);
  }, [s]);

  // LIVE DATA MODE: registrations, pace, confirmation rate and splits come from the database.
  useEffect(() => {
    if (!ready || dataMode !== 'live' || !USING_SUPABASE) return;
    const iso = realToday();
    setToday(iso);
    let active = true;
    let first = true;
    const refresh = async () => {
      const rows = await fetchRegistrationRows();
      if (!active || !rows) return;
      const sum = summarize(rows, iso);
      const silent = first; first = false;
      setS((prev) => {
        const d = structuredClone(prev);
        d.registrations = sum.total; d.conversion = sum.conversion; d.velocity = sum.velocity;
        d.real = { sources: sum.sources, audience: sum.audience }; d.live = false;
        const n = settle(prev, d, { silent });
        celebrate(prev, n);
        return n;
      });
    };
    void refresh();
    const off = subscribeRegistrations(() => void refresh());
    return () => { active = false; off(); };
  }, [ready, dataMode, liveTick, celebrate]);

  // Live registration stream (simulated; pauses while a drawer/palette is open or on pages without live widgets).
  useEffect(() => {
    if (!s.live) return;
    const id = setInterval(() => {
      const g = guard.current; if (g.drawer || g.palette || !LIVE_PAGES.includes(g.path)) return;
      setS((prev) => { const d = structuredClone(prev); applyTick(d); const n = settle(prev, d); celebrate(prev, n); return n; });
    }, 1500);
    return () => clearInterval(id);
  }, [s.live, celebrate]);

  /** Clone -> mutate -> settle (re-run the whole intelligence loop) -> commit. */
  const mutate = useCallback((fn: (d: AppState) => void, msg?: string) => {
    const d = structuredClone(s); fn(d); const n = settle(s, d); celebrate(s, n); setS(n); if (msg) flash(msg);
  }, [s, flash, celebrate]);

  const api = useMemo<Ctx>(() => ({
    s, drawer, toast, palette, party, flash, setPalette, dataMode,
    setDataMode: (m) => {
      if (m === 'live' && !USING_SUPABASE) { flash('Live data needs the Supabase keys'); return; }
      try { localStorage.setItem('ecc-data-mode', m); } catch { /* ignore */ }
      if (m === 'demo') { setToday(DEMO_TODAY); setS(fresh()); flash('Demo data restored'); }
      else flash('Live data on: registrations now come from the database');
      setDataModeState(m);
    },
    openDrawer: (d) => { setDrawer(d); if (d.kind === 'risk') mutate((x) => { x.acknowledged[d.id] = true; }); },
    closeDrawer: () => setDrawer(null),
    setRole: (r) => setS((p) => ({ ...p, role: r })),
    markRead: () => setS((p) => ({ ...p, notifications: p.notifications.map((n) => ({ ...n, unread: false })) })),
    toggleLive: () => { setS((p) => ({ ...p, live: !p.live })); flash(s.live ? 'Live mode paused' : 'Live mode on — registrations streaming in'); },
    acceptAction: (aid, key) => {
      const a = actionsFor(key).find((x) => x.id === aid); if (!a || s.actionState[aid]) return;
      mutate((d) => { const t = taskFromAction(d, a); d.acknowledged[key] = true;
        d.notifications.unshift({ id: `t${t.id}`, text: `Task assigned to ${t.role}: ${t.title}`, href: '/tasks', tone: 'info', unread: true }); },
        `Task created and assigned to ${s.actionOwner[aid] ?? a.ownerRole}`);
    },
    rejectAction: (id) => mutate((d) => { d.actionState[id] = 'rejected'; }),
    editAction: (id, title) => mutate((d) => { d.actionTitle[id] = title; }),
    assignAction: (id, role) => mutate((d) => { d.actionOwner[id] = role; }),
    completeTask: (id) => {
      const d = structuredClone(s); const t = d.tasks.find((x) => x.id === id); if (!t) return;
      finishTask(t, d); const n = settle(s, d); celebrate(s, n);
      n.lastOutcome = `"${t.title}" → Health ${s.health.score}→${n.health.score} · Gap ${s.metrics.gapPct.toFixed(1)}%→${n.metrics.gapPct.toFixed(1)}% · Forecast ${s.metrics.forecast}→${n.metrics.forecast}`;
      setS(n); flash('✔ ' + n.lastOutcome);
    },
    setTaskStatus: (id, st) => mutate((d) => { const t = d.tasks.find((x) => x.id === id)!; t.status = st; t.log.push(`Status → ${st}`); }, `Task ${st.toLowerCase()}`),
    reassignTask: (id, r) => mutate((d) => { const t = d.tasks.find((x) => x.id === id)!; t.role = r; t.owner = OWNERS[r]; t.log.push(`Reassigned to ${r}`); }, `Reassigned to ${r}`),
    setPriority: (id, p) => mutate((d) => { d.tasks.find((x) => x.id === id)!.priority = p; }),
    runScenario: (id) => {
      if (id === 'normal') { setS(fresh()); flash('Baseline restored'); return; }
      mutate((d) => applyScenario(d, id), id === 'recovery' ? 'Recovery applied: tasks completed, metrics improved' : 'Scenario applied — risk engine re-evaluated');
    },
    randomScenario: () => { const ids: ScenarioId[] = ['registration-drop', 'partner-dropoff', 'logistics-crisis']; mutate((d) => applyScenario(d, ids[Math.floor(Math.random() * ids.length)]), 'New scenario generated'); },
    setInput: (k, v) => mutate((d) => {
      if (k === 'reg') d.registrations = v; if (k === 'partners') d.partnerConfirmed = v; if (k === 'conv') d.conversion = v;
      if (k === 'transport') d.categories.Transport = v; if (k === 'tasks') d.baseline.done = v; if (k === 'velocity') d.velocity.push(v);
    }, 'Simulation input applied'),
    logFollowUp: (pid) => mutate((d) => { const p = d.partners.find((x) => x.id === pid)!; p.lastContact = 0; p.nextFollowUp = 3; p.confirmationProbability = Math.min(95, p.confirmationProbability + 5); }, 'Follow-up logged'),
    /** Wizard output -> real state: event fields, target curve, role-filtered task plan. Returns tasks added. */
    applySetup: (form, extra) => {
      let added = 0;
      mutate((d) => {
        d.event = { ...d.event, name: form.name, type: form.type, date: form.date, venue: form.venue, city: form.city,
          targetRegistrations: form.targetRegistrations, expectedAttendance: form.expectedAttendance };
        d.tasks = d.tasks.filter((t) => form.roles.includes(t.role));
        const left = daysUntil(form.date), seen = new Set(d.tasks.map((t) => t.title.toLowerCase()));
        extra.forEach((g) => { if (!form.roles.includes(g.role) || seen.has(g.title.toLowerCase())) return; seen.add(g.title.toLowerCase()); d.tasks.push(toTask(d.tasks, g, d.event.id, left)); added++; });
        d.notifications.unshift({ id: `plan${Date.now()}`, text: `Event plan generated: ${added} new tasks, target ${form.targetRegistrations}`, href: '/plan', tone: 'ok', unread: true });
      }, 'Intelligent plan generated — risk engine re-initialised');
      return added;
    },
    reset: () => {
      void clearState(s.event.id);
      setToday(dataMode === 'live' ? realToday() : DEMO_TODAY);
      setS(fresh()); setDrawer(null);
      if (dataMode === 'live') setLiveTick((t) => t + 1);
      flash('Demo reset');
    },
  }), [s, drawer, toast, palette, party, flash, mutate, celebrate, dataMode]);

  return <C.Provider value={api}>{children}</C.Provider>;
}