'use client';
import { ComposedChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, ReferenceLine, CartesianGrid, BarChart, Bar, LineChart } from 'recharts';
import type { SeriesPoint } from '@/lib/metrics';

const axis = { stroke: 'var(--mu)', fontSize: 10 };
const tip = { contentStyle: { background: 'var(--pn)', border: '1px solid var(--bd)', borderRadius: 6, fontSize: 12 } };

export function RegChart({ data, today, height = 210 }: { data: SeriesPoint[]; today: number; height?: number }) {
  return (
    <div role="img" aria-label="Actual versus target registrations">
      <ResponsiveContainer width="100%" height={height}>
        <ComposedChart data={data} margin={{ left: -10, right: 8, top: 8 }}>
          <CartesianGrid stroke="var(--bd)" vertical={false} />
          <XAxis dataKey="day" {...axis} tickFormatter={(d) => `T-${60 - d}`} interval={9} />
          <YAxis {...axis} />
          <Tooltip {...tip} labelFormatter={(d) => `Day ${d} (T-${60 - Number(d)})`} />
          <ReferenceLine x={today} stroke="var(--mu)" strokeDasharray="3 3" label={{ value: 'today', fill: 'var(--mu)', fontSize: 10 }} />
          <Line dataKey="target" name="Target curve" stroke="var(--mu)" dot={false} strokeWidth={2} />
          <Line dataKey="actual" name="Actual" stroke="var(--b)" dot={false} strokeWidth={2.5} />
          <Line dataKey="forecast" name="Forecast" stroke="var(--a)" dot={false} strokeDasharray="5 4" strokeWidth={2} />
        </ComposedChart>
      </ResponsiveContainer>
    </div>
  );
}
export function Trend({ values, color = 'var(--g)', height = 120 }: { values: number[]; color?: string; height?: number }) {
  const data = values.map((v, i) => ({ i, v }));
  return <ResponsiveContainer width="100%" height={height}><LineChart data={data}><XAxis dataKey="i" hide /><YAxis {...axis} width={28} domain={['auto', 'auto']} /><Tooltip {...tip} /><Line dataKey="v" stroke={color} strokeWidth={2} dot={{ r: 2 }} /></LineChart></ResponsiveContainer>;
}
export function Bars({ values, color = 'var(--b)', height = 120 }: { values: number[]; color?: string; height?: number }) {
  const data = values.map((v, i) => ({ i: `D${i + 1}`, v }));
  return <ResponsiveContainer width="100%" height={height}><BarChart data={data}><XAxis dataKey="i" {...axis} /><YAxis {...axis} width={28} /><Tooltip {...tip} /><Bar dataKey="v" fill={color} radius={[3, 3, 0, 0]} /></BarChart></ResponsiveContainer>;
}

export function Radar({ axes }: { axes: { label: string; value: number }[] }) {
  const cx = 110, cy = 100, R = 70, n = axes.length;
  const pt = (i: number, k: number): [number, number] => { const a = -Math.PI / 2 + (i * 2 * Math.PI) / n; return [cx + Math.cos(a) * R * k, cy + Math.sin(a) * R * k]; };
  const ring = (k: number) => axes.map((_, i) => pt(i, k).join(',')).join(' ');
  const shape = axes.map((a, i) => pt(i, Math.max(0.04, a.value)).join(',')).join(' ');
  return (
    <svg viewBox="0 0 220 200" width="100%" role="img" aria-label="Readiness radar">
      {[0.25, 0.5, 0.75, 1].map((k) => <polygon key={k} points={ring(k)} fill="none" stroke="var(--bd)" />)}
      {axes.map((a, i) => { const [x, y] = pt(i, 1.2); return <text key={a.label} x={x} y={y} fontSize="9" fill="var(--mu)" textAnchor="middle">{a.label}</text>; })}
      <polygon points={shape} fill="var(--b)" fillOpacity=".25" stroke="var(--b)" strokeWidth="2" />
      {axes.map((a, i) => { const [x, y] = pt(i, Math.max(0.04, a.value)); return <circle key={a.label} cx={x} cy={y} r="3" fill="var(--b)"><title>{`${a.label} ${Math.round(a.value * 100)}%`}</title></circle>; })}
    </svg>
  );
}
