'use client';

import { useEvent } from '@/hooks/use-event';
import { SCENARIOS } from '@/lib/simulation';
import { Btn, Card, SevBadge, toneText } from '@/components/ui';

export default function Simulation() {
  const { s, runScenario, randomScenario, setInput, openDrawer } = useEvent();

  const Slider = ({
    label,
    k,
    min,
    max,
    v,
    unit = '',
  }: {
    label: string;
    k: Parameters<typeof setInput>[0];
    min: number;
    max: number;
    v: number;
    unit?: string;
  }) => (
    <div className="flex flex-col gap-2 rounded-xl border border-bd bg-p2/50 p-3.5 transition hover:border-tx/30">
      <div className="flex items-center justify-between text-xs">
        <span className="font-medium text-tx">{label}</span>
        <span className="font-mono font-bold text-tx">
          {v}{unit}
        </span>
      </div>
      <input
        type="range"
        min={min}
        max={max}
        defaultValue={v}
        key={v}
        onMouseUp={(e) => setInput(k, +e.currentTarget.value)}
        onTouchEnd={(e) => setInput(k, +e.currentTarget.value)}
        onKeyUp={(e) => setInput(k, +e.currentTarget.value)}
        aria-label={label}
        className="w-full accent-accent cursor-pointer"
      />
      <div className="flex justify-between text-[10px] text-mu font-mono">
        <span>{min}{unit}</span>
        <span>{max}{unit}</span>
      </div>
    </div>
  );

  return (
    <div className="flex flex-col gap-6">
      {/* Editorial Header */}
      <div className="flex flex-col justify-between gap-4 border-b border-bd pb-6 md:flex-row md:items-end">
        <div>
          <div className="text-[11px] font-bold uppercase tracking-widest text-mu">
            Predictive Stress-Testing /
          </div>
          <h1 className="mt-1 text-3xl font-extrabold tracking-tight text-tx sm:text-4xl">
            Simulation <span className="font-editorial italic font-normal text-tx">Lab</span>
          </h1>
          <p className="mt-1.5 max-w-2xl text-xs text-mu leading-relaxed">
            Test the event's structural resilience under simulated shocks. Alter variables below to immediately recalculate health scores, active risks, and recovery paths.
          </p>
        </div>

        <Btn
          variant="default"
          onClick={randomScenario}
          className="rounded-full px-4 py-1.5 text-xs font-semibold self-start md:self-end"
        >
          Generate <span className="font-editorial italic font-normal">Random</span> Shock
        </Btn>
      </div>

      {/* Preset Scenarios Strip */}
      <Card
        title="Simulated scenarios"
        right={<span className="text-xs text-mu">Instant one-click stress tests</span>}
      >
        <div className="flex flex-wrap gap-2.5">
          {SCENARIOS.map((x) => {
            const isRecovery = x.id === 'recovery';
            const isNormal = x.id === 'normal';
            return (
              <button
                key={x.id}
                onClick={() => runScenario(x.id)}
                className={`rounded-full px-4 py-2 text-xs font-semibold transition ${
                  isRecovery
                    ? 'bg-ok text-white hover:opacity-90 shadow-2xs'
                    : isNormal
                    ? 'bg-ink text-white hover:bg-ink/80 shadow-2xs'
                    : 'border border-bd bg-pn text-tx hover:border-tx shadow-2xs'
                }`}
              >
                {x.label}
              </button>
            );
          })}
        </div>
      </Card>

      {/* Live Impact Display */}
      <div className="grid gap-5 md:grid-cols-2">
        <div className="flex flex-col justify-between rounded-2xl border border-bd bg-pn p-5 shadow-sm">
          <div>
            <div className="text-[10px] font-bold uppercase tracking-wider text-mu">
              Live Projected Health Score
            </div>
            <div className="mt-2 flex items-baseline gap-3">
              <span className={`font-mono text-5xl font-black ${toneText[s.health.tone]}`}>
                {s.health.score}
              </span>
              <span className="text-sm font-bold uppercase tracking-wider text-tx">
                / 100 · {s.health.status}
              </span>
            </div>
          </div>
          <p className="mt-4 text-xs text-mu border-t border-bd pt-3">
            Health score is dynamically derived from attendance pace, milestone velocity, and logistics readiness.
          </p>
        </div>

        <div className="flex flex-col justify-between rounded-2xl border border-bd bg-pn p-5 shadow-sm">
          <div>
            <div className="flex items-center justify-between text-[10px] font-bold uppercase tracking-wider text-mu">
              <span>Active Risks ({s.risks.length})</span>
              <span>Click to inspect</span>
            </div>
            <div className="mt-3 flex flex-col gap-1.5 max-h-36 overflow-y-auto">
              {s.risks.map((r) => (
                <button
                  key={r.id}
                  onClick={() => openDrawer({ kind: 'risk', id: r.id })}
                  className="flex items-center gap-2 rounded-lg border border-bd bg-p2 px-3 py-2 text-left text-xs font-medium text-tx transition hover:border-tx"
                >
                  <SevBadge severity={r.severity} />
                  <span className="truncate">{r.type}</span>
                  <span className="ml-auto text-[10px] text-mu font-mono">→</span>
                </button>
              ))}
              {!s.risks.length && (
                <div className="py-4 text-center">
                  <span className="font-editorial italic text-base text-ok">✓ Zero risks detected.</span>
                </div>
              )}
            </div>
          </div>
          <div className="mt-2 text-[11px] text-mu">
            Risks update autonomously based on slider parameter thresholds.
          </div>
        </div>
      </div>

      {/* Real-time Fine-Tuning Sliders */}
      <Card
        title="Telemetry controls"
        right={<span className="text-xs text-mu">Drag sliders to modify inputs</span>}
      >
        <div className="grid gap-3.5 sm:grid-cols-2 lg:grid-cols-3">
          <Slider
            label="Registrations"
            k="reg"
            min={300}
            max={900}
            v={s.registrations}
          />
          <Slider
            label="Partner Confirmations"
            k="partners"
            min={20}
            max={100}
            v={s.partnerConfirmed}
            unit="%"
          />
          <Slider
            label="Attendance Conversion"
            k="conv"
            min={40}
            max={100}
            v={Math.round(s.conversion)}
            unit="%"
          />
          <Slider
            label="Logistics & Transport"
            k="transport"
            min={10}
            max={100}
            v={s.categories.Transport}
            unit="%"
          />
          <Slider
            label="Tasks Completed Baseline"
            k="tasks"
            min={10}
            max={44}
            v={s.baseline.done}
          />
          <Slider
            label="Marketing Velocity"
            k="velocity"
            min={2}
            max={60}
            v={s.velocity.at(-1)!}
            unit=" reg/d"
          />
        </div>
      </Card>
    </div>
  );
}
