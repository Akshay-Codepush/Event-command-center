import { createClient } from "@supabase/supabase-js";
import {
USERS,
login as demoLogin,
getUser as demoGetUser,
logout as demoLogout,
type User,
type Role,
} from "@/lib/auth";

const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
const key = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;

// True when both Supabase keys exist in .env.local
export const USING_SUPABASE = Boolean(url && key);
export const DEMO_USERS = USERS;

export const supabase = USING_SUPABASE ? createClient(url!, key!) : null;

// Who is logged in right now, and what is their role?
export async function getUser(): Promise<User | null> {
if (!supabase) return demoGetUser();

const { data } = await supabase.auth.getSession();
const session = data.session;
if (!session) return null;

  // The role comes from the profiles table in the database
const { data: profile } = await supabase
    .from("profiles")
    .select("role")
    .eq("id", session.user.id)
    .single();

  // If anything goes wrong, fall back to the safer role: viewer
const role: Role = profile?.role === "manager" ? "manager" : "viewer";
const email = session.user.email ?? "";
return { email, name: email, role };
}

export async function login(
email: string,
password: string
): Promise<{ user: User | null; error?: string }> {
if (!supabase) {
    const u = demoLogin(email, password);
    return u ? { user: u } : { user: null, error: "Wrong email or password." };
}
const { error } = await supabase.auth.signInWithPassword({
    email: email.trim(),
    password,
});
if (error) return { user: null, error: error.message };
return { user: await getUser() };
}

// New accounts are always viewers (the database sets that)
export async function signUp(email: string, password: string): Promise<{ error?: string }> {
if (!supabase) return { error: "Sign up needs the Supabase keys." };
const { error } = await supabase.auth.signUp({ email: email.trim(), password });
return { error: error?.message };
}

export async function logout() {
if (!supabase) return demoLogout();
await supabase.auth.signOut();
}