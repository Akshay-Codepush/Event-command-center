/* Run: npm test  — verifies the closed loop against the real engine (no browser needed). */
import { createInitialState } from '@/data/demo-data';
import { settle } from '@/lib/engine';
import { actionsFor } from '@/lib/actions';
import { taskFromAction, finishTask, applyScenario } from '@/lib/simulation';
import { daysUntil } from '@/lib/dates';
import { buildBrief } from '@/lib/brief';
import { applyTick } from '@/lib/live';
import { answer } from '@/lib/qa';
import { mood } from '@/lib/health-score';
import { DEFAULT_FORM, generatePlan, sanitizeAiTasks } from '@/lib/plan';
import type { AppState } from '@/types/event';

let failed = 0;
const ok = (c: boolean, m: string) => { console.log(`${c ? 'PASS' : 'FAIL'}  ${m}`); if (!c) failed++; };
const ids = (s: AppState) => s.risks.map((r) => r.id);

const s0 = settle(null, createInitialState(), { silent: true });
ok(s0.health.score === 78, `initial health is 78 (got ${s0.health.score})`);
ok(['reg', 'part', 'vel'].every((k) => ids(s0).includes(k)) && s0.risks.length === 3, 'initial risks: registration, partner, velocity');
ok(s0.risks[0].id === 'reg' && s0.risks[0].severity === 'critical', 'registration gap -16.6% is CRITICAL');
ok(daysUntil('2026-10-21') === 12 && s0.metrics.daysLeft === 12, 'event is 12 days away');

// Closed loop: accept -> task -> complete -> metrics -> re-evaluation
const d1 = structuredClone(s0); const t = taskFromAction(d1, actionsFor('reg')[0]);
ok(t.role === 'Partnerships' && d1.tasks.includes(t), 'accepting referral action creates a Partnerships task');
const s1 = settle(s0, d1);
ok(s1.risks.length === s0.risks.length, 'creating a task alone does not change risks');
const d2 = structuredClone(s1); finishTask(d2.tasks.find((x) => x.id === t.id)!, d2); const s2 = settle(s1, d2);
ok(s2.registrations > s0.registrations, `registrations increased ${s0.registrations} → ${s2.registrations}`);
ok(s2.risks.find((r) => r.id === 'reg')?.severity === 'warning', 'registration risk CRITICAL → WARNING');
ok(!ids(s2).includes('part') && !ids(s2).includes('vel'), 'partner + velocity risks resolved');
ok(s2.health.score > s0.health.score, `health improved ${s0.health.score} → ${s2.health.score}`);
ok(s2.notifications.some((n) => n.text.startsWith('Risk resolved')), 'notification emitted for resolved risk');

// Simulation
const d3 = structuredClone(s2); applyScenario(d3, 'logistics-crisis'); const s3 = settle(s2, d3);
ok(ids(s3).includes('blk') && s3.risks.find((r) => r.id === 'blk')?.severity === 'critical', 'logistics crisis → critical blocked AV task');
ok(ids(s3).includes('ops'), 'logistics crisis → overdue logistics risk');
ok(s3.health.score < s2.health.score, 'health drops in crisis');
const d4 = structuredClone(s3); applyScenario(d4, 'recovery'); const s4 = settle(s3, d4);
ok(s4.risks.length === 0 && s4.health.score > s3.health.score, `last-minute recovery clears all risks (health ${s3.health.score} → ${s4.health.score})`);

// Rules 4/5/8 + partner drop
const d5 = structuredClone(s0); applyScenario(d5, 'partner-dropoff'); d5.conversion = 60; const s5 = settle(s0, d5);
ok(ids(s5).includes('pend') && ids(s5).includes('conv'), 'rules 3+4: pending confirmations and low conversion fire');

// Wizard / plan generation
const g = generatePlan({ ...DEFAULT_FORM, roles: ['Marketing', 'Operations'] });
ok(g.length > 0 && g.every((x) => ['Marketing', 'Operations'].includes(x.role)), 'plan generator only emits tasks for selected roles');
ok(sanitizeAiTasks([{ title: 'x', role: 'Hacker', priority: 'High', milestone: 'T-7' }, { title: 'ok', role: 'Marketing', priority: 'Nope', milestone: 'T-99' }], ['Marketing']).length === 1, 'AI task sanitizer rejects invalid roles and normalises bad fields');
const d6 = structuredClone(s0); d6.event.targetRegistrations = 1200; d6.event.date = '2026-11-20'; const s6 = settle(s0, d6);
ok(s6.metrics.gapPct < s0.metrics.gapPct && s6.metrics.daysLeft === 42, 'changing target/date in setup re-drives metrics and risks');

const brief = buildBrief(s3);
ok(brief.includes('Management Brief') && brief.includes('Critical Task Blocked') && brief.includes(`(${s3.health.score}/100)`), 'management brief reflects live risks and health');

// Upgrades: live stream, Q&A, mood
let seed = 7; const rng = () => { seed = (seed * 16807) % 2147483647; return seed / 2147483647; };
const dl = structuredClone(s0); const before = dl.registrations; const added = applyTick(dl, rng);
ok(added >= 2 && added <= 6 && dl.registrations === before + added && dl.feed.length > 0, `live tick adds ${added} registrations and feed entries`);
const dl2 = structuredClone(s0); for (let i = 0; i < 60; i++) applyTick(dl2, rng); const sl = settle(s0, dl2);
ok(!sl.risks.some((r) => r.id === 'reg' && r.severity === 'critical') && sl.feed.length <= 7, `live stream de-escalates the registration risk (reg ${sl.registrations}), feed capped at 7`);
ok(/\/100/.test(answer(s0, 'why is health low?')) && /Top risk/.test(answer(s0, 'what is the top risk')) && /registered/.test(answer(s0, 'forecast')) && /Operations readiness/.test(answer(s0, 'logistics')) && /Try:/.test(answer(s0, 'xyzzy')), 'Q&A answers health/risk/forecast/logistics + fallback');
ok(answer(s4, 'top risk').includes('No active risks'), 'Q&A reflects recovered state');
ok(mood(95) === '🤩' && mood(78) === '😊' && mood(45) === '😬' && mood(10) === '🚨', 'mood emoji mapping');

console.log(failed ? `\n${failed} FAILED` : '\nALL PASSED'); if (failed) throw new Error('tests failed');
