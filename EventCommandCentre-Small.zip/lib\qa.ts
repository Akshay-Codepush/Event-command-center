import type { AppState } from '@/types/event';
import { actionsFor } from './actions';
import { buildInsights } from './ai';

/** "Ask the Command Centre": deterministic Q&A grounded in live state (no model needed). */
export function answer(s: AppState, question: string): string {
  const q = question.toLowerCase(), m = s.metrics, top = s.risks[0];
  if (/health|score/.test(q)) return `Health is ${s.health.score}/100 (${s.health.status}): ${s.health.parts.map((p) => `${p.label} +${Math.round(p.value)}`).join(', ')}, minus ${s.health.penalty.toFixed(1)} for ${s.risks.length} active risk(s).`;
  if (/next|priority|should|do first|recommend/.test(q)) return buildInsights(s).priority;
  if (/risk|wrong|problem|issue|danger/.test(q)) return top ? `Top risk: ${top.type} (${top.severity}). ${top.explanation.what} Why: ${top.explanation.why} Best fix: ${actionsFor(top.id)[0]?.title ?? 'escalate to Leadership'}.` : 'No active risks right now. 🎉';
  if (/forecast|regist|target|gap|attend/.test(q)) return `${s.registrations} of ${s.event.targetRegistrations} registered (${m.gapPct.toFixed(1)}%). At ${m.avgVelocity.toFixed(0)}/day we land near ${m.forecast}; expected attendance ${m.attendance}.`;
  if (/partner|sponsor/.test(q)) { const o = s.partners.filter((p) => p.nextFollowUp < 0 && !['Confirmed', 'Dropped'].includes(p.status)).map((p) => p.name); return `${s.partnerConfirmed}% of partners confirmed. Overdue follow-ups: ${o.join(', ') || 'none'}.`; }
  if (/ops|logistic|venue|transport|\bav\b|catering/.test(q)) { const w = Object.entries(s.categories).sort((a, b) => a[1] - b[1])[0]; return `Operations readiness is ${m.opsReadiness}%. Weakest area: ${w[0]} at ${w[1]}%.`; }
  if (/task|overdue|blocked|todo/.test(q)) { const o = s.tasks.filter((t) => t.status !== 'Completed'); return `${m.tasksDone}/${m.tasksTotal} tasks done. Open: ${o.length}; blocked: ${o.filter((t) => t.status === 'Blocked').length}; overdue: ${o.filter((t) => t.dueInDays < 0).length}.`; }
  if (/days|when|date/.test(q)) return `${s.event.name} is on ${s.event.date} at ${s.event.venue}, ${m.daysLeft} days away.`;
  return 'Try: “why is health low?”, “what is the top risk?”, “forecast”, “what should we do next?”, “partners”, “logistics”, “tasks”.';
}
