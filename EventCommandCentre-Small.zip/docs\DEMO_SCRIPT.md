# 3–5 minute demo script

Tip: press **▶ Guided Demo** (bottom-left) to run this with one click per step, or follow it by hand.

| # | Say | Do | What the judge sees |
|---|---|---|---|
| 1 | "Event data in, intelligence out." | Open Overview | Health **78 😊**, 684 / 820 registrations, 3 risks, the loop strip |
| 2 | "It doesn't just flag — it explains." | Risks → **View Risk** on Registration Velocity Drop | What happened / Why / If nothing is done / What to do |
| 3 | "And assigns an owner." | **Accept & Assign** "partner referral campaign" | Task created for Partnerships; toast + notification |
| 4 | "Did the action work?" | Tasks → **Complete** | Health 78 → 83, gap −16.6% → −9.6%, CRITICAL → WARNING, outcome strip updates |
| 5 | "It reacts live." | Overview → **▶ Go live** | Registrations stream in, gap closes, risk de-escalates |
| 6 | "Stress test." | Simulation → **Logistics Crisis** | Blocked AV task (critical) + overdue transport; health drops |
| 7 | "Recover." | **Last-Minute Recovery** | Tasks created and completed, risks clear, confetti 🎉 |
| 8 | "Ask it anything." | Ask box: "what should we do next?" / **⌘K** | Grounded answers from live state; command palette |
| 9 | "For leadership." | Analytics → **Management brief** | One-page brief generated from live state |

Extras: switch **Role** (Marketing / Partnerships / …) to see role-filtered views; **Event Setup** regenerates the plan from a brief.
