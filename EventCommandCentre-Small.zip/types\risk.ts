import type { Effect, Role } from './event';
export type Severity = 'critical' | 'high' | 'medium' | 'warning';
export type RiskStatus = 'Detected' | 'Acknowledged' | 'Action Assigned' | 'Mitigating' | 'Resolved';
export interface Risk {
  id: string; eventId: string; type: string; severity: Severity; metric: string;
  currentValue: string; threshold: string; detectedAt: string; impact: string;
  explanation: { what: string; why: string };
  recommendedActionIds: string[]; assignedRole: Role; status: RiskStatus;
}
export interface RecoveryAction {
  id: string; riskId: string; title: string; description: string;
  impact: 'HIGH' | 'MEDIUM' | 'LOW'; effort: 'HIGH' | 'MEDIUM' | 'LOW';
  ownerRole: Role; effect: Effect;
}
